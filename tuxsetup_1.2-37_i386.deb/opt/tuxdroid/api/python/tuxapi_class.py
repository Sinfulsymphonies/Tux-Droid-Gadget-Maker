#!/usr/bin/python

# -----------------------------------------------------------------------------
# Tux Droid - API Class
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: tuxapi_class.py 192 2007-03-22 14:25:37Z remi $
# -----------------------------------------------------------------------------

import sys
import os
import time
import socket
import thread
import threading
import string
import signal
import subprocess
import math
from tuxapi_const import *
from copy import deepcopy

#==============================================================================
# Constants
#==============================================================================

api_version ="0.2.3 (SVN/UNRELEASED)"
TCPIP_FRAME_LENGTH = 16

#==============================================================================
# EventControl - class
#==============================================================================
class EventControl(object):

    def __init__(self):
        self.__funct_ptr_list = []
        self.__fifo_list = []
        self.__list_mutex = threading.Lock()
        self.__threads_list = []

    def destroy(self):
        for my_thread in self.__threads_list:
            if my_thread.isAlive():
                my_thread.join()

    def connect(self, funct_ptr):
        self.__list_mutex.acquire()
        idx = len(self.__funct_ptr_list)
        self.__funct_ptr_list.append(funct_ptr)
        self.__list_mutex.release()
        return idx

    def push(self):
        self.__list_mutex.acquire()
        self.__fifo_list.append(self.__funct_ptr_list)
        self.__list_mutex.release()
        self.clear()

    def pop(self):
        if len(self.__fifo_list) > 0:
            self.__list_mutex.acquire()
            self.__funct_ptr_list = self.__fifo_list.pop()
            self.__list_mutex.release()

    def clear(self):
        self.__list_mutex.acquire()
        self.__funct_ptr_list = []
        self.__list_mutex.release()

    def disconnect(self, idx):
        self.__list_mutex.acquire()
        self.__funct_ptr_list[idx] = None
        self.__list_mutex.release()
        
    def __refresh_threads_list(self):
        nl = []
        for t in self.__threads_list:
            if t.isAlive():
                nl.append(t)
        self.__threads_list = nl

    def __run(self, funct_ptr, idx, fargs):
        try:
            funct_ptr(*fargs)
        except:
            self.__list_mutex.acquire()
            self.__funct_ptr_list[idx] == None
            self.__list_mutex.release()

    def notify(self, *fargs):
        self.__list_mutex.acquire()
        if len(self.__funct_ptr_list) == 0:
            self.__list_mutex.release()
            return
        try:
            funct_ptr_list = self.__funct_ptr_list
        except:
            self.__list_mutex.release()
            return
        self.__list_mutex.release()
        for idx, funct_ptr in enumerate(funct_ptr_list):
            if funct_ptr != None:
                self.__refresh_threads_list()
                t=threading.Thread(target=self.__run, args=(funct_ptr, idx, fargs))
                t.setName('EventControl')
                t.start()
                self.__threads_list.append(t)

#==============================================================================
# TUXTCPCommunicator class
#==============================================================================
class TUXTCPCommunicator(object):
    """
    Main class of tux object

        Sub class of this class:
        "cmd" as class              : Class which manages the tux commands
        "connect" as class          : Class which manages connection functions
        "daemon" as class           : Class which manages the daemon commands
        "event" as class            : Class which manages the events
        "hw" as class               : Class which manages the tux hardware
        "micro" as class            : Class which manages the microphone functions
        "misc" as class             : Class which manages the miscellaneous
                                      functions
        "monitoring" as class       : Class which manages the monitoring
        "status" as class           : Class which manages the request of a
                                      status
        "sys" as class              : Class which manages the system functions
        "tts" as class              : Class which manages the text to speech
        "wav" as class              : Class which manages the wav functions

        Global variables of this class:
        "my_name" as string         : Name of the api instance
        "print_status" as boolean   : Allow to print the raw statuses
        "print_warnings" as boolean : Allow to print the warnings

        Comments:
        Call the destroying function at the end of your script for closing
        the api correctly.
        >>> tux.destroy()

        "tts" class is compatible with "tuxttsd" v 0.3.0 or more recent
    """
    #--------------------------------------------------------------------------
    # Constructor of class
    #--------------------------------------------------------------------------
    def __init__(self,deprecated_p=5000,deprecated_a='localhost'):
        """
        Constructor of class

            Example:
            >>> tux=TUXTCPCommunicator()
        """
        self.sock = None
        self.main_thread_list=[]
        self.exit_flag=False
        self.tcp_mutex=threading.Lock()
        self.print_warnings_mutex=threading.Lock()
        self.my_name="Tux client"
        self.print_status=False
        self.print_warnings=True
        self.print_debug_thread=False
        self.lock_list = []
        self.lock_list_mutex = threading.Lock()
        self.tcp_data_fifo_lock = []
        self.tcp_data_fifo_lock_mutex = threading.Lock()
        self.tcp_data_fifo_event = []
        self.tcp_data_fifo_event_mutex = threading.Lock()
        self.event=TUXevent(self)
        self.cmd=TUXcmd(self)
        self.connect=TUXconnect(self)
        self.sys=TUXsys(self)
        self.daemon=TUXdaemon(self)
        self.sdaemon=self.daemon
        self.status=TUXStatus(self)
        self.hw=TUXhw(self)
        self.tts=TUXtts(self)
        self.misc=TUXmisc(self)
        self.monitoring = TUXmonitoring(self)
        self.wav = TUXwav(self)
        self.micro = TUXmicro(self)
        self._switches = []
        self.api_version = api_version

        self.connected=False #deprecated
        t=threading.Thread(target=self.daemon._loop_auto_connect)
        t.setName('daemon._loop_auto_connect')
        t.start()
        self.main_thread_list.append(t)
        t=threading.Thread(target=self.tts._loop_auto_connect)
        t.setName('tts._loop_auto_connect')
        t.start()
        self.main_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Destructor of class
    #--------------------------------------------------------------------------
    def destroy(self):
        if self.exit_flag: return
        self.daemon.auto_connect(False)
        self.tts.auto_connect(False)
        self.daemon.disconnect()
        self.tts.disconnect()
        self.tts.destroy()
        self.daemon._tcp_threads_join()
        self.tts._tcp_threads_join()
        self.micro.destroy()
        self.wav.destroy()
        self.exit_flag=True
        for main_thread in self.main_thread_list:
            if self.print_debug_thread:
                print "'%s' has been released"%main_thread.getName()
            if main_thread.isAlive():
                main_thread.join()
        self=None
        print "Tux object has been destroyed"

    #--------------------------------------------------------------------------
    # Send a frame to tuxd
    #--------------------------------------------------------------------------
    def _sock_send_frame(self, frame):
        try:
            self.sock.send(frame)
        except:
            pass

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _loop_tux_tcp_msg(self):
        """
        Not a user function
        """
        while self.daemon.connected:
            try:
                tmp_tcp_data=self.sock.recv(16)
            except socket.timeout:
                time.sleep(0.01)
                continue
            except socket.error:
                self.sock.close()
                self.daemon.connected=False
                time.sleep(0.01)
                continue
            if len(tmp_tcp_data)<16:
                time.sleep(0.01)
                continue
            self.tcp_data_fifo_lock_mutex.acquire()
            self.tcp_data_fifo_lock.append(tmp_tcp_data)
            self.tcp_data_fifo_lock_mutex.release()
            self.tcp_data_fifo_event_mutex.acquire()
            self.tcp_data_fifo_event.append(tmp_tcp_data)
            self.tcp_data_fifo_event_mutex.release()
            if self.print_status:
                struct_data = ["%.2x" % ord(datae) for datae in tmp_tcp_data]
                print " ".join(struct_data)
            time.sleep(0.01)

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _loop_lock_list(self):
        """
        Not a user function
        self.lock_list
        self.lock_list_mutex
        self.tcp_data_fifo_lock
        self.tcp_data_fifo_lock_mutex
        """
        while self.daemon.connected:
            # get a private lock_list from the class lock_list
            self.lock_list_mutex.acquire()
            lock_list = self.lock_list
            self.lock_list_mutex.release()
            # get a private data_fifo from the class data_fifo
            self.tcp_data_fifo_lock_mutex.acquire()
            if len(self.tcp_data_fifo_lock) > 0:
                data_fifo = self.tcp_data_fifo_lock.pop(0)
            else:
                data_fifo = (chr(99))*16
            self.tcp_data_fifo_lock_mutex.release()
            # get the time now in seconds
            now = self.sys.time()
            # check the whole of the lock elements
            # lock[0] : list of data to match
            # lock[1] : condition mutex
            # lock[2] : data returned
            for i,lock in enumerate(lock_list):
                # for the whole of the lock data
                for lock_data in lock[0]:
                    # if the lock data is matched
                    if lock_data[0] in [ord(data_fifo[0]), 999]\
                    and lock_data[1] in [ord(data_fifo[1]), 999]\
                    and lock_data[2] in [ord(data_fifo[2]), 999]\
                    and lock_data[3] in [ord(data_fifo[3]), 999]\
                    and lock_data[4] in [ord(data_fifo[4]), 999]\
                    and lock_data[5] in [ord(data_fifo[5]), 999]\
                    and lock_data[6] in [ord(data_fifo[6]), 999]\
                    and lock_data[7] in [ord(data_fifo[7]), 999]\
                    and lock_data[8] in [ord(data_fifo[8]), 999]\
                    and lock_data[9] in [ord(data_fifo[9]), 999]\
                    and lock_data[10] in [ord(data_fifo[10]), 999]\
                    and lock_data[11] in [ord(data_fifo[11]), 999]\
                    and lock_data[12] in [ord(data_fifo[12]), 999]\
                    and lock_data[13] in [ord(data_fifo[13]), 999]\
                    and lock_data[14] in [ord(data_fifo[14]), 999]\
                    and lock_data[15] in [ord(data_fifo[15]), 999]:
                        # return the data ones who have unblocked the lock
                        lock[2].append(data_fifo)
                        # unblock the lock
                        lock[1].acquire()
                        lock[1].notify()
                        lock[1].release()
                        lock_list.pop(i)
                        continue
            time.sleep(0.01)
        # kill the whole of the lock elements from the list
        self._close_lock_list()

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _close_lock_list(self):
        self.lock_list_mutex.acquire()
        # unblock the whole of the lock elements
        for i,lock in enumerate(self.lock_list):
            lock[1].acquire()
            lock[1].notify()
            lock[1].release()
        self.lock_list = []
        self.lock_list_mutex.release()

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _insert_lock_in_list(self,data_to_match_list,cond_lock_mutex, \
            returned_data):
            # lock[0] : list of the possible frames to match
            # lock[1] : condition mutex
            # lock[2] : data returned
        lock = []
        lock.append(data_to_match_list)
        lock.append(cond_lock_mutex)
        lock.append(returned_data)
        self.lock_list_mutex.acquire()
        self.lock_list.append(lock)
        self.lock_list_mutex.release()

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _loop_tux_data_dispatching(self):
        """
        Not a user function
        """
        while self.daemon.connected:
            data = ()
            self.tcp_data_fifo_event_mutex.acquire()
            if len(self.tcp_data_fifo_event) > 0:
                data = self.tcp_data_fifo_event.pop(0)
            else:
                self.tcp_data_fifo_event_mutex.release()
                time.sleep(0.003)
                continue
            self.tcp_data_fifo_event_mutex.release()
            self._dispatch_data_main(data)
            time.sleep(0.003)

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _dispatch_data_main(self,data):
        """
        Not a user function
        """
        # from daemon
        if ord(data[0])==SOURCE_SUB_DAEMON:
            self._dispatch_data_from_daemon(data)
        # from tux droid
        if ord(data[0])==SOURCE_TUX:
            self._dispatch_data_from_tux(data)

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _dispatch_data_from_daemon(self,data):
        """
        Not a user function
        """
        # data type command
        if ord(data[2])==DATA_TP_CMD:
            if ord(data[3])==SUBDATA_TP_STRUCT:
                # daemon close
                if ord(data[4])==SUB_D_CMD_STRUC_DISCONNECT_CLIENT:
                    self.daemon.disconnect()

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _dispatch_data_from_tux(self,data):
        """
        Not a user function
        """
        # data type response
        if ord(data[2])==DATA_TP_RSP:
            if ord(data[3])==SUBDATA_TP_STATUS:
                #Head button
                if ord(data[4])==DATAS_STATUS_HEAD_PUSH_SWITCH:
                    if ord(data[5])==1:
                        if self.event.on_head_bt_pushed!=None:
                            self.event.on_head_bt_pushed()
                        if self.event.on_bt_pushed!=None:
                            self.event.on_bt_pushed()
                    else:
                        if self.event.on_head_bt_released!=None:
                            self.event.on_head_bt_released()
                        if self.event.on_bt_released!=None:
                            self.event.on_bt_released()
                #Left wing button
                if ord(data[4])==DATAS_STATUS_LEFT_WING_PUSH:
                    if ord(data[5])==1:
                        if self.event.on_lwing_bt_pushed!=None:
                            self.event.on_lwing_bt_pushed()
                        if self.event.on_bt_pushed!=None:
                            self.event.on_bt_pushed()
                    else:
                        if self.event.on_lwing_bt_released!=None:
                            self.event.on_lwing_bt_released()
                        if self.event.on_bt_released!=None:
                            self.event.on_bt_released()
                #Right wing button
                if ord(data[4])==DATAS_STATUS_RIGHT_WING_PUSH:
                    if ord(data[5])==1:
                        if self.event.on_rwing_bt_pushed!=None:
                            self.event.on_rwing_bt_pushed()
                        if self.event.on_bt_pushed!=None:
                            self.event.on_bt_pushed()
                    else:
                        if self.event.on_rwing_bt_released!=None:
                            self.event.on_rwing_bt_released()
                        if self.event.on_bt_released!=None:
                            self.event.on_bt_released()
                #Remote button
                if ord(data[4])==DATAS_STATUS_IR_CODE:
                    if self.event.on_remote_bt[ord(data[5])]!=None:
                        thread.start_new_thread( \
                                self.event.on_remote_bt[ord(data[5])], ())
                        #self.event.on_remote_bt[ord(data[5])]()
                    if self.event.on_remote!=None:
                        thread.start_new_thread( \
                                self.event.on_remote, (ord(data[5]),))
                        #self.event.on_remote(ord(data[5]))
                #Mouth open
                if ord(data[4])==DATAS_STATUS_MOUTH_OPEN_POSITION:
                    if ord(data[5])==0:
                        if self.event.on_mouth_open!=None:
                            self.event.on_mouth_open()
                #Mouth close
                if ord(data[4])==DATAS_STATUS_MOUTH_CLOSED_POSITION:
                    if ord(data[5])==0:
                        if self.event.on_mouth_close!=None:
                            self.event.on_mouth_close()
                #Ledl
                if ord(data[4])==DATAS_STATUS_LEFT_BLUE_LED:
                    if ord(data[5])==1:
                        if self.event.on_left_blue_led_on!=None:
                            self.event.on_left_blue_led_on()
                    else:
                        if self.event.on_left_blue_led_off!=None:
                            self.event.on_left_blue_led_off()
                #Ledr
                if ord(data[4])==DATAS_STATUS_RIGHT_BLUE_LED:
                    if ord(data[5])==1:
                        if self.event.on_right_blue_led_on!=None:
                            self.event.on_right_blue_led_on()
                    else:
                        if self.event.on_right_blue_led_off!=None:
                            self.event.on_right_blue_led_off()
                #Eyes open/close
                if ord(data[4])==DATAS_STATUS_EYES_CLOSED_POSITION_SWITCH:
                    if ord(data[5])==0:
                        if self.event.on_eyes_close!=None:
                            self.event.on_eyes_close()
                    else:
                        if self.event.on_eyes_open!=None:
                            self.event.on_eyes_open()
                #Power plug switch
                if ord(data[4])==DATAS_STATUS_POWER_PLUG_SWITCH:
                    if ord(data[5])==1:
                        if self.event.on_power_plugged!=None:
                            self.event.on_power_plugged()
                    else:
                        if self.event.on_power_unplugged!=None:
                            self.event.on_power_unplugged()
                #RF status
                if ord(data[4])==DATAS_STATUS_RF_CONNECTED:
                    if ord(data[5])==1:
                        self.status.rf_connected=True
                        if self.event.on_rf_connected!=None:
                            self.event.on_rf_connected()
                    else:
                        self.status.rf_connected=False
                        if self.event.on_rf_disconnected!=None:
                            self.event.on_rf_disconnected()
                #PONG
                if ord(data[4])==DATAS_STATUS_PONG:
                    if self.event.on_pong_received!=None:
                        rcv=ord(data[6])
                        rem=ord(data[5])
                        avg=int((100*rcv)/(200-rem))
                        self.event.on_pong_received(rcv,rem,avg)
                #mouth stop
                if ord(data[4])==DATAS_STATUS_MOUTH_POSITION_COUNTER:
                    if ord(data[5])==0:
                        if self.event.on_mouth_stop!=None:
                            self.event.on_mouth_stop()
                #eyes stop
                if ord(data[4])==DATAS_STATUS_EYES_POSITION_COUNTER:
                    if ord(data[5])==0:
                        if self.event.on_eyes_stop!=None:
                            self.event.on_eyes_stop()

                #wings stop
                if ord(data[4])==DATAS_STATUS_WINGS_POSITION_COUNTER:
                    if ord(data[5])==0:
                        if self.event.on_wings_stop!=None:
                            self.event.on_wings_stop()
                #spin stop
                if ord(data[4])==DATAS_STATUS_SPIN_POSITION_COUNTER:
                    if ord(data[5])==0:
                        if self.event.on_spin_stop!=None:
                            self.event.on_spin_stop()
                #on status
                if self.event.on_status!=None:
                    self.event.on_status(data)
                #on monitoring
                self.monitoring.check_events(data)

                for switch in self._switches:
                    try:
                        switch._notify(ord(data[4]), ord(data[5]))
                    except:
                        pass


    #--------------------------------------------------------------------------
    # Deprecated functions
    #--------------------------------------------------------------------------
    def explicit_status(self,frame):
        """
        Deprecated : see 'tux.status.to_string'
        """
        return self.status.to_string(frame)

    def connect_to_daemon(self):
        """
        Deprecated : see 'tux.daemon.connect'
        """
        return self.daemon.connect()

    def disconnect_from_daemon(self):
        """
        Deprecated : see 'tux.daemon.disconnect'
        """
        self.daemon.disconnect()

#==============================================================================
# TUXTCPCommunicator - connect - class
#==============================================================================
class TUXconnect(object):
    """
    Class which manages connection functions

        Functions list for the users:
            tux.connect.disconnect_from_tux
            tux.connect.connect_to_tux
            tux.connect.random_connect_to_tux
            tux.connect.id_request
            tux.connect.id_lookup
            tux.connect.change_id
            tux.connect.sleep
            tux.connect.wakeup
            tux.connect.avoid_wifi
    """

    #--------------------------------------------------------------------------
    # Constructor of the class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        """
        Constructor of the class
        """
        self.parent=parent

    #--------------------------------------------------------------------------
    # Send a connection command and wait for the result
    #--------------------------------------------------------------------------
    def tux_connection(self, connection_command, connection_args=[]):
        """
        Not a user function
        """
        if not self.parent.daemon.connected:
            return 0
        data=[DEST_TUX, SD_DEFAULT, USB_CONNECTION_CMD, 0, connection_command]
        data.extend(connection_args)
        if len(data) > TCPIP_FRAME_LENGTH:
            return False
        # Fill up the end of the frame with 0
        data.extend([0] * (TCPIP_FRAME_LENGTH - len(data)))
        self.parent._sock_send_frame("".join( [chr(x) for x in data] ))
        return self.parent.status.rsp_status(connection_command, timeout=5)

    #--------------------------------------------------------------------------
    # Disconnect from tux
    #--------------------------------------------------------------------------
    def disconnect_from_tux(self):
        """
        Disconnect from tux

            Parameters:
            "seconds" as float : Time to wait in seconds

            Example:
            >>> tux.sys.wait(2.4)
        """
        ack_frame = self.tux_connection(TUX_CONNECTION_DISCONNECT)
        if not ack_frame or ord(ack_frame[5]) != TUX_CONNECTION_ACK:
            return False

        return True

    #--------------------------------------------------------------------------
    # Connect to a tux by its ID
    #--------------------------------------------------------------------------
    def connect_to_tux(self, id):
        """
        Connect to a tux by its ID

            Parameters:
            "id" as uint16 : ID of the tux you want to connect to
                             0 and 0xFFFF (65536) are not valid ID's

            Returns:
            "True" if the command has been sent successfully,
            "False" otherwise.

            Example:
            >>> tux.connect.connect_to_tux(300)
        """
        # 0 is an invalid id and 0xFFFF is reserved
        assert 0 < id < 0xFFFF
        id_msb = id >> 8
        id_lsb = id & 0xFF
        ack_frame = self.tux_connection(TUX_CONNECTION_CONNECT,
                                        [id_msb, id_lsb])
        if not ack_frame or ord(ack_frame[5]) != TUX_CONNECTION_ACK:
            return False

        return True

    #--------------------------------------------------------------------------
    # Connect to the first tux discovered
    #--------------------------------------------------------------------------
    def random_connect_to_tux(self):
        """
        Connect to the first tux discovered

        Catch any disconnected tux, request it's ID and connect to it.

            Returns:
            "True" if the command has been sent successfully,
            "False" otherwise.

        """
        ack_frame = self.tux_connection(TUX_CONNECTION_RANDOM)
        if not ack_frame or ord(ack_frame[5]) != TUX_CONNECTION_ACK:
            return False

        return True

    #--------------------------------------------------------------------------
    # Get the ID of the first disconnected tux which is discoverred
    #--------------------------------------------------------------------------
    def id_request(self):
        """
        Get the ID of tux currently connected

            Returns:
            "id" as uint16 (0 < id < 65536) if the command has been sent
                    successfully,
            "False" otherwise.
        """
        ack_frame = self.tux_connection(TUX_CONNECTION_ID_REQUEST)
        if ack_frame and ord(ack_frame[5]) == TUX_CONNECTION_ACK:
            return (ord(ack_frame[6])*256) + ord(ack_frame[7])

        return False

    #--------------------------------------------------------------------------
    # Get the ID of the first disconnected tux which is discoverred
    #--------------------------------------------------------------------------
    def id_lookup(self):
        """
        Get the ID of the first disconnected tux which is discoverred

        The first disconnected tux that will detect this command will reply
        with it's ID and disconnect immediately. You can then connect to
        that tux with the ID you just got.

        In order to get the ID's of more than one disconnected tux, you have
        to issue this command multiple times until you don't get any new ID.

            Returns:
            "id" as uint16 (0 < id < 65536) if the command has been sent
                    successfully,
            "False" otherwise.
        """
        ack_frame = self.tux_connection(TUX_CONNECTION_ID_LOOKUP)
        if ack_frame and ord(ack_frame[5]) == TUX_CONNECTION_ACK:
            return (ord(ack_frame[6])*256) + ord(ack_frame[7])

        return False

    #--------------------------------------------------------------------------
    # Changes the ID of a disconnected tux
    #--------------------------------------------------------------------------
    def change_id(self, id):
        """
        Changes the ID of a disconnected tux

        You have to push on the head button of tux for XXX seconds while
        sending this command in order to validate the ID change request, this
        in order to avoid stealing a tux too easily.

            Parameters:
            "id" as uint16 : new ID you want to set to your tux
                             0 and 0xFFFF (65536) are not valid ID's

            Returns:
            "True" if the command has been sent successfully,
            "False" otherwise.
        """
        assert 0 < id < 0xFFFF
        id_msb = id >> 8
        id_lsb = id % 256
        ack_frame = self.tux_connection(TUX_CONNECTION_CHANGE_ID,
                                        [id_msb, id_lsb])
        if not ack_frame or ord(ack_frame[5]) != TUX_CONNECTION_ACK:
            return False

        return True

    #--------------------------------------------------------------------------
    # Set tux in sleep mode
    #--------------------------------------------------------------------------
    def sleep(self):
        """
        Set tux in sleep mode

            Returns:
            "True" if the command has been sent successfully,
            "False" otherwise.
        """
        ack_frame = self.tux_connection(TUX_CONNECTION_SLEEP)
        if not ack_frame or ord(ack_frame[5]) != TUX_CONNECTION_ACK:
            return False

        return True

    #--------------------------------------------------------------------------
    # Wake-up a tux if it's in sleep mode.
    #--------------------------------------------------------------------------
    def wakeup(self, id):
        """
        Wake-up a tux if it's in sleep mode.

            Parameters:
            "id" as uint16 : ID of the tux you want to wake-up
                             0 and 0xFFFF (65536) are not valid ID's

            Returns:
            "True" if the command has been sent successfully,
            "False" otherwise.
        """
        assert 0 < id < 0xFFFF
        id_msb = id >> 8
        id_lsb = id % 256
        ack_frame = self.tux_connection(TUX_CONNECTION_WAKEUP,
                                        [id_msb, id_lsb])
        if not ack_frame or ord(ack_frame[5]) != TUX_CONNECTION_ACK:
            return False

        return True

    #--------------------------------------------------------------------------
    # Configure the RF module to avoid a given wifi channel
    #--------------------------------------------------------------------------
    def avoid_wifi(self, channel):
        """
        Configure the RF module to avoid a given wifi channel


            Parameters:
            "channel" : wifi channel number that tux should avoid using
                    Channels from 1 to 14 are valid wifi channels. Set the wifi
                    channel to 0 to disable channel avoidance and use the
                    complete range of frequencies.

            Returns:
            "True" if the command has been sent successfully,
            "False" otherwise.
        """
        ack_frame = self.tux_connection(TUX_CONNECTION_WIRELESS_CHANNEL,
                                        [channel])
        if not ack_frame or ord(ack_frame[5]) != TUX_CONNECTION_ACK:
            return False

        return True


#==============================================================================
# TUXTCPCommunicator - sys - class
#==============================================================================
class TUXsys(object):
    """
    Class which manages the system functions

        Functions list for the users:
            tux.sys.add_time_event
            tux.sys.clear_time_events
            tux.sys.delayed_function
            tux.sys.delete_time_event
            tux.sys.looped_function
            tux.sys.shell
            tux.sys.shell_free
            tux.sys.time
            tux.sys.wait
    """

    #--------------------------------------------------------------------------
    # Constructor of class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        """
        Constructor of class
        """
        self.parent = parent
        self.events_list = [[0,'NONE',9999,99,99,99,99,99]]
        self.__time_event_mutex = threading.Lock()

    #--------------------------------------------------------------------------
    # Get the current time in seconds
    #--------------------------------------------------------------------------
    def time(self):
        """
        Get the current time in seconds

            Return an integer

            Example:
            >>> var=tux.sys.time()
        """
        return (time.localtime()[3]*3600)+(time.localtime()[4]*60)+ \
                time.localtime()[5]

    #--------------------------------------------------------------------------
    # Wait a time in seconds
    #--------------------------------------------------------------------------
    def wait(self,seconds):
        """
        Wait a time in seconds

            Parameters:
            "seconds" as float : Time to wait in seconds

            Example:
            >>> tux.sys.wait(2.4)
        """
        time.sleep(seconds)

    #--------------------------------------------------------------------------
    # Execute a shell command
    #--------------------------------------------------------------------------
    def shell(self,command):
        """
        Execute a shell command

            Parameters:
            "command" as string : Shell command

            Example:
            >>> tux.sys.shell('ls -al')
        """
        os.system(command)

    #--------------------------------------------------------------------------
    # Execute a shell command in free mode
    #--------------------------------------------------------------------------
    def shell_free(self,command):
        """
        Execute a shell command in free mode

            Parameters:
            "command" as string : Shell command

            Example:
            >>> tux.sys.shell_free('ls -al')
        """
        thread.start_new_thread(self.shell,(command,))

    #--------------------------------------------------------------------------
    # Add a time event in the time event handler
    #--------------------------------------------------------------------------
    def add_time_event(self,cmd_type,cmd,year,month,day,hour,minute,second):
        """
        Add a time event in the time event handler

            Parameters:
            "cmd_type" as number  : Command type (CT_SHELL|CT_FUNCTION)
            "cmd" as string       : Command to execute
            "year" as integer     : (ex : 2006) (9999 : parameter ignored)
            "month" as integer    : (ex : 12) (99 : parameter ignored)
            "day" as integer      : (ex : 23) (99 : parameter ignored)
            "hour" as integer     : (ex : 08) (99 : parameter ignored)
            "minute" as integer   : (ex : 55) (99 : parameter ignored)
            "second" as integer   : (ex : 30) (99 : parameter ignored)

            Example:
            >>> tux.sys.add_time_event(CT_SHELL,'xmms',9999,99,99,8,5,0)
        """
        self.__time_event_mutex.acquire()
        self.events_list.append([cmd_type,cmd,year,month,day,hour, \
                minute,second])
        self.__time_event_mutex.release()

    #--------------------------------------------------------------------------
    # Clear the time events of the time event handler
    #--------------------------------------------------------------------------
    def clear_time_events(self):
        """
        Clear the time events of the time event handle

            Example:
            >>> tux.sys.clear_time_events()
        """
        self.__time_event_mutex.acquire()
        self.events_list=[[0,'NONE',9999,99,99,99,99,99]]
        self.__time_event_mutex.release()

    #--------------------------------------------------------------------------
    # Delete a time event from the time event handler
    #--------------------------------------------------------------------------
    def delete_time_event(self, cmd_type,cmd,year,month,day,hour,minute,second):
        """
        Delete a time event from the time event handler

            Parameters:
            "cmd_type" as number  : Command type (CT_SHELL|CT_FUNCTION)
            "cmd" as string       : Command to execute
            "year" as integer     : (ex : 2006) (9999 : parameter ignored)
            "month" as integer    : (ex : 12) (99 : parameter ignored)
            "day" as integer      : (ex : 23) (99 : parameter ignored)
            "hour" as integer     : (ex : 08) (99 : parameter ignored)
            "minute" as integer   : (ex : 55) (99 : parameter ignored)
            "second" as integer   : (ex : 30) (99 : parameter ignored)

            Example:
            >>> tux.sys.delete_time_event(CT_SHELL,'xmms',9999,99,99,8,5,0)
        """
        self.__time_event_mutex.acquire()
        event_to_remove = [cmd_type,cmd,year,month,day,hour,minute,second]
        for i, event in enumerate(self.events_list):
            matched = True
            for j, p in enumerate(event):
                if event_to_remove[j] != p:
                    matched = False
            if matched:
                self.events_list.pop(i)
                self.__time_event_mutex.release()
                return True
        self.__time_event_mutex.release()
        return False

    #--------------------------------------------------------------------------
    # Not a user function
    #--------------------------------------------------------------------------
    def _loop_time_events(self):
        """
        Not a user function
        """
        def event_due(event):
            now = time.localtime()
            return event[2] in [now[0], 9999]\
                    and event[3] in [now[1], 99]\
                    and event[4] in [now[2], 99]\
                    and event[5] in [now[3], 99]\
                    and event[6] in [now[4], 99]\
                    and event[7] in [now[5], 99]

        while self.parent.daemon.connected:
            self.__time_event_mutex.acquire()
            events_list = self.events_list
            self.__time_event_mutex.release()
            for event in events_list:
                if event[0]!=0 and event_due(event):
                    if event[0]==CT_SHELL:
                        self.shell_free(event[1])
                    elif event[0]==CT_FUNCTION:
                        event[1]()
            time.sleep(1)

    #--------------------------------------------------------------------------
    # To execute a function with a delay
    #--------------------------------------------------------------------------
    def delayed_function(self,function,delay):
        """
        To execute a function with a delay

            Parameters:
            "function" as pointer of function   : function to execute
            "delay" as float                    : time to wait before executing
                                                  the function. In seconds

            Example:
            >>> def test():
            ...     print "hello world"
            ...
            >>> tux.sys.delayed_function(test,10)
        """
        def _funct(function,delay):
            self.wait(delay)
            function()

        t=threading.Thread(target=_funct,args=(function,delay,))
        t.setName('sys.delayed_function')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Looping on a function with a delay
    #--------------------------------------------------------------------------
    def looped_function(self,function,delay):
        """
        Looping on a function with a delay

            Parameters:
            "function" as pointer of function: function to execute
            "delay" as float                 : time to wait between 2 executions
                                               of the function. In seconds

            Example:
            >>> def test():
            ...     print "hello world"
            ...     return True
            ...
            >>> tux.sys.looped_function(test,10)

            Comment:
            While the return of the function is true, the loop remains
            active
        """
        def _funct(function,delay):
            while not self.parent.exit_flag:
                self.wait(delay)
                if not function():
                    return
        t=threading.Thread(target=_funct,args=(function,delay,))
        t.setName('sys.temporized_function')
        t.start()
        self.parent.main_thread_list.append(t)

#==============================================================================
# TUXTCPCommunicator - monitoring - class
#==============================================================================
class TUXmonitoring(object):
    """
    Class which manages the monitoring

        Status constants list:
        (STATUS_WINGS_MOTOR_BACKWARD,       STATUS_SPIN_MOTOR_BACKWARD,
         STATUS_SPIN_MOTOR_FORWARD,         STATUS_MOUTH_OPEN_POSITION,
         STATUS_MOUTH_CLOSED_POSITION,      STATUS_HEAD_PUSH_POSITION,
         STATUS_CHARGER_INHIBIT_SIGNAL,     STATUS_WINGS_POSITION_SWITCH,
         STATUS_MOTOR_FOR_WINGS,            STATUS_LEFT_BLUE_LED,
         STATUS_I2C_SDA_LINE,               STATUS_I2C_SCL_LINE ,
         STATUS_HEAD_MOTOR_FOR_MOUTH,       STATUS_HEAD_MOTOR_FOR_EYES,
         STATUS_IR_RECEIVER_SIGNAL,         STATUS_SPIN_POSITION_SWITCH,
         STATUS_WINGS_MOTOR_FORWARD,        STATUS_IR_LED,
         STATUS_EYES_OPEN_POSITION_SWITCH,  STATUS_EYES_CLOSED_POSITION_SWITCH,
         STATUS_LEFT_WING_PUSH,             STATUS_RIGHT_WING_PUSH,
         STATUS_POWER_PLUG_SWITCH,          STATUS_HEAD_PUSH_SWITCH,
         STATUS_CHARGER_LED,                STATUS_MUTE_STATUS,
         STATUS_LIGHT_LEVEL,                STATUS_EYES_POSITION_COUNTER,
         STATUS_MOUTH_POSITION_COUNTER,     STATUS_WINGS_POSITION_COUNTER,
         STATUS_SPIN_POSITION_COUNTER,      STATUS_RIGHT_BLUE_LED,
         STATUS_RF_CONNECTED,               STATUS_IR_CODE,
         STATUS_SOUND_COUNT,                STATUS_PONG,
         STATUS_BATTERY,                    STATUS_MICRO_ENERGY,
        )

        Functions list:
        tux.monitoring.insert
        tux.monitoring.remove
    """

    def __init__(self, parent):
        self.parent = parent
        self._event_mutex = threading.Lock()
        self._event_list = []

    def insert(self, status, function):
        """
        Insert a monitoring event.

            Parameters:
            "status" as integer                 : Status index
                                                  (See status contants list)
            "function" as pointer of function   : Function to bind

            Returns:
            The index of your event in the monitoring manager.
            You must save this index if you want removing your event.

            Exemple:
            >>> monitor_idx = tux.monitoring.insert(STATUS_LIGHT_LEVEL, my_function)
        """
        self._event_mutex.acquire()
        self._event_list.append([status, function])
        self._event_mutex.release()
        return len(self._event_list) - 1

    def remove(self, event_id):
        """
        Remove a monitoring event.

            Parameters:
            "event_id" as integer   : Index of the event.

            Exemple:
            >>> tux.monitoring.remove(monitor_idx)
        """
        self._event_mutex.acquire()
        self._event_list[event_id][1] = None
        self._event_mutex.release()

    def check_events(self, frame):
        self._event_mutex.acquire()
        events = self._event_list
        self._event_mutex.release()

        def __load_funct_async(idx, funct, args):
            try:
                funct(args)
            except:
                self.remove(idx)
                
        fff = frame[5:]
        ord_frame = []
        for val in fff:
            ord_frame.append(ord(val))

        for i, event in enumerate(events):
            if event[1] != None:
                if event[0] == ord(frame[4]):
                    m_args = tuple(ord_frame)
                    t = threading.Thread(target = __load_funct_async, args = (i, event[1], m_args))
                    t.start()


#==============================================================================
# TUXTCPCommunicator - event - class
#==============================================================================
class TUXevent(object):
    """
    Class which manages the events

        Global variables of this class:
        "on_bt_pushed" as pof           : On tux button pushed
        "on_head_bt_pushed" as pof      : On tux head button pushed
        "on_lwing_bt_pushed" as pof     : On tux left wing button pushed
        "on_rwing_bt_pushed" as pof     : On tux right wing button pushed
        "on_bt_released" as pof         : On tux button released
        "on_head_bt_released" as pof    : On tux head button released
        "on_lwing_bt_released" as pof   : On tux left wing button released
        "on_rwing_bt_released" as pof   : On tux right wing button released
        "on_remote_bt" as list of pof   : On remote controller button pressed
        "on_status" as pof              : On status arrival
        "on_remote" as pof              : On remote controller event
                                          param 1 : Key as integer
        "on_light_level" as pof         : On light level event
                                          param 1 : light value as integer
        "on_connected" as pof           : On api connected to tuxd
        "on_disconnected" as pof        : On api disconnect from tuxd
        "on_mouth_open" as pof          : On mouth open event
        "on_mouth_close" as pof         : On mouth close event
        "on_power_plugged" as pof       : On power plugged event
        "on_power_unplugged" as pof     : On power unplugged event
        "on_left_blue_led_on" as pof    : On left blue led changed to on
        "on_left_blue_led_off" as pof   : On left blue led changed to off
        "on_right_blue_led_on" as pof   : On right blue led changed to on
        "on_right_blue_led_off" as pof  : On right blue led changed to off
        "on_eyes_open" as pof           : On eyes open event
        "on_eyes_close" as pof          : On eyes close event
        "on_rf_connected" as pof        : On RF is connected
        "on_rf_disconnected" as pof     : On RF is disconnected
        "on_pong_received" as pof       : On pong status received
        "on_mouth_stop" as pof          : On mouth stop event
        "on_eyes_stop" as pof           : On eyes stop event
        "on_wings_stop" as pof          : On wings stop event
        "on_spin_stop" as pof           : On spin stop event
        (pof = pointer of function)

        Example of associating a function to a remote event:
        >>> def my_function(key):
        >>>     print "Button %s is pressed"%remote_bt_name[key]
        >>> tux.event.on_remote=my_function

        Example of associating a function to a specific remote event:
        >>> def play_pause():
        >>> tux.sys.shell("audacious --play-pause")
        >>> tux.event.on_remote_bt[K_PLAYPAUSE]=play_pause

        Key constants of the remote controller:
        (K_0,K_1,K_2,K_3,K_4,K_5,K_6,K_7,K_8,K_9,K_STANDBY,
        K_MUTE,K_VOLUMEPLUS,K_VOLUMEMINUS,K_ESCAPE,K_YES,
        K_NO,K_BACKSPACE,K_STARTVOIP,K_RECEIVECALL,K_HANGUP,
        K_STAR,K_SHARP,K_RED,K_GREEN,K_BLUE,K_YELLOW,
        K_CHANNELPLUS,K_CHANNELMINUS,K_UP,K_DOWN,K_LEFT,
        K_RIGHT,K_OK,K_FASTREWIND,K_FASTFORWARD,K_PLAYPAUSE,
        K_STOP,K_RECORDING,K_PREVIOUS,K_NEXT,K_MENU,K_MOUSE,
        K_ALT)

        Functions list:
            tux.event.clear
            tux.event.remote_key_to_string
            tux.event.restore
            tux.event.store
            tux.event.wait_bt_pushed
            tux.event.wait_head_bt_pushed
            tux.event.wait_head_bt_released
            tux.event.wait_lwing_bt_pushed
            tux.event.wait_lwing_bt_released
            tux.event.wait_remote_bt
            tux.event.wait_rwing_bt_pushed
            tux.event.wait_rwing_bt_released
            tux.event.wait_stable_status
            tux.event.wait_status
    """
    #--------------------------------------------------------------------------
    # Constructor of class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        """
        Constructor of class
        """
        self.parent=parent
        self.event_storage_fifo = []
        self.clear()

    #--------------------------------------------------------------------------
    # Get the string name of a remote key value
    #--------------------------------------------------------------------------
    def remote_key_to_string(self,key):
        """
        Get the string name of a remote key value

            Parameters:
            "key" as integer    : key to translate to string

            Return a string

            Example:
            >>> print tux.event.remote_key_to_string(10)
        """
        return remote_bt_name[key]

    #--------------------------------------------------------------------------
    # Clear all events
    #--------------------------------------------------------------------------
    def clear(self):
        """
        Clear all events

            Example:
            >>> tux.event.clear()
        """
        self.on_bt_pushed=None
        self.on_head_bt_pushed=None
        self.on_lwing_bt_pushed=None
        self.on_rwing_bt_pushed=None
        self.on_bt_released=None
        self.on_head_bt_released=None
        self.on_lwing_bt_released=None
        self.on_rwing_bt_released=None
        self.on_remote_bt=[None]*64
        self.on_status=None
        self.on_remote=None
        self.on_light_level=None
        self.on_connected=None
        self.on_disconnected=None
        self.on_mouth_open=None
        self.on_mouth_close=None
        self.on_power_plugged=None
        self.on_power_unplugged=None
        self.on_left_blue_led_on=None
        self.on_left_blue_led_off=None
        self.on_right_blue_led_on=None
        self.on_right_blue_led_off=None
        self.on_eyes_open=None
        self.on_eyes_close=None
        self.on_rf_connected=None
        self.on_rf_disconnected=None
        self.on_pong_received=None
        self.on_mouth_stop=None
        self.on_eyes_stop=None
        self.on_wings_stop=None
        self.on_spin_stop=None

    #--------------------------------------------------------------------------
    # Store all events
    #--------------------------------------------------------------------------
    def store(self):
        """
        Store all events

            Example:
            >>> tux.event.store()
        """
        event_storage = []
        event_storage.append(self.on_bt_pushed)
        event_storage.append(self.on_head_bt_pushed)
        event_storage.append(self.on_lwing_bt_pushed)
        event_storage.append(self.on_rwing_bt_pushed)
        event_storage.append(self.on_bt_released)
        event_storage.append(self.on_head_bt_released)
        event_storage.append(self.on_lwing_bt_released)
        event_storage.append(self.on_rwing_bt_released)
        event_storage.append(self.on_remote_bt)
        event_storage.append(self.on_status)
        event_storage.append(self.on_remote)
        event_storage.append(self.on_light_level)
        event_storage.append(self.on_connected)
        event_storage.append(self.on_disconnected)
        event_storage.append(self.on_mouth_open)
        event_storage.append(self.on_mouth_close)
        event_storage.append(self.on_power_plugged)
        event_storage.append(self.on_power_unplugged)
        event_storage.append(self.on_left_blue_led_on)
        event_storage.append(self.on_left_blue_led_off)
        event_storage.append(self.on_right_blue_led_on)
        event_storage.append(self.on_right_blue_led_off)
        event_storage.append(self.on_eyes_open)
        event_storage.append(self.on_eyes_close)
        event_storage.append(self.on_rf_connected)
        event_storage.append(self.on_rf_disconnected)
        event_storage.append(self.on_pong_received)
        event_storage.append(self.on_mouth_stop)
        event_storage.append(self.on_eyes_stop)
        event_storage.append(self.on_wings_stop)
        event_storage.append(self.on_spin_stop)
        event_storage.append(self.parent.tts.on_sound_on)
        event_storage.append(self.parent.tts.on_sound_off)
        self.event_storage_fifo.append(event_storage)

    #--------------------------------------------------------------------------
    # Restore all events
    #--------------------------------------------------------------------------
    def restore(self):
        """
        Restore all events

            Example:
            >>> tux.event.restore()
        """
        if len(self.event_storage_fifo) == 0: return
        event_storage = self.event_storage_fifo.pop()
        self.on_bt_pushed=event_storage.pop(0)
        self.on_head_bt_pushed=event_storage.pop(0)
        self.on_lwing_bt_pushed=event_storage.pop(0)
        self.on_rwing_bt_pushed=event_storage.pop(0)
        self.on_bt_released=event_storage.pop(0)
        self.on_head_bt_released=event_storage.pop(0)
        self.on_lwing_bt_released=event_storage.pop(0)
        self.on_rwing_bt_released=event_storage.pop(0)
        self.on_remote_bt=event_storage.pop(0)
        self.on_status=event_storage.pop(0)
        self.on_remote=event_storage.pop(0)
        self.on_light_level=event_storage.pop(0)
        self.on_connected=event_storage.pop(0)
        self.on_disconnected=event_storage.pop(0)
        self.on_mouth_open=event_storage.pop(0)
        self.on_mouth_close=event_storage.pop(0)
        self.on_power_plugged=event_storage.pop(0)
        self.on_power_unplugged=event_storage.pop(0)
        self.on_left_blue_led_on=event_storage.pop(0)
        self.on_left_blue_led_off=event_storage.pop(0)
        self.on_right_blue_led_on=event_storage.pop(0)
        self.on_right_blue_led_off=event_storage.pop(0)
        self.on_eyes_open=event_storage.pop(0)
        self.on_eyes_close=event_storage.pop(0)
        self.on_rf_connected=event_storage.pop(0)
        self.on_rf_disconnected=event_storage.pop(0)
        self.on_pong_received=event_storage.pop(0)
        self.on_mouth_stop=event_storage.pop(0)
        self.on_eyes_stop=event_storage.pop(0)
        self.on_wings_stop=event_storage.pop(0)
        self.on_spin_stop=event_storage.pop(0)
        self.parent.tts.on_sound_on=event_storage.pop(0)
        self.parent.tts.on_sound_off=event_storage.pop(0)

    #--------------------------------------------------------------------------
    # Wait until the specified status arrives
    #--------------------------------------------------------------------------
    def wait_status(self,DATA_STATUS,DATA_VALUE,time_out):
        """
        Wait until the specified status arrives

            Parameters:
            "DATA_STATUS" as integer  : Desired status
            "DATA_VALUE" as integer   : Desired value
            "time_out" as integer     : Time-out in seconds
                                        (9999 = infinite wait)

            Return a boolean

            Example:
            >>> var=tux.event.wait_status(DATAS_STATUS_HEAD_PUSH_SWITCH,1,2)
            (see 'tuxapi_const.py' for the complete list of statuses)
        """
        # create a condition mutex
        cond_lock_mutex = threading.Condition(threading.Lock())
        # create a list of frames to match
        data_to_match_list = []
        # create and insert a frame to match
        data_to_match = (SOURCE_TUX,SS_DEFAULT,DATA_TP_RSP,SUBDATA_TP_STATUS,
                DATA_STATUS,DATA_VALUE,0,0,0,0,0,0,0,0,0,0)
        data_to_match_list.append(data_to_match)
        # create empty frame returned
        returned_data = []
        # insert theses settings in the lock list
        self.parent._insert_lock_in_list(data_to_match_list,cond_lock_mutex, \
                returned_data)
        # wait the lock has unblocked. With a time-out
        cond_lock_mutex.acquire()
        cond_lock_mutex.wait(time_out)
        cond_lock_mutex.release()
        # returns
        if len(returned_data) == 0:
            return False
        else:
            return True

    #--------------------------------------------------------------------------
    # Wait for stable status
    #--------------------------------------------------------------------------
    def wait_stable_status(self,DATA_STATUS,DATA_VALUE,stable_time,time_out):
        """
        Wait for stable status

            Parameters:
            "DATA_STATUS" as integer  : Desired status
            "DATA_VALUE" as integer   : Desired value
            "time_out" as integer     : Time-out in seconds
                                        (9999 = infinite wait)
            "stable_out" as integer   : Time of stable status request in seconds

            Return a boolean

            Example:
            >>> var=tux.event.wait_status(DATAS_STATUS_HEAD_PUSH_SWITCH,1,5,2)
        """
        if self.wait_status(DATA_STATUS,DATA_VALUE,time_out)==False:
            return False
        else:
            if DATA_VALUE==1:
                INV_DATA_VALUE=0
            else:
                INV_DATA_VALUE=1
            return not self.wait_status(DATA_STATUS,INV_DATA_VALUE,stable_time)

    #--------------------------------------------------------------------------
    # Wait until a tux button is pushed
    #--------------------------------------------------------------------------
    def wait_bt_pushed(self,time_out):
        """
        Wait until a tux button is pushed

            Parameters:
            "time_out" as integer : Time-out in seconds
                                    (9999 = infinite wait)

            Return the button value as integer
            (HEAD_BT|LEFT_WING_BT|RIGHT_WING_BT|NONE_BT)

            Example:
            >>> tux.event.wait_bt_pushed(10)
        """
        # create a condition mutex
        cond_lock_mutex = threading.Condition(threading.Lock())
        # create a list of frames to match
        data_to_match_list = []
        # create and insert a frame to match
        data_to_match = (SOURCE_TUX,SS_DEFAULT, DATA_TP_RSP, SUBDATA_TP_STATUS,
                DATAS_STATUS_HEAD_PUSH_SWITCH,1,0,0,0,0,0,0,0,0,0,0)
        data_to_match_list.append(data_to_match)
        # create and insert a frame to match
        data_to_match = (SOURCE_TUX,SS_DEFAULT,DATA_TP_RSP,SUBDATA_TP_STATUS,
                DATAS_STATUS_LEFT_WING_PUSH,1,0,0,0,0,0,0,0,0,0,0)
        data_to_match_list.append(data_to_match)
        # create and insert a frame to match
        data_to_match = (SOURCE_TUX,SS_DEFAULT,DATA_TP_RSP,SUBDATA_TP_STATUS,
                DATAS_STATUS_RIGHT_WING_PUSH,1,0,0,0,0,0,0,0,0,0,0)
        data_to_match_list.append(data_to_match)
        # create empty frame returned
        returned_data = []
        # insert theses settings in the lock list
        self.parent._insert_lock_in_list(data_to_match_list,cond_lock_mutex, \
                returned_data)
        # wait the lock has unblocked. With a time-out
        cond_lock_mutex.acquire()
        cond_lock_mutex.wait(time_out)
        cond_lock_mutex.release()
        # returns
        if len(returned_data) == 0:
            return NONE_BT
        else:
            if ord(returned_data[0][4]) == DATAS_STATUS_HEAD_PUSH_SWITCH:
                return HEAD_BT
            if ord(returned_data[0][4]) == DATAS_STATUS_LEFT_WING_PUSH:
                return LEFT_WING_BT
            if ord(returned_data[0][4]) == DATAS_STATUS_RIGHT_WING_PUSH:
                return RIGHT_WING_BT

    #--------------------------------------------------------------------------
    # Wait until head button is pushed
    #--------------------------------------------------------------------------
    def wait_head_bt_pushed(self,time_out):
        """
        Wait until head button is pushed

            Parameters:
            "time_out" as integer : Time-out in seconds
                                    (9999 = infinite wait)

            Return a boolean

            Example:
            >>> tux.event.wait_head_bt_pushed(2)
        """
        return self.wait_status(DATAS_STATUS_HEAD_PUSH_SWITCH,1,time_out)

    #--------------------------------------------------------------------------
    # Wait until head button is released
    #--------------------------------------------------------------------------
    def wait_head_bt_released(self,time_out):
        """
        Wait until head button is released

            Parameters:
            "time_out" as integer : Time-out in seconds
                                    (9999 = infinite wait)

            Return a boolean

            Example:
            >>> tux.event.wait_head_bt_released(2)
        """
        return self.wait_status(DATAS_STATUS_HEAD_PUSH_SWITCH,0,time_out)

    #--------------------------------------------------------------------------
    # Wait until left wing is pushed
    #--------------------------------------------------------------------------
    def wait_lwing_bt_pushed(self,time_out):
        """
        Wait until left wing is pushed

            Parameters:
            "time_out" as integer : Time-out in seconds
                                    (9999 = infinite wait)

            Return a boolean

            Example:
            >>> tux.event.wait_lwing_bt_pushed(2)
        """
        return self.wait_status(DATAS_STATUS_LEFT_WING_PUSH,1,time_out)

    #--------------------------------------------------------------------------
    # Wait until left wing is released
    #--------------------------------------------------------------------------
    def wait_lwing_bt_released(self,time_out):
        """
        Wait until left wing is released

            Parameters:
            "time_out" as integer : Time-out in seconds
                                    (9999 = infinite wait)

            Return a boolean

            Example:
            >>> tux.event.wait_lwing_bt_released(2)
        """
        return self.wait_status(DATAS_STATUS_LEFT_WING_PUSH,0,time_out)

    #--------------------------------------------------------------------------
    # Wait until right wing is pushed
    #--------------------------------------------------------------------------
    def wait_rwing_bt_pushed(self,time_out):
        """
        Wait until right wing is pushed

            Parameters:
            "time_out" as integer : Time-out in seconds
                                    (9999 = infinite wait)

            Return a boolean

            Example:
            >>> tux.event.wait_rwing_bt_pushed(2)
        """
        return self.wait_status(DATAS_STATUS_RIGHT_WING_PUSH,1,time_out)

    #--------------------------------------------------------------------------
    # Wait until right wing is released
    #--------------------------------------------------------------------------
    def wait_rwing_bt_released(self,time_out):
        """
        Wait until right wing is released

            Parameters:
            "time_out" as integer : Time-out in seconds
                                    (9999 = infinite wait)

            Return a boolean

            Example:
            >>> tux.event.wait_rwing_bt_released(2)
        """
        return self.wait_status(DATAS_STATUS_RIGHT_WING_PUSH,0,time_out)

    #--------------------------------------------------------------------------
    # Wait until a specified key of the remote is pressed
    #--------------------------------------------------------------------------
    def wait_remote_bt(self,remote_key,timeout):
        """
        Wait until a specified key of the remote is pressed

            Parameters:
            "time_out" as integer : Time-out in seconds
                                    (9999 = infinite wait)

            Return a boolean

            Example:
            >>> tux.event.wait_remote_bt(K_OK,2)
        """
        return self.wait_status(DATAS_STATUS_IR_CODE,remote_key,timeout)


    #--------------------------------------------------------------------------
    # Deprecated functions
    #--------------------------------------------------------------------------
    def set_on_bt_pushed(self,function):
        """
        Deprecated
        """
        self.on_bt_pushed=function
    def set_on_head_bt_pushed(self,function):
        """
        Deprecated
        """
        self.on_head_bt_pushed=function
    def set_on_lwing_bt_pushed(self,function):
        """
        Deprecated
        """
        self.on_lwing_bt_pushed=function
    def set_on_rwing_bt_pushed(self,function):
        """
        Deprecated
        """
        self.on_rwing_bt_pushed=function
    def set_on_bt_released(self,function):
        """
        Deprecated
        """
        self.on_bt_released=function
    def set_on_head_bt_released(self,function):
        """
        Deprecated
        """
        self.on_head_bt_released=function
    def set_on_lwing_bt_released(self,function):
        """
        Deprecated
        """
        self.on_lwing_bt_released=function
    def set_on_rwing_bt_released(self,function):
        """
        Deprecated
        """
        self.on_rwing_bt_released=function
    def set_on_remote_bt(self,key,function):
        """
        Deprecated
        """
        self.on_remote_bt[key]=function

#==============================================================================
# TUXTCPCommunicator - cmd - class
#==============================================================================
class TUXcmd(object):
    """
    Class which manages the tux commands

        Global variables of this class:
        "last_ack" as integer   : ACK value of the last command
                                  (ACK_CMD_DONGLE_NOT_PRESENT|ACK_CMD_TIMEOUT|
                                  ACK_CMD_OK|ACK_CMD_KO|ACK_CMD_ERROR)
        "no_ack" as boolean     : Allow to wait a ACK from tuxd

        Functions list for the users:
            tux.cmd.audio_channel_general
            tux.cmd.audio_channel_tts
            tux.cmd.eyes_close
            tux.cmd.eyes_off
            tux.cmd.eyes_on
            tux.cmd.eyes_on_free
            tux.cmd.eyes_open
            tux.cmd.ir_off
            tux.cmd.ir_on
            tux.cmd.ir_send
            tux.cmd.ledl_during
            tux.cmd.ledl_during_free
            tux.cmd.ledl_off
            tux.cmd.ledl_on
            tux.cmd.ledr_during
            tux.cmd.ledr_during_free
            tux.cmd.ledr_off
            tux.cmd.ledr_on
            tux.cmd.leds_blink
            tux.cmd.leds_during
            tux.cmd.leds_during_free
            tux.cmd.leds_off
            tux.cmd.leds_on
            tux.cmd.mouth_close
            tux.cmd.mouth_off
            tux.cmd.mouth_on
            tux.cmd.mouth_on_free
            tux.cmd.mouth_open
            tux.cmd.ping
            tux.cmd.raw
            tux.cmd.sleep_off
            tux.cmd.sleep_on
            tux.cmd.sound_play
            tux.cmd.sound_store_index
            tux.cmd.sound_storing
            tux.cmd.sound_test
            tux.cmd.spinl_off
            tux.cmd.spinl_on
            tux.cmd.spinl_on_free
            tux.cmd.spinr_off
            tux.cmd.spinr_on
            tux.cmd.spinr_on_free
            tux.cmd.structured
            tux.cmd.wings_off
            tux.cmd.wings_on
            tux.cmd.wings_on_free
    """

    #--------------------------------------------------------------------------
    # Constructor of class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        """
        Constructor of class
        """
        self.parent=parent
        self.last_ack=ACK_CMD_OK
        self.no_ack=False

    #--------------------------------------------------------------------------
    # SYSTEM
    #--------------------------------------------------------------------------
    def cmd_ack(self):
        """
        Not a user function
        """
        # create a condition mutex
        cond_lock_mutex = threading.Condition(threading.Lock())
        # create a list of frames to match
        data_to_match_list = []
        # create and insert a frame to match
        data_to_match = (SOURCE_TUX,SS_DEFAULT,DATA_TP_ACK_CMD, \
                999,999,999,999,999,999,999,999,999,999,999,999,999)
        data_to_match_list.append(data_to_match)
        # create empty frame returned
        returned_data = []
        # insert theses settings in the lock list
        self.parent._insert_lock_in_list(data_to_match_list,cond_lock_mutex, \
                returned_data)
        # wait the lock has unblocked. With a time-out
        cond_lock_mutex.acquire()
        cond_lock_mutex.wait(2)
        cond_lock_mutex.release()
        # returns
        if len(returned_data) == 0:
            return ACK_CMD_TIMEOUT
        else:
            return ord(returned_data[0][4])

    #--------------------------------------------------------------------------
    # Send a structured command to tux
    #--------------------------------------------------------------------------
    def structured(self,fct,cmd,param1,param2,param3):
        """
        Send a structured command to tux

            Parameters:
            "fct" as integer        : function of tux
            "cmd" as integer        : command for this function
            "param1" as integer     : parameter 1 for this command
            "param2" as integer     : parameter 2 for this command
            "param3" as integer     : parameter 3 for this command

            Return a ACK as integer

            Example:
            >>> tux.cmd.structured(TUX_CMD_STRUCT_EYES,TUX_CMD_STRUCT_SUB_ON
            ,count,0,0)
        """
        if not self.parent.daemon.connected:
            return 2
        data=(DEST_TUX,SD_DEFAULT,DATA_TP_CMD,SUBDATA_TP_STRUCT, \
                int(fct),int(cmd),int(param1),int(param2),int(param3),0,0,0,0,0,0,0)
        self.parent._sock_send_frame("".join( [chr(x) for x in data] ))
        if self.no_ack:
            return 2
        else:
            return self.cmd_ack()

    #--------------------------------------------------------------------------
    # Send a raw command to tux
    #--------------------------------------------------------------------------
    def raw(self,cmd,param1,param2,param3):
        """
        Send a raw command to tux

            Parameters:
            "cmd" as integer        : command
            "param1" as integer     : parameter 1 of these command
            "param2" as integer     : parameter 2 of these command
            "param3" as integer     : parameter 3 of these command

            Return a ACK if it's required

            Example:
            >>> tux.cmd.raw(BLINK_EYES_CMD,4,0,0)
        """
        if not self.parent.daemon.connected:
            return 2
        data=(DEST_TUX,SD_DEFAULT,DATA_TP_CMD,SUBDATA_TP_RAW, \
                cmd,param1,param2,param3,0,0,0,0,0,0,0,0)
        self.parent._sock_send_frame("".join( [chr(x) for x in data] ))
        if self.no_ack:
            return 2
        else:
            return self.cmd_ack()

    #--------------------------------------------------------------------------
    # Send a command to tux for moving the eyes
    #--------------------------------------------------------------------------
    def eyes_on(self,count=1):
        """
        Send a command to tux for moving the eyes

            Parameters:
            "count" as integer      : Number of movements
                                      (default = 1)

            Example:
            >>> tux.cmd.eyes_on()
            >>> tux.cmd.eyes_on(2)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_EYES, \
                TUX_CMD_STRUCT_SUB_ON,count,0,0)
        self.parent.event.wait_status(DATAS_STATUS_EYES_POSITION_COUNTER, \
                0,(0.3*count))

    #--------------------------------------------------------------------------
    # Send a command to tux for opening the eyes
    #--------------------------------------------------------------------------
    def eyes_open(self):
        """
        Send a command to tux for opening the eyes

            Example:
            >>> tux.cmd.eyes_open()
        """
        if self.parent.status.get_eyes_closed_position_switch()==0:
            self.eyes_on()

    #--------------------------------------------------------------------------
    # Send a command to tux for closing the eyes
    #--------------------------------------------------------------------------
    def eyes_close(self):
        """
        Send a command to tux for closing the eyes

            Example:
            >>> tux.cmd.eyes_close()
        """
        if self.parent.status.get_eyes_closed_position_switch()==1:
            self.eyes_on()

    #--------------------------------------------------------------------------
    # Send a command to tux for moving the eyes in free mode
    #--------------------------------------------------------------------------
    def eyes_on_free(self,count=1):
        """
        Send a command to tux for moving the eyes in free mode

            Parameters:
            "count" as integer      : number of movements
                                      (default = 1)

            Example:
            >>> tux.cmd.eyes_on_free()
            >>> tux.cmd.eyes_on_free(2)
        """
        t=threading.Thread(target=self.eyes_on,args=(count,))
        t.setName('cmd.eyes_on')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Send a command to tux for stopping the eyes movement
    #--------------------------------------------------------------------------
    def eyes_off(self):
        """
        Send a command to tux for stopping the eyes movement

            Example:
            >>> tux.cmd.eyes_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_EYES, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for moving the mouth
    #--------------------------------------------------------------------------
    def mouth_on(self,count=1):
        """
        Send a command to tux for moving the mouth

            Parameters:
            "count" as integer      : number of movements
                                      (default = 1)

            Example:
            >>> tux.cmd.mouth_on()
            >>> tux.cmd.mouth_on(2)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_MOUTH, \
                TUX_CMD_STRUCT_SUB_ON,count,0,0)
        self.parent.event.wait_status(DATAS_STATUS_MOUTH_POSITION_COUNTER, \
                0,(0.3*count))

    #--------------------------------------------------------------------------
    # Send a command to tux for moving the mouth in free mode
    #--------------------------------------------------------------------------
    def mouth_on_free(self,count=1):
        """
        Send a command to tux for moving the mouth in free mode

            Parameters:
            "count" as integer      : number of movements
                                      (default = 1)

            Example:
            >>> tux.cmd.mouth_on_free()
            >>> tux.cmd.mouth_on_free(2)
        """
        t=threading.Thread(target=self.mouth_on,args=(count,))
        t.setName('cmd.mouth_on')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Send a command to tux for opening the mouth
    #--------------------------------------------------------------------------
    def mouth_open(self):
        """
        Send a command to tux for opening the mouth

            Example:
            >>> tux.cmd.mouth_open()
        """
        if self.parent.status.get_mouth_open_position()==1:
            self.mouth_on()

    #--------------------------------------------------------------------------
    # Send a command to tux for closing the mouth
    #--------------------------------------------------------------------------
    def mouth_close(self):
        """
        Send a command to tux for closing the mouth

            Example:
            >>> tux.cmd.mouth_close()
        """
        if self.parent.status.get_mouth_open_position()==0:
            self.mouth_on()

    #--------------------------------------------------------------------------
    # Send a command to tux for stopping the mouth movement
    #--------------------------------------------------------------------------
    def mouth_off(self):
        """
        Send a command to tux for stopping the mouth movement

            Example:
            >>> tux.cmd.mouth_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_MOUTH, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for moving the wings
    #--------------------------------------------------------------------------
    def wings_on(self,count=1,speed=5):
        """
        Send a command to tux for moving the wings

            Parameters:
            "count" as integer      : number of movements
                                      (default = 1)
            "speed" as integer      : speed of the movement(1-5)
                                      (default = 5)

            Example:
            >>> tux.cmd.wings_on()
            >>> tux.cmd.wings_on(2)     (2 movements)
            >>> tux.cmd.wings_on(2,5)   (2 movements and speed=5)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_WINGS, \
                TUX_CMD_STRUCT_SUB_ON,count,speed,0)
        self.parent.event.wait_status(DATAS_STATUS_WINGS_POSITION_COUNTER, \
                0,(0.6*count))
                
    #--------------------------------------------------------------------------
    # Send a command to tux for lowering the wings
    #--------------------------------------------------------------------------
    def wings_down(self):
        """
        Send a command to tux for lowering the wings

            Example:
            >>> tux.cmd.wings_down()
        """
        self.last_ack = self.raw(0x3A, 0, 0, 0)
                
    #--------------------------------------------------------------------------
    # Send a command to tux for raising the wings
    #--------------------------------------------------------------------------
    def wings_up(self):
        """
        Send a command to tux for raising the wings

            Example:
            >>> tux.cmd.wings_up()
        """
        self.last_ack = self.raw(0x39, 0, 0, 0)
                
    #--------------------------------------------------------------------------
    # Send a command to tux for moving the wings in free mode
    #--------------------------------------------------------------------------
    def wings_on_free(self,count=1,speed=5):
        """
        Send a command to tux for moving the wings in free mode

            Parameters:
            "count" as integer      : number of movements
                                      (default = 1)
            "speed" as integer      : speed of the movement(1..5)
                                      (default = 5)

            Example:
            >>> tux.cmd.wings_on_free()
            >>> tux.cmd.wings_on_free(2)     (2 movements)
            >>> tux.cmd.wings_on_free(2,5)   (2 movements and speed=5)
        """
        t=threading.Thread(target=self.wings_on,args=(count,speed,))
        t.setName('cmd.wings_on')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Send a command to tux for stopping the wings movement
    #--------------------------------------------------------------------------
    def wings_off(self):
        """
        Send a command to tux for stopping the wings movement

            Example:
            >>> tux.cmd.wings_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_WINGS, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux to spin to the left
    #--------------------------------------------------------------------------
    def spinl_on(self,count=4,speed=5):
        """
        Send a command to tux to spin to the left

            Parameters:
            "count" as integer      : number of quarter turns
                                      (default = 4)
            "speed" as integer      : speed of the movement(1..5)
                                      (default = 5)

            Example:
            >>> tux.cmd.spinl_on()
            >>> tux.cmd.spinl_on(2)     (count = 2)
            >>> tux.cmd.spinl_on(2,5)   (count = 2 and speed = 5)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SPINL, \
                TUX_CMD_STRUCT_SUB_ON,count,speed,0)
        self.parent.event.wait_status(DATAS_STATUS_SPIN_POSITION_COUNTER, \
                0,(0.5*count))

    #--------------------------------------------------------------------------
    # Send a command to tux to spin to the left in free mode
    #--------------------------------------------------------------------------
    def spinl_on_free(self,count=4,speed=5):
        """
        Send a command to tux to spin to the left in free mode

            Parameters:
            "count" as integer      : number of quarter turns
                                      (default = 4)
            "speed" as integer      : speed of the movement(1..5)
                                      (default = 5)

            Example:
            >>> tux.cmd.spinl_on_free()
            >>> tux.cmd.spinl_on_free(2)     (count = 2)
            >>> tux.cmd.spinl_on_free(2,5)   (count = 2 and speed = 5)
        """
        t=threading.Thread(target=self.spinl_on,args=(count,speed,))
        t.setName('cmd.spinl_on')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Send a command to tux for stopping the spinning movement
    #--------------------------------------------------------------------------
    def spinl_off(self):
        """
        Send a command to tux for stopping the spinning movement

            Example:
            >>> tux.cmd.spinl_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SPINL, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux to spin to the right
    #--------------------------------------------------------------------------
    def spinr_on(self,count=4,speed=5):
        """
        Send a command to tux to spin to the right

            Parameters:
            "count" as integer      : number of quarter turns
                                      (default = 4)
            "speed" as integer      : speed of the movement(1..5)
                                      (default = 5)

            Example:
            >>> tux.cmd.spinr_on()
            >>> tux.cmd.spinr_on(2)     (count = 2)
            >>> tux.cmd.spinr_on(2,5)   (count = 2 and speed = 5)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SPINR, \
                TUX_CMD_STRUCT_SUB_ON,count,speed,0)
        self.parent.event.wait_status(DATAS_STATUS_SPIN_POSITION_COUNTER,0, \
                (0.5*count))

    #--------------------------------------------------------------------------
    # Send a command to tux to spin to the right in free mode
    #--------------------------------------------------------------------------
    def spinr_on_free(self,count=4,speed=5):
        """
        Send a command to tux to spin to the right in free mode

            Parameters:
            "count" as integer      : number of quarter turns
                                      (default = 4)
            "speed" as integer      : speed of the movement(1..5)
                                      (default = 5)

            Example:
            >>> tux.cmd.spinr_on_free()
            >>> tux.cmd.spinr_on_free(2)     (count = 2)
            >>> tux.cmd.spinr_on_free(2,5)   (count = 2 and speed = 5)
        """
        t=threading.Thread(target=self.spinr_on,args=(count,speed,))
        t.setName('cmd.spinr_on')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Send a command to tux for stopping the spinning movement
    #--------------------------------------------------------------------------
    def spinr_off(self):
        """
        Send a command to tux for stopping the spinning movement

            Example:
            >>> tux.cmd.spinr_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SPINR, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the IR on
    #--------------------------------------------------------------------------
    def ir_on(self):
        """
        Send a command to tux for turning the IR on

            Example:
            >>> tux.cmd.ir_on()
        """
        ACK=self.structured(TUX_CMD_STRUCT_IR,TUX_CMD_STRUCT_SUB_ON,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the IR off
    #--------------------------------------------------------------------------
    def ir_off(self):
        """
        Send a command to tux for turning the IR off

            Example:
            >>> tux.cmd.ir_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_IR, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for sending an IR code
    #--------------------------------------------------------------------------
    def ir_send(self,address,command):
        """
        Send a command to tux for sending an IR code

            Parameters:
            "address" as integer        : RC5 address
            "command" as integer        : RC5 command

            Example:
            >>> tux.cmd.ir_send(1,1)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_IR, \
                TUX_CMD_STRUCT_SUB_SEND,address,command,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the leds on
    #--------------------------------------------------------------------------
    def leds_on(self):
        """
        Send a command to tux for turning the leds on

            Example:
            >>> tux.cmd.leds_on()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_LEDS, \
                TUX_CMD_STRUCT_SUB_ON,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for blinking the leds
    #--------------------------------------------------------------------------
    def leds_blink(self,count,delay):
        """
        Send a command to tux for blinking the leds

            Parameters:
            "count" as integer      : number of blink(0..255)
            "delay" as integer      : delay between 2 states (u=4msec)

            Example:
            >>> tux.cmd.leds_blink(10,25)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_LEDS, \
                TUX_CMD_STRUCT_SUB_BLINK,count,delay,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the leds off
    #--------------------------------------------------------------------------
    def leds_off(self):
        """
        Send a command to tux for turning the leds off

            Example:
            >>> tux.cmd.leds_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_LEDS, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the leds on during a specified time
    #--------------------------------------------------------------------------
    def leds_during(self,seconds):
        """
        Send a command to tux for turning the leds on during a specified time

            Parameters:
            "seconds" as float      : time to wait in seconds

            Example:
            >>> tux.cmd.leds_during(2.5)
        """
        self.leds_on()
        time.sleep(seconds)
        self.leds_off()

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the leds on during a specified time
    # in free mode
    #--------------------------------------------------------------------------
    def leds_during_free(self,seconds):
        """
        Send a command to tux for turning the leds on during a specified time
        in free mode

            Parameters:
            "seconds" as float      : time to wait in seconds

            Example:
            >>> tux.cmd.leds_during_free(2.5)
        """
        t=threading.Thread(target=self.leds_during,args=(seconds,))
        t.setName('cmd.leds_during')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the left led on
    #--------------------------------------------------------------------------
    def ledl_on(self):
        """
        Send a command to tux for turning the left led on

            Example:
            >>> tux.cmd.ledl_on()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_LEDL, \
                TUX_CMD_STRUCT_SUB_ON,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the left led off
    #--------------------------------------------------------------------------
    def ledl_off(self):
        """
        Send a command to tux for turning the left led off

            Example:
            >>> tux.cmd.ledl_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_LEDL, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the left led on during a specified time
    #--------------------------------------------------------------------------
    def ledl_during(self,seconds):
        """
        Send a command to tux for turning the left led on during a specified
        time

            Parameters:
            "seconds" as float      : time to wait in seconds

            Example:
            >>> tux.cmd.ledl_during(2.5)
        """
        self.ledl_on()
        time.sleep(seconds)
        self.ledl_off()

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the left led on during a specified
    # time in free mode
    #--------------------------------------------------------------------------
    def ledl_during_free(self,seconds):
        """
        Send a command to tux for turning the left led on during a specified
        time in free mode

            Parameters:
            "seconds" as float      : time to wait in seconds

            Example:
            >>> tux.cmd.ledl_during_free(2.5)
        """
        t=threading.Thread(target=self.ledl_during,args=(seconds,))
        t.setName('cmd.ledl_during')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the right led on
    #--------------------------------------------------------------------------
    def ledr_on(self):
        """
        Send a command to tux for turning the right led on

            Example:
            >>> tux.cmd.ledr_on()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_LEDR, \
                TUX_CMD_STRUCT_SUB_ON,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the right led off
    #--------------------------------------------------------------------------
    def ledr_off(self):
        """
        Send a command to tux for turning the right led off

            Example:
            >>> tux.cmd.ledr_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_LEDR, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the right led on during a specified
    # time
    #--------------------------------------------------------------------------
    def ledr_during(self,seconds):
        """
        Send a command to tux for turning the right led on during a specified
        time

            Parameters:
            "seconds" as float      : time to wait in seconds

            Example:
            >>> tux.cmd.ledr_during(2.5)
        """
        self.ledr_on()
        time.sleep(seconds)
        self.ledr_off()

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the right led on during a specified
    # time in free mode
    #--------------------------------------------------------------------------
    def ledr_during_free(self,seconds):
        """
        Send a command to tux for turning the right led on during a specified
        time in free mode

            Parameters:
            "seconds" as float      : time to wait in seconds

            Example:
            >>> tux.cmd.ledr_during_free(2.5)
        """
        t=threading.Thread(target=self.ledr_during,args=(seconds,))
        t.setName('cmd.ledr_during')
        t.start()
        self.parent.daemon.free_thread_list.append(t)

    #--------------------------------------------------------------------------
    # Send a command to tux for playing a sound from the flash memory
    #--------------------------------------------------------------------------
    def sound_play(self,index,volume=0):
        """
        Send a command to tux for playing a sound from the flash
        memory

            Parameters:
            "index" as integer      : index of the sound
            "volume" as integer     : volume of the sound(0..7,0=max)
                                      (default = 0)

            Example:
            >>> tux.cmd.sound_play(1)
            >>> tux.cmd.sound_play(1,0)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SOUND, \
                TUX_CMD_STRUCT_SUB_PLAY,index,volume,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for storing a sound collection in the memory flash
    #--------------------------------------------------------------------------
    def sound_storing(self,number):
        """
        Send a command to tux for storing a sound collection in the
        memory flash

            Parameters:
            "number" as integer     : number of sounds to be stored

            Example:
            >>> tux.cmd.sound_storing(10)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SOUND, \
                TUX_CMD_STRUCT_SUB_STORING,number,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for indexing the sound
    #--------------------------------------------------------------------------
    def sound_store_index(self,highAdd,middleAdd,lowAdd):
        """
        Send a command to tux for indexing the sound

            Parameters:
            "highAdd" as integer    : high byte address of the sound
            "middleAdd" as integer  : middle byte address of the sound
            "lowAdd" as integer     : low byte address of the sound

            Example:
            >>> tux.cmd.sound_store_index(0x00,0x04,0x00)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SOUND, \
                TUX_CMD_STRUCT_SUB_STORE_INDEX,highAdd,middleAdd,lowAdd)

    #--------------------------------------------------------------------------
    # Send a command to tux for testing the sound in tux
    #--------------------------------------------------------------------------
    def sound_test(self):
        """
        Send a command to tux for testing the sound in tux

            Example:
            >>> tux.cmd.sound_test()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SOUND, \
                TUX_CMD_STRUCT_SUB_TEST,0,0,0)
                
    #--------------------------------------------------------------------------
    # test
    #--------------------------------------------------------------------------
    def sound_on(self):
        self.last_ack = self.raw(0x92, 0, 0, 0)
        
    def sound_off(self):
        self.last_ack = self.raw(0x92, 1, 0, 0)

    #--------------------------------------------------------------------------
    # Send a command to tux for the "ping-pong" test
    #--------------------------------------------------------------------------
    def ping(self,count=200):
        """
        Send a command to tux for the "ping-pong" test

            Parameters:
            "count" as integer      : number of pong requested
                                      (default = 200)

            Example:
            >>> tux.cmd.ping()
            >>> tux.cmd.ping(200)
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_PING,0,count,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the sleep mode on
    #--------------------------------------------------------------------------
    def sleep_on(self):
        """
        Send a command to tux for turning the sleep mode on

            Example:
            >>> tux.cmd.sleep_on()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SLEEP, \
                TUX_CMD_STRUCT_SUB_ON,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for turning the sleep mode off
    #--------------------------------------------------------------------------
    def sleep_off(self):
        """
        Send a command to tux for turning the sleep mode off

            Example:
            >>> tux.cmd.sleep_off()
        """
        self.last_ack=self.structured(TUX_CMD_STRUCT_SLEEP, \
                TUX_CMD_STRUCT_SUB_OFF,0,0,0)

    #--------------------------------------------------------------------------
    # Send a command to tux for selecting the "general" audio channel in
    # the dongle
    #--------------------------------------------------------------------------
    def audio_channel_general(self):
        """
        Send a command to tux for selecting the "general" audio channel in
        the dongle

            Example:
            >>> tux.cmd.audio_channel_general()
        """
        self.no_ack=True
        self.last_ack=self.structured(TUX_CMD_STRUCT_AUDIO_CHANNEL, \
                TUX_CMD_STRUCT_SUB_CH_GENERAL,0,0,0)
        self.no_ack=False

    #--------------------------------------------------------------------------
    # Send a command to tux for selecting the "TTS" audio channel in the dongle
    #--------------------------------------------------------------------------
    def audio_channel_tts(self):
        """
        Send a command to tux for selecting the "TTS" audio channel in
        the dongle

            Example:
            >>> tux.cmd.audio_channel_tts()
        """
        self.no_ack=True
        self.last_ack=self.structured(TUX_CMD_STRUCT_AUDIO_CHANNEL, \
                TUX_CMD_STRUCT_SUB_CH_TTS,0,0,0)
        self.no_ack=False

#==============================================================================
# TUXTCPCommunicator - status - class
#==============================================================================
class TUXStatus(object):
    """
    Class which manages the request of a status

        Global variables of this class:
        "rf_connected" as boolean   : State of the droid/dongle connection

        Functions list for the users:
            tux.status.charger_state
            tux.status.flash_status
            tux.status.eyes_closed
            tux.status.eyes_counter
            tux.status.eyes_motor
            tux.status.eyes_opened
            tux.status.get
            tux.status.head_bt
            tux.status.ir_led
            tux.status.ir_signal
            tux.status.light_level
            tux.status.battery_level
            tux.status.lled
            tux.status.lwing_bt
            tux.status.mouth_closed
            tux.status.mouth_counter
            tux.status.mouth_motor
            tux.status.mouth_opened
            tux.status.power_plug
            tux.status.rf_state
            tux.status.rled
            tux.status.rwing_bt
            tux.status.sounds_count
            tux.status.sound_muted
            tux.status.spin_backward
            tux.status.spin_bt
            tux.status.spin_counter
            tux.status.wings_backward
            tux.status.wings_counter
            tux.status.wings_motor
            tux.status.wings_forward
            tux.status.wings_bt
            tux.status.get_wings_position_switch
            tux.status.to_string
    """

    #--------------------------------------------------------------------------
    # Constructor of the class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        """
        Constructor of the class
        """
        self.parent=parent
        self.rf_connected=False

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _loop_light_level(self):
        """
        Not a user function
        """
        while self.parent.daemon.connected:
            if self.parent.event.on_light_level!=None:
                self.parent.event.on_light_level(self.get_light_level())
            self.parent.sys.wait(1)

    #--------------------------------------------------------------------------
    # Convert the current raw statuses to an explicit string
    #--------------------------------------------------------------------------
    def to_string(self,frame):
        """
        Convert the current raw statuses to an explicit string

            Parameters:
            "frame" as tuple of char    : raw statuses

            Return a string

            Example:
            >>> print tux.status.to_string()
        """
        value_onoff=0
        value_10=1
        value_8b=2
        value_16b=3
        value_np=4
        value_offon=5

        value_type=value_onoff
        line=""
        status=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
        self.parent.tcp_mutex.acquire()
        for i, data in enumerate(frame):
            status[i]=ord(data)
        self.parent.tcp_mutex.release()
        # -- Tux status
        if status[4]==DATAS_STATUS_WINGS_MOTOR_BACKWARD:
            line=line+"Wings motor backward->"
        if status[4]==DATAS_STATUS_SPIN_MOTOR_BACKWARD:
            line=line+"Spin motor backward->"
        if status[4]==DATAS_STATUS_SPIN_MOTOR_FORWARD:
            line=line+"Spin motor forward->"
        if status[4]==DATAS_STATUS_MOUTH_OPEN_POSITION:
            line=line+"Mouth open position->"
        if status[4]==DATAS_STATUS_MOUTH_CLOSED_POSITION:
            line=line+"Mouth closed position->"
        if status[4]==DATAS_STATUS_HEAD_PUSH_POSITION:
            line=line+"Head push position->"
        if status[4]==DATAS_STATUS_CHARGER_INHIBIT_SIGNAL:
            line=line+"Charger inhibit signal->"
        if status[4]==DATAS_STATUS_WINGS_POSITION_SWITCH:
            line=line+"Wings position switch->"
        if status[4]==DATAS_STATUS_MOTOR_FOR_WINGS:
            line=line+"Motor for wings->"
        if status[4]==DATAS_STATUS_LEFT_BLUE_LED:
            line=line+"Left blue led->"
        if status[4]==DATAS_STATUS_HEAD_MOTOR_FOR_MOUTH:
            line=line+"Head motor for beack->"
        if status[4]==DATAS_STATUS_HEAD_MOTOR_FOR_EYES:
            line=line+"Head motor for eyes->"
        if status[4]==DATAS_STATUS_IR_RECEIVER_SIGNAL:
            line=line+"Ir receiver signal->"
        if status[4]==DATAS_STATUS_SPIN_POSITION_SWITCH:
            line=line+"Spin position switch->"
        if status[4]==DATAS_STATUS_WINGS_MOTOR_FORWARD:
            line=line+"Wings motor forward->"
        if status[4]==DATAS_STATUS_IR_LED:
            line=line+"IR led->"
        if status[4]==DATAS_STATUS_EYES_OPEN_POSITION_SWITCH:
            line=line+"Eyes open position switch->"
        if status[4]==DATAS_STATUS_EYES_CLOSED_POSITION_SWITCH:
            line=line+"Eyes closed position switch->"
        if status[4]==DATAS_STATUS_LEFT_WING_PUSH:
            line=line+"Left wing push->"
        if status[4]==DATAS_STATUS_RIGHT_WING_PUSH:
            line=line+"Right wing push->"
        if status[4]==DATAS_STATUS_POWER_PLUG_SWITCH:
            line=line+"Power plug switch->"
        if status[4]==DATAS_STATUS_HEAD_PUSH_SWITCH:
            line=line+"Head push switch->"
        if status[4]==DATAS_STATUS_CHARGER_LED_STATUS:
            line=line+"Charger led status->"
        if status[4]==DATAS_STATUS_MUTE_STATUS:
            line=line+"Audio mute->"
        if status[4]==DATAS_STATUS_LIGHT_LEVEL:
            line=line+"Light level->"
            value_type=value_16b
        if status[4]==DATAS_STATUS_BATTERY:
            line=line+"Battery level->"
            value_type=value_16b
        if status[4]==DATAS_STATUS_EYES_POSITION_COUNTER:
            line=line+"Eyes position counter->"
            value_type=value_8b
        if status[4]==DATAS_STATUS_MOUTH_POSITION_COUNTER:
            line=line+"Mouth position counter->"
            value_type=value_8b
        if status[4]==DATAS_STATUS_WINGS_POSITION_COUNTER:
            line=line+"Wings position counter->"
            value_type=value_8b
        if status[4]==DATAS_STATUS_SPIN_POSITION_COUNTER:
            line=line+"Spin position counter->"
            value_type=value_8b
        if status[4]==DATAS_STATUS_RIGHT_BLUE_LED:
            line=line+"Right blue led->"
        if status[4]==DATAS_STATUS_RF_CONNECTED:
            line=line+"RF connected->"
        if status[4]==DATAS_STATUS_IR_CODE:
            line=line+"IR code->%s"%remote_bt_name[status[5]]
            value_type=value_np
        if status[4]==DATAS_STATUS_SOUND_COUNT:
            line=line+"Flash sounds count->"
        if status[4]==DATAS_STATUS_PONG:
            line=line+"Pong-> Received : %d Remaining : %d Average : %.0f %s" \
                    %(status[6],status[5],((status[6]*100)/(200-status[5])),'%')
            value_type=value_np
        #-- Write value
        if value_type==value_onoff:
            if status[5]==0: line=line+"off"
            else: line=line+"on"
        if value_type==value_offon:
            if status[5]==0: line=line+"off"
            else: line=line+"on"
        if value_type==value_8b:
            line=line+"%d"%status[5]
        if value_type==value_16b:
            line=line+"%d"%((status[5]*256)+status[6])
        return line

    #--------------------------------------------------------------------------
    # wait a specified response status
    #--------------------------------------------------------------------------
    def rsp_status(self, DATA_STATUS, timeout=2):
        """
        Not a user function
        """
        # create a condition mutex
        cond_lock_mutex = threading.Condition(threading.Lock())
        # create a list of frames to match
        data_to_match_list = []
        # create and insert a frame to match
        data_to_match = (SOURCE_TUX,SS_DEFAULT,DATA_TP_RSP,999,DATA_STATUS, \
                999,999,999,999,999,999,999,999,999,999,999)
        data_to_match_list.append(data_to_match)
        # create empty frame returned
        returned_data = []
        # insert theses settings in the lock list
        self.parent._insert_lock_in_list(data_to_match_list,cond_lock_mutex,
                returned_data)
        # wait the lock has unblocked. With a time-out
        cond_lock_mutex.acquire()
        cond_lock_mutex.wait(timeout)
        cond_lock_mutex.release()
        # returns
        if len(returned_data) == 0:
            return None
        else:
            return returned_data[0]

    #--------------------------------------------------------------------------
    # Get a specified status
    #--------------------------------------------------------------------------
    def get(self,DATA_STATUS):
        """
        Get a specified status

            Parameters:
            "DATA_STATUS" as integer    : desired status

            Return a boolean
            (True if the status arrives before 2 seconds)
            (The raw of the status response is in tux.tcp_data)

            Example:
            >>> tux.status.get(DATAS_STATUS_WINGS_MOTOR_BACKWARD)
        """
        if not self.parent.daemon.connected:
            return 0
        data=(DEST_TUX,SD_DEFAULT,DATA_TP_REQ,SUBDATA_TP_STATUS,DATA_STATUS, \
                0,0,0,0,0,0,0,0,0,0,0)
        self.parent._sock_send_frame("".join( [chr(x) for x in data] ))
        return self.rsp_status(DATA_STATUS)

    #--------------------------------------------------------------------------
    # Get a specified status ( one value )
    #--------------------------------------------------------------------------
    def get_one_status(self,DATA_STATUS):
        """
        Not a user function
        """
        if not self.parent.daemon.connected:
            return 0
        frame = self.get(DATA_STATUS)
        try:
            if len(frame) > 0:
                return ord(frame[5])
            else:
                return 0
        except:
            return 0

    #--------------------------------------------------------------------------
    # Get the last state of wings motor backward status
    #--------------------------------------------------------------------------
    def get_wings_motor_backward(self):
        """
        deprecated : see 'tux.status.wings_backward'
        """
        return self.wings_backward()

    def wings_backward(self):
        """
        Get the last state of "wings motor backward" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.wings_backward()
        """
        return self.get_one_status(DATAS_STATUS_WINGS_MOTOR_BACKWARD)

    #--------------------------------------------------------------------------
    # Get the last state of spin motor backward status
    #--------------------------------------------------------------------------
    def get_spin_motor_backward(self):
        """
        deprecated : see 'tux.status.spin_backward'
        """
        return self.spin_backward()
    def spin_backward(self):
        """
        Get the last state of "spin motor backward" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.spin_backward()
        """
        return self.get_one_status(DATAS_STATUS_SPIN_MOTOR_BACKWARD)

    #--------------------------------------------------------------------------
    # Get the last state of spin motor forward status
    #--------------------------------------------------------------------------
    def get_spin_motor_forward(self):
        """
        deprecated : see 'tux.status.spin_forward'
        """
        return self.spin_forward()
    def spin_backward(self):
        """
        Get the last state of "spin motor forward" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.spin_forward()
        """
        return self.get_one_status(DATAS_STATUS_SPIN_MOTOR_FORWARD)

    #--------------------------------------------------------------------------
    # Get the last state of mouth open position status
    #--------------------------------------------------------------------------
    def get_mouth_open_position(self):
        """
        Deprecated : see 'tux.status.mouth_opened'
        """
        return self.mouth_opened()
    def mouth_opened(self):
        """
        Get the last state of "mouth open position" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.mouth_opened()
        """
        return self.get_one_status(DATAS_STATUS_MOUTH_OPEN_POSITION)

    #--------------------------------------------------------------------------
    # Get the last state of mouth closed position status
    #--------------------------------------------------------------------------
    def get_mouth_closed_position(self):
        """
        Deprecated : see 'tux.status.mouth_closed'
        """
        return self.mouth_closed()
    def mouth_closed(self):
        """
        Get the last state of "mouth closed position" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.mouth_closed()
        """
        return self.get_one_status(DATAS_STATUS_MOUTH_CLOSED_POSITION)

    #--------------------------------------------------------------------------
    # Get the last state of head push position status
    #--------------------------------------------------------------------------
    def get_head_push_position(self):
        """
        Deprecated : see 'tux.status.head_bt'
        """
        return self.head_bt()
    def head_bt(self):
        """
        Get the status of the head button

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.head_bt()
        """
        return self.get_one_status(DATAS_STATUS_HEAD_PUSH_SWITCH)

    #--------------------------------------------------------------------------
    # Get the last state of charger inhibit signal status
    #--------------------------------------------------------------------------
    def get_charger_inhibit_signal(self):
        """
        Deprecated : see 'tux.status.charger_state'
        """
        return self.charger_state()
    def charger_state(self):
        """
        Get the status of the charger

            Return 1 for charging and 0 for not charging

            Example:
            >>>var = tux.status.charger_state()
        """
        return self.get_one_status(DATAS_STATUS_CHARGER_LED_STATUS)

    #--------------------------------------------------------------------------
    # Get the last state of wings position switch status
    #--------------------------------------------------------------------------
    def get_wings_position_switch(self):
        """
        Deprecated : see 'tux.status.wings_bt'
        """
        return self.wings_bt()
    def wings_bt(self):
        """
        Get the last state of "wings position switch" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.wings_bt()
        """
        return self.get_one_status(DATAS_STATUS_WINGS_POSITION_SWITCH)

    #--------------------------------------------------------------------------
    # Get the last state of motor for wings status
    #--------------------------------------------------------------------------
    def get_motor_for_wings(self):
        """
        Deprecated : see 'tux.status.wings_motor'
        """
        return self.wings_motor()
    def wings_motor(self):
        """
        Get the last state of "motor for wings" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.wings_motor()
        """
        return self.get_one_status(DATAS_STATUS_MOTOR_FOR_WINGS)

    #--------------------------------------------------------------------------
    # Get the last state of left blue led status
    #--------------------------------------------------------------------------
    def get_left_blue_led(self):
        """
        Deprecated : see 'tux.status.lled'
        """
        return self.lled()
    def lled(self):
        """
        Get the state of the left blue led

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.lled()
        """
        return self.get_one_status(DATAS_STATUS_LEFT_BLUE_LED)

    #--------------------------------------------------------------------------
    # Get the last state of right blue led status
    #--------------------------------------------------------------------------
    def get_right_blue_led(self):
        """
        Deprecated : see 'tux.status.rled'
        """
        return self.rled()
    def rled(self):
        """
        Get the state of the right blue led

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.rled()
        """
        return self.get_one_status(DATAS_STATUS_RIGHT_BLUE_LED)

    #--------------------------------------------------------------------------
    # Get the last state of head motor for mouth status
    #--------------------------------------------------------------------------
    def get_head_motor_for_mouth(self):
        """
        Deprecated : see 'tux.status.mouth_motor'
        """
        return self.mouth_motor()
    def mouth_motor(self):
        """
        Get the last state of "head motor for mouth" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.mouth_motor()
        """
        return self.get_one_status(DATAS_STATUS_HEAD_MOTOR_FOR_MOUTH)

    #--------------------------------------------------------------------------
    # Get the last state of head motor for eyes status
    #--------------------------------------------------------------------------
    def get_head_motor_for_eyes(self):
        """
        Deprecated : see 'tux.status.eyes_motor'
        """
        return self.eyes_motor()
    def eyes_motor(self):
        """
        Get the last state of "head motor for eyes" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.eyes_motor()
        """
        return self.get_one_status(DATAS_STATUS_HEAD_MOTOR_FOR_EYES)

    #--------------------------------------------------------------------------
    # Get the last state of IR receiver signal status
    #--------------------------------------------------------------------------
    def get_ir_receiver_signal(self):
        """
        Deprecated : see 'tux.status.ir_signal'
        """
        return self.ir_signal()
    def ir_signal(self):
        """
        Get the last state of "IR receiver signal" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.ir_signal()
        """
        return self.get_one_status(DATAS_STATUS_IR_RECEIVER_SIGNAL)

    #--------------------------------------------------------------------------
    # Get the last state of spin position switch status
    #--------------------------------------------------------------------------
    def get_spin_position_switch(self):
        """
        Deprecated : see 'tux.status.spin_bt'
        """
        return self.spin_bt()
    def spin_bt(self):
        """
        Get the last state of "spin position switch" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.spin_bt()
        """
        return self.get_one_status(DATAS_STATUS_SPIN_POSITION_SWITCH)

    #--------------------------------------------------------------------------
    # Get the last state of wings motor forward status
    #--------------------------------------------------------------------------
    def get_wings_motor_forward(self):
        """
        Deprecated : see 'tux.status.wings_forward'
        """
        return self.wings_forward()
    def wings_forward(self):
        """
        Get the last state of "wings motor forward" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.wings_forward()
        """
        return self.get_one_status(DATAS_STATUS_WINGS_MOTOR_FORWARD)

    #--------------------------------------------------------------------------
    # Get the last state of IR led status
    #--------------------------------------------------------------------------
    def get_ir_led(self):
        """
        Deprecated : see 'tux.status.ir_led'
        """
        return self.ir_led()
    def ir_led(self):
        """
        Get the last state of "IR led" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.ir_led()
        """
        return self.get_one_status(DATAS_STATUS_IR_LED)

    #--------------------------------------------------------------------------
    # Get the last state of eyes open position switch status
    #--------------------------------------------------------------------------
    def get_eyes_open_position_switch(self):
        """
        Deprecated : see 'tux.status.eyes_opened'
        """
        return self.eyes_opened()
    def eyes_opened(self):
        """
        Get the last state of "eyes open position switch" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.eyes_opened()
        """
        return self.get_one_status(DATAS_STATUS_EYES_OPEN_POSITION_SWITCH)

    #--------------------------------------------------------------------------
    # Get the last state of eyes closed position switch status
    #--------------------------------------------------------------------------
    def get_eyes_closed_position_switch(self):
        """
        Deprecated : see 'tux.status.eyes_closed'
        """
        return self.eyes_closed()
    def eyes_closed(self):
        """
        Get the last state of "eyes closed position switch" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.eyes_closed()
        """
        return self.get_one_status(DATAS_STATUS_EYES_CLOSED_POSITION_SWITCH)

    #--------------------------------------------------------------------------
    # Get the last state of left wing push status
    #--------------------------------------------------------------------------
    def get_left_wing_push(self):
        """
        Deprecated : see 'tux.status.lwing_bt'
        """
        return self.lwing_bt()
    def lwing_bt(self):
        """
        Get the last state of "left wing push" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.lwing_bt()
        """
        return self.get_one_status(DATAS_STATUS_LEFT_WING_PUSH)

    #--------------------------------------------------------------------------
    # Get the last state of right wing push status
    #--------------------------------------------------------------------------
    def get_right_wing_push(self):
        """
        Deprecated : see 'tux.status.rwing_bt'
        """
        return self.rwing_bt()
    def rwing_bt(self):
        """
        Get the last state of "right wing push" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.rwing_bt()
        """
        return self.get_one_status(DATAS_STATUS_RIGHT_WING_PUSH)

    #--------------------------------------------------------------------------
    # Get the last state of power plug switch status
    #--------------------------------------------------------------------------
    def get_power_plug_switch(self):
        """
        Deprecated : see 'tux.status.power_plug'
        """
        return self.power_plug()
    def power_plug(self):
        """
        Get the last state of "power plug switch" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.power_plug()
        """
        return self.get_one_status(DATAS_STATUS_POWER_PLUG_SWITCH)

    #--------------------------------------------------------------------------
    # Get the last state of head push switch status
    #--------------------------------------------------------------------------
    def get_head_push_switch(self):
        """
        Deprecated : see 'tux.status.head_bt'
        """
        return self.head_bt()

    #--------------------------------------------------------------------------
    # Get the last state of tux mute sound status
    #--------------------------------------------------------------------------
    def get_tux_mute_sound(self):
        """
        Deprecated : see 'tux.status.sound_muted'
        """
        return self.sound_muted()
    def sound_muted(self):
        """
        Get the last state of "tux mute sound" status

            Return 1 for on and 0 for off

            Example:
            >>> var = tux.status.sound_muted()
        """
        return self.get_one_status(DATAS_STATUS_MUTE_STATUS)

    #--------------------------------------------------------------------------
    # Get the last state of light level status
    #--------------------------------------------------------------------------
    def get_light_level(self):
        """
        Deprecated : see 'tux.status.light_level'
        """
        return self.light_level()
    def light_level(self):
        """
        Get the last light level

            Return an integer (0..1024)

            Example:
            >>> var = tux.status.light_level()
        """
        if not self.parent.daemon.connected:
            return 0
        frame = self.get(DATAS_STATUS_LIGHT_LEVEL)
        try:
            if len(frame) > 0:
                return (ord(frame[5])*256)+ord(frame[6])
            else:
                return 0
        except:
            return 0

    #--------------------------------------------------------------------------
    # Get the last state of battery level status
    #--------------------------------------------------------------------------
    def battery_level(self):
        """
        Get the last battery level

            Return a tupple with the battery level and the status:
            (level, status)
                level: 0..1024
                status: True (valid battery level) or False (i.e. a motor was
                running during the measurement so it's not accurate)

            Example:
            >>> (level, valid) = tux.status.battery_level()
        """
        if not self.parent.daemon.connected:
            return 0
        frame = self.get(DATAS_STATUS_BATTERY)
        try:
            if len(frame) > 0:
                return ((ord(frame[5])*256)+ord(frame[6]),
                        bool(not ord(frame[7])))
            else:
                return 0
        except:
            return 0

    #--------------------------------------------------------------------------
    # Get the last state of sound status
    #--------------------------------------------------------------------------
    def flash_status(self):
        """
        Get the last sound flash status

            Return a tupple with the audio flash status:
            (play state, record state, sound number)
                play state : Return the sound number or 0 if no sound is played
                record state : Return the recording state
                sound number : Return the track which is recorded.

            Example:
            >>> (play_state, record_state, sound_number) = tux.status.flash_status()

        """
        if not self.parent.daemon.connected:
            return 0
        frame = self.get(0x26)
        try:
            if len(frame) > 0:
                return (ord(frame[5]), ord(frame[6]), ord(frame[7]))
            else:
                return 0
        except:
            return 0


    #--------------------------------------------------------------------------
    # Get the last state of eyes position counter status
    #--------------------------------------------------------------------------
    def get_eyes_position_counter(self):
        """
        Deprecated : see 'tux.status.eyes_counter'
        """
        return self.eyes_counter()
    def eyes_counter(self):
        """
        Get the number of remaining movements of the eyes

            Return an integer (0..255)

            Example:
            >>> var = tux.status.eyes_counter()
        """
        return self.get_one_status(DATAS_STATUS_EYES_POSITION_COUNTER)

    #--------------------------------------------------------------------------
    # Get the last state of mouth position counter status
    #--------------------------------------------------------------------------
    def get_mouth_position_counter(self):
        """
        Deprecated : see 'tux.status.mouth_counter'
        """
        return self.mouth_counter()
    def mouth_counter(self):
        """
        Get the number of remaining movements of the mouth

            Return an integer (0..255)

            Example:
            >>> var = tux.status.mouth_counter()
        """
        return self.get_one_status(DATAS_STATUS_MOUTH_POSITION_COUNTER)

    #--------------------------------------------------------------------------
    # Get the last state of wings position counter status
    #--------------------------------------------------------------------------
    def get_wings_position_counter(self):
        """
        Deprecated : see 'tux.status.wings_counter'
        """
        return self.wings_counter()
    def wings_counter(self):
        """
        Get the number of remaining movements of the wings

            Return an integer (0..255)

            Example:
            >>> var = tux.status.wings_counter()
        """
        return self.get_one_status(DATAS_STATUS_WINGS_POSITION_COUNTER)

    #--------------------------------------------------------------------------
    # Get the last state of spin position counter status
    #--------------------------------------------------------------------------
    def get_spin_position_counter(self):
        """
        Deprecated : see 'tux.status.spin_counter'
        """
        return self.spin_counter()
    def spin_counter(self):
        """
        Get the number of remaining movements of 'spinning'

            Return an integer (0..255)

            Example:
            >>> var = tux.status.spin_counter()
        """
        return self.get_one_status(DATAS_STATUS_SPIN_POSITION_COUNTER)

    #--------------------------------------------------------------------------
    # Get the last state of the RF status
    #--------------------------------------------------------------------------
    def get_RF_state(self):
        """
        Deprecated : see 'tux.status.rf_state'
        """
        return self.rf_state()
    def rf_state(self):
        """
        Get the last state of the RF status

            Return 1 for connected and 0 for disconnected

            Example:
            >>>var = tux.status.rf_state()
        """
        return self.get_one_status(DATAS_STATUS_RF_CONNECTED)

    #--------------------------------------------------------------------------
    # Get the number of sound in flash
    #--------------------------------------------------------------------------
    def get_sound_flash_count(self):
        """
        Deprecated : see 'tux.status.sounds_count'
        """
        return self.sounds_count()
    def sounds_count(self):
        """
        Get the number of sounds stored in the flash memory

            Return a integer (0..255)

            Example:
            >>> var = tux.status.sounds_count()
        """
        return self.get_one_status(DATAS_STATUS_SOUND_COUNT)

#==============================================================================
# TUXTCPCommunicator - daemon - class
#==============================================================================
class TUXdaemon(object):
    """
    Class which manages the daemon commands

        Global variables of this class:
        "connected" as boolean      : State of the connection to tuxd

        Functions list for users:
            tux.daemon.auto_connect
            tux.daemon.connect
            tux.daemon.disconnect
            tux.daemon.disconnect_client
            tux.daemon.get_client_count
            tux.daemon.get_client_name
            tux.daemon.get_my_client_id
            tux.daemon.get_version
            tux.daemon.kill
            tux.daemon.print_clients_name
            tux.daemon.set_my_client_name
    """
    #--------------------------------------------------------------------------
    # Constructor of class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        """
        Constructor of class
        """
        self.parent=parent
        self.con_thread_list=[]
        self.free_thread_list=[]
        self.last_ack=ACK_CMD_OK
        self.connected=False
        self.ac=False
        self.ac_address='localhost'
        self.ac_port=5000

    #--------------------------------------------------------------------------
    # Allow to connect the api to tuxd automatically
    #--------------------------------------------------------------------------
    def auto_connect(self,value,address='ndef',port=0):
        """
        Allow to connect the api to tuxd automatically

            Parameters:
            "value" as boolean      : turn on/off the auto_connect mode
            "address" as string     : Tcp/IP Host address
                                      (default = 'localhost')
            "port" as integer       : Tcp/IP Port number
                                      (default = 5000)

            Examples:
            >>> tux.daemon.auto_connect(True)
            >>> tux.daemon.auto_connect(True,'192.168.0.1')
            >>> tux.daemon.auto_connect(True,'192.168.0.1',5000)
        """
        self.ac=value
        if port!=0:
            self.ac_port=port
        if address!='ndef':
            self.ac_address=address

    #--------------------------------------------------------------------------
    # Not a user function
    #--------------------------------------------------------------------------
    def _tcp_threads_join(self):
        # Wait until the tcp threads has been released
        for con_thread in self.con_thread_list:
            if self.parent.print_debug_thread:
                print "'%s' has been released"%con_thread.getName()
            if con_thread.isAlive():
                con_thread.join()
        self.con_thread_list=[]

    #--------------------------------------------------------------------------
    # Not a user function
    #--------------------------------------------------------------------------
    def _loop_auto_connect(self):
        """
        Not a user function
        """
        last_connect_status=False
        while not self.parent.exit_flag:
            if self.ac:
                if not self.connected:
                    self.parent.print_warnings_mutex.acquire()
                    store=self.parent.print_warnings
                    self.parent.print_warnings=False
                    self.connect(self.ac_address,self.ac_port)
                    self.parent.print_warnings=store
                    self.parent.print_warnings_mutex.release()
            if self.connected!=last_connect_status:
                if self.connected:
                    self.parent.hw.alsa_devices_select(0)
                    if self.parent.print_warnings:
                        print "CONNECTED to tuxd"
                    if self.parent.event.on_connected!=None:
                        self.parent.event.on_connected()
                else:
                    if self.parent.print_warnings:
                        print "DISCONNECTED from tuxd"
                    self.parent.status.rf_connected = False
                    if self.parent.event.on_disconnected!=None:
                        self.parent.event.on_disconnected()
                    self._tcp_threads_join()
            last_connect_status=self.connected
            self.parent.sys.wait(0.1)

    #--------------------------------------------------------------------------
    # Connect object to tuxd
    #--------------------------------------------------------------------------
    def connect(self,address='localhost',port=5000):
        """
        Connect tux object to tuxd

            Parameters:
            "port" as integer       : Tcp/IP Port number
                                      (default = 5000)
            "address" as string     : Tcp/IP Host address
                                      (default = 'localhost')

            Examples:
            >>> tux.daemon.connect()
            >>> tux.daemon.connect('192.168.0.1')
            >>> tux.daemon.connect('192.168.0.1',5000)

            Comment:
            The variable "tux.daemon.connected" contains the result of
            this method
        """
        self.disconnect()
        self.connected=False
        self.parent.connected=False #deprecated
        self.parent.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.parent.sock.setblocking(1)
        try:
            self.parent.sock.connect((address,port))
        except socket.timeout:
            return False
        except socket.error:
            return False
        self.parent.sock.setblocking(0)
        self.parent.sock.settimeout(0.1)
        self.connected=True
        self.parent.connected=True #deprecated
        t=threading.Thread(target=self.parent.sys._loop_time_events)
        t.setName('sys._loop_time_events')
        t.start()
        self.con_thread_list.append(t)
        t=threading.Thread(target=self.parent._loop_tux_tcp_msg)
        t.setName('_loop_tux_tcp_msg')
        t.start()
        self.con_thread_list.append(t)
        t=threading.Thread(target=self.parent._loop_lock_list)
        t.setName('_loop_lock_list')
        t.start()
        self.con_thread_list.append(t)
        t=threading.Thread(target=self.parent._loop_tux_data_dispatching)
        t.setName('_loop_tux_data_dispatching')
        t.start()
        self.con_thread_list.append(t)
        t=threading.Thread(target=self.parent.status._loop_light_level)
        t.setName('status._loop_light_level')
        t.start()
        self.con_thread_list.append(t)
        return True

    #--------------------------------------------------------------------------
    # Disconnect object from tuxd
    #--------------------------------------------------------------------------
    def disconnect(self):
        """
        Disconnect tux object from tuxd

            Example:
            >>> tux.daemon.disconnect()
        """
        if self.connected:
            sav_ac=self.ac
            self.auto_connect(False)
            # Wait until the "free" threads has been released
            for free_thread in self.free_thread_list:
                if self.parent.print_debug_thread:
                    print "'%s' has been released"%free_thread.getName()
                if free_thread.isAlive():
                    free_thread.join()
            self.free_thread_list=[]
            # To inform the system and tuxd that the connection
            # is closed
            self.disconnect_me()
            self.connected=False
            self.parent.connected=False #deprecated
            # Close the tcp socket
            self.parent.sock.close()
            self.auto_connect(sav_ac)

    #--------------------------------------------------------------------------
    # SYSTEM
    #--------------------------------------------------------------------------
    def cmd_ack(self):
        """
        Not a user function
        """
        # create a condition mutex
        cond_lock_mutex = threading.Condition(threading.Lock())
        # create a list of frames to match
        data_to_match_list = []
        # create and insert a frame to match
        data_to_match = (SOURCE_SUB_DAEMON,SS_DEFAULT,DATA_TP_ACK_CMD, \
                999,999,999,999,999,999,999,999,999,999,999,999,999)
        data_to_match_list.append(data_to_match)
        # create empty frame returned
        returned_data = []
        # insert theses settings in the lock list
        self.parent._insert_lock_in_list(data_to_match_list, \
                cond_lock_mutex,returned_data)
        # wait the lock has unblocked. With a time-out
        cond_lock_mutex.acquire()
        cond_lock_mutex.wait(2)
        cond_lock_mutex.release()
        # returns
        if len(returned_data) == 0:
            return ACK_CMD_TIMEOUT
        else:
            return ord(returned_data[0][4])

    #--------------------------------------------------------------------------
    # Wait a specified response status
    #--------------------------------------------------------------------------
    def rsp_info(self,DATA_INFO):
        """
        Not a user function
        """
        # create a condition mutex
        cond_lock_mutex = threading.Condition(threading.Lock())
        # create a list of frames to match
        data_to_match_list = []
        # create and insert a frame to match
        data_to_match = (SOURCE_SUB_DAEMON,SS_DEFAULT,DATA_TP_RSP, \
                SUBDATA_TP_INFO,DATA_INFO,999,999,999,999,999,999, \
                999,999,999,999,999)
        data_to_match_list.append(data_to_match)
        # create empty frame returned
        returned_data = []
        # insert theses settings in the lock list
        self.parent._insert_lock_in_list(data_to_match_list,cond_lock_mutex,
                returned_data)
        # wait the lock has unblocked. With a time-out
        cond_lock_mutex.acquire()
        cond_lock_mutex.wait(2)
        cond_lock_mutex.release()
        # returns
        if len(returned_data) == 0:
            return ()
        else:
            return returned_data[0]

    #--------------------------------------------------------------------------
    # Send a command to tuxd
    #--------------------------------------------------------------------------
    def cmd(self,cmd,param1,param2,param3):
        """
        Not a user function
        """
        self.cmd_no_ack(cmd,param1,param2,param3)
        return self.cmd_ack()

    #--------------------------------------------------------------------------
    # Send a command to tuxd
    #--------------------------------------------------------------------------
    def cmd_no_ack(self,cmd,param1,param2,param3):
        """
        Not a user function
        """
        if not self.connected:
            return 2
        data=(DEST_SUB_DAEMON,SD_DEFAULT,DATA_TP_CMD,SUBDATA_TP_STRUCT,cmd,
                param1,param2,param3,0,0,0,0,0,0,0,0)
        self.parent._sock_send_frame("".join( [chr(x) for x in data] ))
        return 0

    #--------------------------------------------------------------------------
    # Send a request to tuxd
    #--------------------------------------------------------------------------
    def request(self,req,param1,param2,param3):
        """
        Not a user function
        """
        if not self.connected:
            return 2
        data=(DEST_SUB_DAEMON,SD_DEFAULT,DATA_TP_REQ, \
                SUBDATA_TP_INFO,req,param1,param2,param3,0,0,0,0,0,0,0,0)
        self.parent._sock_send_frame("".join( [chr(x) for x in data] ))
        return self.rsp_info(req)

    #--------------------------------------------------------------------------
    # Disconnect a client from tuxd
    #--------------------------------------------------------------------------
    def disconnect_client(self,id_client):
        """
        Disconnect a client from tuxd

            Parameters:
            "id_client" as integer  : id of the client to disconnect

            Example:
            >>> tux.daemon.disconnect_client(0)
        """
        if not self.connected : return
        self.last_ack=self.cmd(SUB_D_CMD_STRUC_DISCONNECT_CLIENT,id_client,0,0)

    #--------------------------------------------------------------------------
    # Not a user function
    #--------------------------------------------------------------------------
    def disconnect_me(self):
        """
        Not a user function
        """
        if not self.connected : return
        self.last_ack=self.cmd_no_ack(SUB_D_CMD_STRUC_DISCONNECT_CLIENT_ME, \
                0,0,0)

    #--------------------------------------------------------------------------
    # Kill tuxd
    #--------------------------------------------------------------------------
    def kill(self):
        """
        Kill tuxd

            Example:
            >>> tux.daemon.kill()
        """
        if not self.connected : return
        self.last_ack=self.cmd(SUB_D_CMD_STRUC_KILL_DAEMON,0,0,0)

    #--------------------------------------------------------------------------
    # Set my client name on tuxd
    #--------------------------------------------------------------------------
    def set_my_client_name(self,name):
        """
        Set my client name on tuxd

            Parameters:
            "name" as string    : name of this client (max 11 char)

            Example:
            >>> tux.daemon.set_my_client_name('Py client')

            Comment:
            The variable 'tux.my_name' is affected by this function
        """
        if not self.connected:
            return
        name_length=len(name)
        if name_length<11:
            add_name="".join( [' ' for i in range(11-name_length)] )
            name=name+add_name
        data=(DEST_SUB_DAEMON,SD_DEFAULT,DATA_TP_CMD,SUBDATA_TP_STRUCT, \
                SUB_D_CMD_STRUC_DEFINE_CLIENT_NAME,ord(name[0]),ord(name[1]), \
                ord(name[2]),ord(name[3]),ord(name[4]),ord(name[5]),
                ord(name[6]),ord(name[7]),ord(name[8]),ord(name[9]),
                ord(name[10]))
        self.parent._sock_send_frame("".join( [chr(x) for x in data] ))
        self.parent.my_name=name
        self.last_ack=self.cmd_ack()

    #--------------------------------------------------------------------------
    # Get the version of tuxd
    #--------------------------------------------------------------------------
    def get_version(self):
        """
        Get the version of tuxd

            Return a string

            Example:
            >>> print tux.daemon.get_version()
        """
        if not self.connected : return ''
        frame = self.request(SUB_D_REQ_INFO_VERSION,0,0,0)
        result=[0,0,0]
        if len(frame) > 0:
            result[0]=ord(frame[5])
            result[1]=ord(frame[6])
            result[2]=ord(frame[7])
        return "%d.%d.%d"%(result[0],result[1],result[2])

    #--------------------------------------------------------------------------
    # Get the number of clients connected to tuxd
    #--------------------------------------------------------------------------
    def get_client_count(self):
        """
        Get the number of clients connected to tuxd

            Return an integer

            Example:
            >>> print tux.daemon.get_client_count()
        """
        if not self.connected : return 0
        frame = self.request(SUB_D_REQ_INFO_CLIENT_COUNT,0,0,0)
        if len(frame) > 0:
            return ord(frame[5])
        else:
            return 0

    #--------------------------------------------------------------------------
    # Get the name of a client of tuxd
    #--------------------------------------------------------------------------
    def get_client_name(self,id_client):
        """
        Get the name of a client of tuxd

            Return a string

            Example:
            >>> print tux.daemon.get_client_name(0)
        """
        if not self.connected : return ''
        frame = self.request(SUB_D_REQ_INFO_CLIENT_NAME,id_client,0,0)
        if len(frame) > 0:
            struct_data = [frame[i] for i in range(5,16,1)]
            return "".join(struct_data)
        else:
            return ''

    #--------------------------------------------------------------------------
    # Print the name of all the clients connected to tuxd
    #--------------------------------------------------------------------------
    def print_clients_name(self):
        """
        Print the name of all the clients connected to tuxd

            Example:
            >>> tux.daemon.print_clients_name()
        """
        if not self.connected : return
        for i in range(self.get_client_count()):
            print "Client %.3d : %s"%(i,self.get_client_name(i))

    #--------------------------------------------------------------------------
    # Get the client id of my connection to tuxd
    #--------------------------------------------------------------------------
    def get_my_client_id(self):
        """
        Get the client id of my connection to tuxd

            Return an integer

            Example:
            >>> print tux.daemon.get_my_client_id()
        """
        if not self.connected : return 0
        frame = self.request(SUB_D_REQ_INFO_MY_CLIENT_ID,0,0,0)
        if len(frame) > 0:
            return ord(frame[5])
        else:
            return 0


#==============================================================================
# TUXTCPCommunicator - hw - class
#==============================================================================
class TUXhw(object):
    """
    Class which manages the tux hardware

        Global variables of this class
        "TUX_devices" as tuple          : tuple of tux devices as tuple
                                          (param 0 = alsa device name)
                                          (param 1 = sound card)
                                          (param 2 = sound device)
                                          (param 3 = usb bus)
                                          (param 4 = usb device)
                                          (param 5 = usb PID)
                                          (param 6 = usb VID)
        "TUX_devices_count" as integer  : number of tux devices
        "alsa_device" as string         : current alsa device name
                                          (is selected on the beginning
                                           of the api with the first tux
                                           sound card)

        Functions list for the users:
            tux.hw.alsa_devices_count
            tux.hw.alsa_devices_select
            tux.hw.audio_get_version
            tux.hw.behavior_get_version
            tux.hw.donglerf_get_version
            tux.hw.oss_device
            tux.hw.tuxrf_get_version
    """
    #--------------------------------------------------------------------------
    # Constructor of this class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        """
        Constructor of this class
        """
        self.parent=parent
        self.TUX_devices=[]
        self.TUX_devices_count=0
        self.alsa_device="default"
        self.alsa_devices_select(0)

    #--------------------------------------------------------------------------
    # Get version of a firmware
    #--------------------------------------------------------------------------
    def get_firmware_versioning(self,cpu_index):
        """
        Not a user function
        """
        if not self.parent.daemon.connected:
            return (0,0,0,0,0)
        data=(DEST_TUX,SD_DEFAULT,DATA_TP_REQ,SUBDATA_TP_INFO, \
                TUX_REQ_INFO_VERSION,cpu_index,0,0,0,0,0,0,0,0,0,0)
        self.parent._sock_send_frame("".join( [chr(x) for x in data] ))
        frame = self.parent.status.rsp_status(TUX_REQ_INFO_VERSION)
        if len(frame) > 0:
            ver_major=ord(frame[5])
            ver_minor=ord(frame[6])
            ver_update=ord(frame[7])
            revision=(ord(frame[8])<<8)+ord(frame[9])
            author_id=(ord(frame[10])<<8)+ord(frame[11])
            return (ver_major,ver_minor,ver_update,revision,author_id)

    #--------------------------------------------------------------------------
    # Get the version of the behavior firmware
    #--------------------------------------------------------------------------
    def behavior_get_version(self):
        """
        Get the version of the behavior firmware

            Return a tuple  : (major version, minor version, update version,
                               revision, author_id)

            Example:
            >>> print tux.hw.behavior_get_version()
        """
        return self.get_firmware_versioning(0)

    #--------------------------------------------------------------------------
    # Get the version of the audio firmware
    #--------------------------------------------------------------------------
    def audio_get_version(self):
        """
        Get the version of the audio firmware

            Return a tuple  : (major version, minor version, update version,
                               revision, author_id)

            Example:
            >>> print tux.hw.audio_get_version()
        """
        return self.get_firmware_versioning(1)

    #--------------------------------------------------------------------------
    # Get the version of the tuxrf firmware
    #--------------------------------------------------------------------------
    def tuxrf_get_version(self):
        """
        Get the version of the tuxrf firmware

            Return a tuple  : (major version, minor version, update version,
                               revision, author_id)

            Example:
            >>> print tux.hw.tuxrf_get_version()
        """
        return self.get_firmware_versioning(2)

    #--------------------------------------------------------------------------
    # Get the version of the donglerf firmware
    #--------------------------------------------------------------------------
    def donglerf_get_version(self):
        """
        Get the version of the donglerf firmware

            Return a tuple  : (major version, minor version, update version,
                               revision, author_id)

            Example:
            >>> print tux.hw.donglerf_get_version()
        """
        return self.get_firmware_versioning(3)

    #--------------------------------------------------------------------------
    # Get the alsa devices
    #--------------------------------------------------------------------------
    def alsa_devices_enumerate(self):
        """
        Not a user function
        """
        self.TUX_devices=[]
        self.TUX_devices_count=0
        try:
            snd_dir=os.listdir("/dev/snd")
        except OSError:
            if self.parent.print_warnings:
                print "No alsa sound path found !"
            return
        last_card=255
        last_device=255
        for dinfo_name in snd_dir:
            if ((dinfo_name.find('pcmC')==0)and(dinfo_name.find('D')>-1)):
                card=int(dinfo_name[4:5])
                device=int(dinfo_name[6:7])
                if ((card!=last_card)or(device!=last_device)):
                    last_card=card
                    last_device=device
                    filename="/proc/asound/card%d/usbbus"%card
                    try:
                        fp=open(filename,'r')
                    except IOError:
                        break
                    tmp_tab=fp.read(7).split('/')
                    current_tux_device=["",0,0,0,0,0,0]
                    current_tux_device[1]=card
                    current_tux_device[2]=device
                    current_tux_device[3]=int(tmp_tab[0])
                    current_tux_device[4]=int(tmp_tab[1])
                    filename="/proc/asound/card%d/usbid"%card
                    try:
                        fp=open(filename,'r')
                    except IOError:
                        break
                    tmp_tab=fp.read(9).split(':')
                    current_tux_device[5]=int(tmp_tab[0],16)
                    current_tux_device[6]=int(tmp_tab[1],16)
                    current_tux_device[0]="hw:%d,%d"%(current_tux_device[1], \
                            current_tux_device[2])
                    if ((current_tux_device[5]==0x03eb) and
                            (current_tux_device[6]==0xff07)):
                        self.TUX_devices.append(current_tux_device)
                        self.TUX_devices_count=self.TUX_devices_count+1

    #--------------------------------------------------------------------------
    # Return the number of tux alsa devices
    #--------------------------------------------------------------------------
    def alsa_devices_count(self):
        """
        Return the number of tux alsa devices

            Return an integer

            Example:
            >>> print tux.hw.alsa_devices_count()
        """
        count=0
        for ctd in self.TUX_devices:
            if ctd[2]==0:
                count=count+1
        return count

    #--------------------------------------------------------------------------
    # Get the alsa device name of a tux sound card
    #--------------------------------------------------------------------------
    def alsa_devices_select(self,number):
        """
        Get the alsa device name of a tux sound card

            Return a string (ex: 'hw:1,0')

            Example:
            >>> print tux.hw.alsa_devices_select(0)
        """
        self.alsa_devices_enumerate()
        self.alsa_devices_count()
        self.alsa_device=""
        i=0
        if self.TUX_devices_count>0:
            for ctd in self.TUX_devices:
                if ctd[2]==0:
                    if i==number:
                        self.alsa_device="hw:%d,%d"%(ctd[1],ctd[2])
                        return
                    i=i+1
            self.alsa_device="default"
        else:
            self.alsa_device="default"

    #--------------------------------------------------------------------------
    # Get the oss compatibility device of the tux sound card
    #--------------------------------------------------------------------------
    def oss_device(self):
        """
        Get the oss compatibility device of the tux sound card

            Return a string (ex : '/dev/dsp')
        """
        if self.alsa_device=='default':
            return ''
        elif self.alsa_device[3]=='0':
            return '/dev/dsp'
        else:
            return '/dev/dsp%s'%self.alsa_device[3]

#==============================================================================
# TUXTCPCommunicator - TTS - class
#==============================================================================
class TUXtts(object):
    """
    Class which manages the text to speech

        Global variables of this class:
        "connected" as boolean      : State of the connection to tuxttsd
        "print_status" as boolean   : Allow to print the raw statuses
        "sound_on" as boolean       : Speaking state of the tuxttsd
        "on_connected" as pof       : Event on tuxttsd connected
        "on_disconnected" as pof    : Event on tuxttsd disconnected
        "on_sound_on" as pof        : Event on tts speaking on
        "on_sound_off" as pof       : Event on tts speaking off
        "on_voice_list" as pof      : Event on new authorized voices list
        "authorized_voices_list" as list of string : List of authorized voices
        (pof = pointer of function)

        Example of associating a function to an event:
        >>> def my_function():
        >>>     tux.cmd.mouth_open()
        >>> tux.tts.on_sound_on=my_function

        Functions list for the users:
            tux.tts.auto_connect
            tux.tts.connect
            tux.tts.disconnect
            tux.tts.kill_daemon
            tux.tts.pause
            tux.tts.play
            tux.tts.select_voice
            tux.tts.speak
            tux.tts.speak_free
            tux.tts.stop
    """
    #--------------------------------------------------------------------------
    # Constructor of class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        """
        Constructor of this class
        """
        self.parent=parent
        self.con_thread_list = []
        self.connected=False
        self.tcp_mutex = threading.Lock()
        self.tts_mutex = threading.Lock()
        self.tcp_data_list = []
        self.print_status = False
        self.on_sound_on = None
        self.on_sound_off = None
        self.on_connected = None
        self.on_disconnected = None
        self.on_voice_list = None
        self.on_wav_raw = EventControl()
        self.__last_wav_raw = [0] * 1024;
        self.sound_on=False
        self.my_pitch=100
        self.my_voice=SPK_US_MALE
        self.ac=False
        self.ac_port=5500
        self.ac_address='localhost'
        self.authorized_voices_list = []
        self.voice_loaded = False
        self.speaking_stack = []
        self.speaking_stack_mutex = threading.Lock()

    def destroy(self):
        self.on_wav_raw.destroy()
        self.stop()

    def speaking_stack_add(self, speaking_conf):
        self.speaking_stack_mutex.acquire()
        self.speaking_stack.append(speaking_conf)
        self.speaking_stack_mutex.release()

    def speaking_stack_get_size(self):
        self.speaking_stack_mutex.acquire()
        val = len(self.speaking_stack)
        self.speaking_stack_mutex.release()
        return val

    def speaking_stack_loop(self):
        while self.connected:
            if self.speaking_stack_get_size() > 0:
                if not self.tts_mutex.locked():
                    self.speaking_stack_mutex.acquire()
                    if len(self.speaking_stack) > 0:
                        curr_speaking_conf = self.speaking_stack.pop(0)
                    else:
                        self.speaking_stack_mutex.release()
                        time.sleep(0.1)
                        continue
                    self.speaking_stack_mutex.release()
                    if curr_speaking_conf[2] == 'speak_free':
                        self.my_pitch = curr_speaking_conf[1][1]
                        self.my_voice = curr_speaking_conf[1][0]
                        self.__speak_free(curr_speaking_conf[0])
                    elif curr_speaking_conf[2] == 'speak':
                        self.my_pitch = curr_speaking_conf[1][1]
                        self.my_voice = curr_speaking_conf[1][0]
                        self.__speak(curr_speaking_conf[0])
                    elif curr_speaking_conf[2] == 'wav_free':
                        self.parent.wav._set_begin_end( curr_speaking_conf[1][0],
                                                        curr_speaking_conf[1][1])
                        self.__wav_free(curr_speaking_conf[0])
                    elif curr_speaking_conf[2] == 'wav':
                        self.parent.wav._set_begin_end( curr_speaking_conf[1][0],
                                                        curr_speaking_conf[1][1])
                        self.__wav(curr_speaking_conf[0])
                    curr_speaking_conf[3].acquire()
                    curr_speaking_conf[3].notify()
                    curr_speaking_conf[3].release()
            time.sleep(0.1)
        self.speaking_stack_mutex.acquire()
        for curr_speaking_conf in self.speaking_stack:
            curr_speaking_conf[3].acquire()
            curr_speaking_conf[3].notify()
            curr_speaking_conf[3].release()
        self.speaking_stack_mutex.release()

    def speak(self, text):
        """
        Speak a text with the acapela text to speech engine

            Parameters:
            "text" as string    : text to read

            Example:
            >>> tux.tts.speak('My name is tux! tux droid !')
        """
        if not self.connected:
            return
        speaking_conf = []
        speaking_conf.append(text)
        voice_conf = []
        voice_conf.append(self.my_voice)
        voice_conf.append(self.my_pitch)
        speaking_conf.append(voice_conf)
        speaking_conf.append('speak')
        my_lock = threading.Condition(threading.Lock())
        speaking_conf.append(my_lock)
        self.speaking_stack_add(speaking_conf)
        my_lock.acquire()
        my_lock.wait()
        my_lock.release()

    def speak_free(self, text):
        """
        Speak a text with the acapela text to speech engine in free mode

            Parameters:
            "text" as string    : text to read

            Example:
            >>> tux.tts.speak_free('My name is tux! tux droid !')
        """
        if not self.connected:
            return
        speaking_conf = []
        speaking_conf.append(text)
        voice_conf = []
        voice_conf.append(self.my_voice)
        voice_conf.append(self.my_pitch)
        speaking_conf.append(voice_conf)
        speaking_conf.append('speak_free')
        my_lock = threading.Condition(threading.Lock())
        speaking_conf.append(my_lock)
        self.speaking_stack_add(speaking_conf)
        my_lock.acquire()
        my_lock.wait()
        my_lock.release()

    def _wav(self, wav_path, begin, end):
        if not os.path.isfile(wav_path):
            return
        if not self.connected:
            return
        speaking_conf = []
        speaking_conf.append(wav_path)
        voice_conf = []
        voice_conf.append(begin)
        voice_conf.append(end)
        speaking_conf.append(voice_conf)
        speaking_conf.append('wav')
        my_lock = threading.Condition(threading.Lock())
        speaking_conf.append(my_lock)
        self.speaking_stack_add(speaking_conf)
        my_lock.acquire()
        my_lock.wait()
        my_lock.release()

    def _wav_free(self, wav_path, begin, end):
        if not os.path.isfile(wav_path):
            return
        if not self.connected:
            return
        speaking_conf = []
        speaking_conf.append(wav_path)
        voice_conf = []
        voice_conf.append(begin)
        voice_conf.append(end)
        speaking_conf.append(voice_conf)
        speaking_conf.append('wav_free')
        my_lock = threading.Condition(threading.Lock())
        speaking_conf.append(my_lock)
        self.speaking_stack_add(speaking_conf)
        my_lock.acquire()
        my_lock.wait()
        my_lock.release()

    #--------------------------------------------------------------------------
    # Allow to connect the api to tuxttsd automatically
    #--------------------------------------------------------------------------
    def auto_connect(self,value,address='ndef',port=0):
        """
        Allow to connect the api to tuxttsd automatically

            Parameters:
            "value" as boolean      : turn on/off the auto_connect mode
            "address" as string     : Tcp/IP Host address
                                      (default = 'localhost')
            "port" as integer       : Tcp/IP Port number
                                      (default = 5500)

            Examples:
            >>> tux.tts.auto_connect(True)
            >>> tux.tts.auto_connect(True,'192.168.0.1')
            >>> tux.tts.auto_connect(True,'192.168.0.1',5500)
        """
        self.ac=value
        if port!=0:
            self.ac_port=port
        if address!='ndef':
            self.ac_address=address
    #--------------------------------------------------------------------------
    # Not a user function
    #--------------------------------------------------------------------------
    def _tcp_threads_join(self):
        # Wait until the tcp threads has been released
        for con_thread in self.con_thread_list:
            if self.parent.print_debug_thread:
                print "'%s' has been released"%con_thread.getName()
            if con_thread.isAlive():
                con_thread.join()
        self.con_thread_list=[]

    #--------------------------------------------------------------------------
    # Not a user function
    #--------------------------------------------------------------------------
    def _loop_auto_connect(self):
        """
        Not a user function
        """
        last_connect_status=False
        while not self.parent.exit_flag:
            if self.ac:
                if not self.connected:
                    self.parent.print_warnings_mutex.acquire()
                    store=self.parent.print_warnings
                    self.parent.print_warnings=False
                    self.connect(self.ac_address,self.ac_port)
                    self.parent.print_warnings=store
                    self.parent.print_warnings_mutex.release()
            if self.connected!=last_connect_status:
                if self.connected:
                    if self.parent.print_warnings:
                        print "CONNECTED to tuxttsd"
                    if self.on_connected!=None:
                        self.on_connected()
                else:
                    if self.parent.print_warnings:
                        print "DISCONNECTED from tuxttsd"
                    if self.on_disconnected!=None:
                        self.on_disconnected()
                    self._tcp_threads_join()
            last_connect_status=self.connected
            self.parent.sys.wait(0.1)

    #--------------------------------------------------------------------------
    # Connect object to tuxttsd
    #--------------------------------------------------------------------------
    def connect_to_daemon(self):
        """
        Deprecated : see 'tux.tts.connect'
        """
        return self.connect()
    def connect(self,address='localhost',port=5500):
        """
        Connect tts object to tuxttsd

           Parameters:
           "port" as integer     : Tcp/IP Port number
                                   (default = 5500)
           "address" as string   : Tcp/IP Host address
                                   (default = 'localhost')

           Examples:
           >>> tux.tts.connect()
           >>> tux.tts.connect('192.168.0.1')
           >>> tux.tts.connect('localhost',5500)

           Comment:
           The variable "tux.tts.connected" contains the result of this method
        """
        self.disconnect()
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setblocking(1)
        try:
            self.sock.connect((address,port))
        except socket.error:
            return False
        self.sock.setblocking(0)
        self.sock.settimeout(0.1)
        self.connected=True
        t=threading.Thread(target=self._loop_tux_data_dispatching)
        t.setName('tts._loop_tux_data_dispatching')
        t.start()
        self.con_thread_list.append(t)

        t=threading.Thread(target=self._loop_tcp_tts_msg)
        t.setName('tts._loop_tcp_tts_msg')
        t.start()
        self.con_thread_list.append(t)

        t=threading.Thread(target=self.speaking_stack_loop)
        t.setName('tts.speaking_stack_loop')
        t.start()
        self.con_thread_list.append(t)

        self.get_sound_state()
        return True

    #--------------------------------------------------------------------------
    # Disconnect tts object from tuxttsd
    #--------------------------------------------------------------------------
    def disconnect_from_daemon(self):
        """
        Deprecated : see 'tux.tts.disconnect'
        """
        self.disconnect()
    def disconnect(self):
        """
        Disconnect tts object from tuxttsd

           Example:
           >>> tux.tts.disconnect()
        """
        if self.connected:
            self.send_disconnect()
            self.connected=False
            self.sock.close()

    #--------------------------------------------------------------------------
    # Send a frame to tuxttsd
    #--------------------------------------------------------------------------
    def _sock_send_frame(self, frame):
        try:
            self.sock.send(frame)
        except:
            pass

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _loop_tcp_tts_msg(self):
        """
        Not a user function
        """
        while self.connected:
            try:
                tcp_data=self.sock.recv(256)
            except socket.timeout:
                time.sleep(0.01)
                continue
            except socket.error:
                self.sock.close()
                self.connected=False
                time.sleep(0.01)
                continue
            if len(tcp_data) < 256:
                time.sleep(0.01)
                continue
            if self.print_status:
                struct_data = ["%.2x" % ord(datae) for datae in tcp_data]
                print " ".join(struct_data)
            self.tcp_mutex.acquire()
            self.tcp_data_list.append(tcp_data)
            self.tcp_mutex.release()
            time.sleep(0.002)

    #--------------------------------------------------------------------------
    # SYSTEM function
    #--------------------------------------------------------------------------
    def _loop_tux_data_dispatching(self):
        """
        Not a user function
        """
        while self.connected:
            self.tcp_mutex.acquire()
            data = ()
            if len(self.tcp_data_list) > 0:
                data = self.tcp_data_list.pop(0)
            else:
                self.tcp_mutex.release()
                time.sleep(0.002)
                continue
            self.tcp_mutex.release()
            self._dispatch_data_main(data)
            time.sleep(0.002)

    #--------------------------------------------------------------------------
    # Dispatch data from tcp server
    #--------------------------------------------------------------------------
    def _dispatch_data_main(self,data):
        """
        Not a user function
        """
        # DAEMON INFO
        if ord(data[0])==DAEMON_INFO:
            # Daemon is killed
            if ord(data[1])==DAEMON_INFO_KILLED:
                self.disconnect()
        # TTS INFO
        if ord(data[0])==TTS_INFO:
            # INFO sound state
            if ord(data[1])==CMD_INFO_SOUND_STATE:
                # SOUND on
                if ord(data[2])==TTS_SOUND_ON:
                    self.sound_on=True
                    if self.on_sound_on!=None:
                        self.on_sound_on()
                # SOUND off
                if ord(data[2])==TTS_SOUND_OFF:
                    self.sound_on=False
                    if self.on_sound_off!=None:
                        self.on_sound_off()
            # Authorized voices list
            if ord(data[1])==CMD_INFO_VOICE_LIST:
                self.authorized_voices_list = []
                for voice_id in data[2:]:
                    if ord(voice_id) != 0:
                        self.authorized_voices_list.append(ord(voice_id)-1)
                if self.on_voice_list != None:
                    self.on_voice_list()
            # A voice has been loaded
            if ord(data[1])==CMD_INFO_VOICE_OK:
                self.voice_loaded = True
        # WAV INFO
        if ord(data[0]) == WAV_INFO:
            idx = ord(data[1])
            if idx < 4:
                spectre_idx = idx * 254
                for i in range(254):
                    self.__last_wav_raw[spectre_idx + i] = ord(data[i + 2])
            else:
                spectre_idx = idx * 254
                for i in range(8):
                    self.__last_wav_raw[spectre_idx + i] = ord(data[i + 2])
                if self.on_wav_raw != None:
                    tmp_raw = deepcopy(self.__last_wav_raw)
                    self.on_wav_raw.notify(tmp_raw)

    #--------------------------------------------------------------------------
    # Send command to tuxttsd
    #--------------------------------------------------------------------------
    def send_command_to_tts(self,cmd_type,cmd,param1,param2,param3,param4):
        """
        Not a user function
        """
        if not self.connected:
            if self.parent.print_warnings:
                print "WARNING : Resource text to speech Acapela not found"
            return
        data=(cmd_type,cmd,param1,param2,param3,param4)
        self._sock_send_frame("".join( [chr(x) for x in data] ))

    #--------------------------------------------------------------------------
    # Reinit sound to tux sound card device
    #--------------------------------------------------------------------------
    def soundconf_reinit(self,usb_bus,usb_device):
        """
        Not a user function
        """
        self.send_command_to_tts(CMD_TYPE_SOUND_CONF,CMD_SOUNDCONF_REINIT, \
                usb_bus,usb_device,0,0)

    #--------------------------------------------------------------------------
    # Stop alsa driver
    #--------------------------------------------------------------------------
    def soundconf_stop(self):
        """
        Not a user function
        """
        self.send_command_to_tts(CMD_TYPE_SOUND_CONF,CMD_SOUNDCONF_STOP, \
                0,0,0,0)

    #--------------------------------------------------------------------------
    # Select a speaker voice
    #--------------------------------------------------------------------------
    def select_voice(self,speaker,pitch):
        """
        Select a speaker voice

            Parameters:
            "speaker" as integer    : speaker id (SPK_FR_MALE|SPK_FR_FEMALE|
                                                  SPK_US_MALE|SPK_US_FEMALE)
            "pitch" as integer      : raised pitch in % (100..330)

            Example:
            >>> tux.tts.select_voice(SPK_FR_MALE,100)
        """
        if (pitch<100) or (pitch>330):
            if self.parent.print_warnings:
                print " Pitch not in range (100 - 330)"
            return
        my_pitch=int(10000/pitch)
        self.my_pitch=my_pitch
        self.my_voice=speaker

    #--------------------------------------------------------------------------
    # Select the French male speaker voice with a normal pitch
    #--------------------------------------------------------------------------
    def select_voice_fr_male(self):
        """
        Select the French male speaker voice with a normal pitch

            Example:
            >>> tux.tts.select_voice_fr_male()
        """
        self.select_voice(SPK_FR_MALE,100)

    #--------------------------------------------------------------------------
    # Select the French female speaker voice with a normal pitch
    #--------------------------------------------------------------------------
    def select_voice_fr_female(self):
        """
        Select the French female speaker voice with a normal pitch

            Example:
            >>> tux.tts.select_voice_fr_female()
        """
        self.select_voice(SPK_FR_FEMALE,100)

    #--------------------------------------------------------------------------
    # Select the US English male speaker voice with a normal pitch
    #--------------------------------------------------------------------------
    def select_voice_us_male(self):
        """
        Select the US English male speaker voice with a normal pitch

            Example:
            >>> tux.tts.select_voice_us_male()
        """
        self.select_voice(SPK_US_MALE,100)

    #--------------------------------------------------------------------------
    # Select the US English female speaker voice with a normal pitch
    #--------------------------------------------------------------------------
    def select_voice_us_female(self):
        """
        Select the US English female speaker voice with a normal pitch

            Example:
            >>> tux.tts.select_voice_us_female()
        """
        self.select_voice(SPK_US_FEMALE,100)

    #--------------------------------------------------------------------------
    # Select the French male speaker voice with a raised pitch
    #--------------------------------------------------------------------------
    def select_voice_fr_male_tuxed(self):
        """
        Select the French male speaker voice with a raised pitch

            Example:
            >>> tux.tts.select_voice_fr_male_tuxed()
        """
        self.select_voice(SPK_FR_MALE,170)

    #--------------------------------------------------------------------------
    # Select the French female speaker voice with a raised pitch
    #--------------------------------------------------------------------------
    def select_voice_fr_female_tuxed(self):
        """
        Select the French female speaker voice with a raised pitch

            Example:
            >>> tux.tts.select_voice_fr_female_tuxed()
        """
        self.select_voice(SPK_FR_FEMALE,175)

    #--------------------------------------------------------------------------
    # Select the US English male speaker voice with a raised pitch
    #--------------------------------------------------------------------------
    def select_voice_us_male_tuxed(self):
        """
        Select the US English male speaker voice with a raised pitch

            Example:
            >>> tux.tts.select_voice_us_male_tuxed()
        """
        self.select_voice(SPK_US_MALE,166)

    #--------------------------------------------------------------------------
    # Select the US English female speaker voice with a raised pitch
    #--------------------------------------------------------------------------
    def select_voice_us_female_tuxed(self):
        """
        Select the US English female speaker voice with a raised pitch

            Example:
            >>> tux.tts.select_voice_us_female_tuxed()
        """
        self.select_voice(SPK_US_FEMALE,166)

    #--------------------------------------------------------------------------
    # Speak a text with the acapela text to speech engine
    #--------------------------------------------------------------------------
    def __speak(self,text):
        """
        Speak a text with the acapela text to speech engine

            Parameters:
            "text" as string    : text to read

            Example:
            >>> tux.tts.speak('My name is tux! tux droid !')
        """
        self.tts_mutex.acquire()
        if not self.connected:
            if self.parent.print_warnings:
                print "WARNING : Resource text to speech Acapela not found"
            self.tts_mutex.release()
            return False
        self.stop()
        #if self.sound_on == True:
        #    self.stop()
        o_text = text
        text = text+" "
        try:
            u = unicode(text,"utf-8")
        except:
            u = text
        text_to_send = u.encode('latin-1','replace')
        text_length = len(text_to_send)
        self.send_command_to_tts(CMD_TYPE_TTS, CMD_TTS_INSERT_PLAY_SPEECH, \
                (text_length & 0x0000FF00) >> 8, (text_length & 0x000000FF), \
                self.my_voice, self.my_pitch)
        self.voice_loaded = False
        self._sock_send_frame(text_to_send)
        counter = 0
        while ((self.voice_loaded == False) and (counter < 100)):
            counter = counter + 1
            self.parent.sys.wait(0.1)
            if self.speaking_stack_get_size() > 0:
                break
        if counter == 100:
            self.stop()
            print "TTS Speak : Voice not loaded"
            self.tts_mutex.release()
            return False
        self.parent.cmd.audio_channel_tts()
        counter = 0
        while ((self.sound_on == False) and (counter < 50)):
            counter = counter + 1
            self.parent.sys.wait(0.1)
            if self.speaking_stack_get_size() > 0:
                break
        if counter == 50:
            self.stop()
            self.parent.cmd.audio_channel_general()
            print "TTS Speak : Timeout 5 sec"
            self.tts_mutex.release()
            self.__speak(o_text)
            return False
        while self.sound_on == True:
            self.parent.sys.wait(0.1)
            if self.speaking_stack_get_size() > 0:
                break
        time.sleep(0.3)
        self.parent.cmd.audio_channel_general()
        self.tts_mutex.release()
        return True

    #--------------------------------------------------------------------------
    # Play a wav with tuxttsd
    #--------------------------------------------------------------------------
    def __wav(self, wav_path):
        """
        Speak a text with the acapela text to speech engine

            Parameters:
            "text" as string    : text to read

            Example:
            >>> tux.tts.speak('My name is tux! tux droid !')
        """
        self.tts_mutex.acquire()
        if not self.connected:
            if self.parent.print_warnings:
                print "WARNING : Resource text to speech Acapela not found"
            self.tts_mutex.release()
            return False
        #if self.sound_on == True:
        #    self.stop()
        o_wav_path = wav_path
        self.stop()
        u = unicode(wav_path, "utf-8")
        text_to_send = u.encode('latin-1','replace')
        text_length = len(text_to_send)
        self.send_command_to_tts(CMD_TYPE_WAV, CMD_WAV_INSERT_PLAY, \
                (text_length & 0x0000FF00) >> 8, (text_length & 0x000000FF), \
                0, 0)
        self._sock_send_frame(text_to_send)
        self.parent.cmd.audio_channel_tts()
        counter = 0
        while ((self.sound_on == False) and (counter < 50)):
            counter = counter + 1
            self.parent.sys.wait(0.1)
            if self.speaking_stack_get_size() > 0:
                break
        if counter == 50:
            self.stop()
            self.parent.cmd.audio_channel_general()
            print "WAV play : Timeout 5 sec"
            self.tts_mutex.release()
            self.__wav(o_wav_path)
            return False
        while self.sound_on == True:
            self.parent.sys.wait(0.1)
            if self.speaking_stack_get_size() > 0:
                break
        time.sleep(0.3)
        self.parent.cmd.audio_channel_general()
        self.tts_mutex.release()
        return True

    #--------------------------------------------------------------------------
    # Speak a text with the acapela text to speech engine in free mode
    #--------------------------------------------------------------------------
    def __speak_free(self,text):
        t=threading.Thread(target=self.__speak, args=(text,))
        t.setName('tts.speak_free')
        t.start()
        self.parent.daemon.free_thread_list.append(t)
        return True

    #--------------------------------------------------------------------------
    # Play a wav with tuxttsd in free mode
    #--------------------------------------------------------------------------
    def __wav_free(self, wav_path):
        t=threading.Thread(target=self.__wav, args=(wav_path,))
        t.setName('tts.wav_free')
        t.start()
        self.parent.daemon.free_thread_list.append(t)
        return True

    #--------------------------------------------------------------------------
    # Play the sound if it's in "pause" state
    #--------------------------------------------------------------------------
    def play(self):
        """
        Play the sound if it's in "pause" state

            Example:
            >>> tux.tts.play()
        """
        self.send_command_to_tts(CMD_TYPE_TTS,CMD_TTS_PLAY,0,0,0,0)

    #--------------------------------------------------------------------------
    # Pause the sound
    #--------------------------------------------------------------------------
    def pause(self):
        """
        Pause the sound

            Example:
            >>> tux.tts.pause()
        """
        self.send_command_to_tts(CMD_TYPE_TTS,CMD_TTS_PAUSE,0,0,0,0)

    #--------------------------------------------------------------------------
    # Stop the sound
    #--------------------------------------------------------------------------
    def stop(self):
        """
        Stop the sound

            Example:
            >>> tux.tts.stop()
        """
        if not self.sound_on:
            return
        self.send_command_to_tts(CMD_TYPE_TTS,CMD_TTS_STOP,0,0,0,0)
        while self.sound_on == True:
            self.parent.sys.wait(0.1)

    #--------------------------------------------------------------------------
    # Send a command to tuxttsd for getting the state of the sound
    #--------------------------------------------------------------------------
    def get_sound_state(self):
        """
        Send a command to tuxttsd for getting the state of
        the sound

            Example:
            >>> tux.tts.get_sound_state()
        """
        self.send_command_to_tts(CMD_TYPE_INFO,CMD_INFO_SOUND_STATE,0,0,0,0)

    #--------------------------------------------------------------------------
    # Disconnect from tuxttsd
    #--------------------------------------------------------------------------
    def send_disconnect(self):
        """
        Not a user function
        """
        self.send_command_to_tts(CMD_TYPE_DAEMON,CMD_DAEMON_DISCONNECT_CLIENT, \
                0,0,0,0)

    #--------------------------------------------------------------------------
    # Print the audio fifo state on tuxttsd
    #--------------------------------------------------------------------------
    def print_audio_fifo_state(self):
        """
        Not a user function
        """
        self.send_command_to_tts(CMD_TYPE_DAEMON,CMD_DAEMON_PRINT_FIFO_STATE, \
                0,0,0,0)

    #--------------------------------------------------------------------------
    # Print informations of tux sound cards plugged
    #--------------------------------------------------------------------------
    def print_tux_sound_cards(self):
        """
        Not a user function
        """
        self.send_command_to_tts(CMD_TYPE_DAEMON, \
                CMD_DAEMON_PRINT_TUX_SOUND_CARDS,0,0,0,0)

    #--------------------------------------------------------------------------
    # Kill tuxttsd
    #--------------------------------------------------------------------------
    def kill_daemon(self):
        """
        Kill the tuxttsd

            Example:
            >>> tux.tts.kill_daemon()
        """
        self.send_command_to_tts(CMD_TYPE_DAEMON,CMD_DAEMON_KILL,0,0,0,0)

#==============================================================================
# TUXTCPCommunicator - wav - class
#==============================================================================
class TUXwav(object):
    """
    Class which manages the wav functions.

        Functions list for the users:
            tux.wav.play
            tux.wav.play_free
            tux.wav.pause
            tux.wav.stop
            tux.wav._continue
            tux.wav.get_duration
    """

    #--------------------------------------------------------------------------
    # Constructor of class
    #--------------------------------------------------------------------------
    def __init__(self,parent):
        self.parent = parent
        self.__wav_path = ""
        self.__wav_length = 0

    def destroy(self):
        self.stop()

    def __load(self, wav_path):
        if os.path.isfile(wav_path):
            try:
                size = os.stat(wav_path)[6] - 44
                self.__wav_length = (float)(size) / 8000
                self.__wav_path = wav_path
            except:
                return False
            return True
        else:
            return False

    def _set_begin_end(self, begin = 0., end = 0.):
        begin_100m = (int)(round(begin * 10))
        end_100m = (int)(round(end * 10))
        begin_lower = begin_100m & 0x000000FF
        begin_upper = (begin_100m & 0x0000FF00) >> 8
        end_lower = end_100m & 0x000000FF
        end_upper = (end_100m & 0x0000FF00) >> 8
        self.parent.tts.send_command_to_tts(
            CMD_TYPE_WAV,
            CMD_WAV_BEGIN_END,
            begin_lower,
            begin_upper,
            end_lower,
            end_upper)

    def get_duration(self, wav_path):
        """
        Get the duration of a wave file.

            Parameters:
            "wav_path" as string    : Path of the wave file

            Returns:
            The time duration in seconds as float.

            Exemple:
            >>> print tux.wav.get_duration('/home/tux/test.wav')
        """
        if self.__load(wav_path):
            self.__wav_path = ""
            return self.__wav_length
        else:
            return 0.

    def play(self, wav_path, begin = 0., end = 0.):
        """
        Play a wave file with tuxttsd daemon.

            Parameters:
            "wav_path" as string    : Path of the wave file
            "begin" as float        : Starting index in seconds(Optional)
            "end" as float          : Ending index in seconds(Optional)

            Exemple:
            >>> tux.wav.play('/home/tux/test.wav')
            >>> tux.wav.play('/home/tux/test.wav', 0., 5.5)
        """
        if self.__load(wav_path):
            self.parent.tts._wav(self.__wav_path, begin, end)

    def play_free(self, wav_path, begin = 0., end = 0.):
        """
        Play a wave file with tuxttsd daemon in free mode.

            Parameters:
            "wav_path" as string    : Path of the wave file
            "begin" as float        : Starting index in seconds(Optional)
            "end" as float          : Ending index in seconds(Optional)

            Exemple:
            >>> tux.wav.play_free('/home/tux/test.wav')
            >>> tux.wav.play_free('/home/tux/test.wav', 0., 5.5)
        """
        if self.__load(wav_path):
            self.parent.tts._wav_free(self.__wav_path, begin, end)

    def stop(self):
        """
        Stop the current played wave file.

            Exemple:
            >>> tux.wav.stop()
        """
        self.parent.tts.stop()

    def pause(self):
        """
        Pause the current played wave file.

            Exemple:
            >>> tux.wav.pause()
        """
        self.parent.tts.pause()

    def _continue(self):
        """
        Continue the playing of a paused wave file.

            Exemple:
            >>> tux.wav._continue()
        """
        self.parent.tts.play()

#==============================================================================
# TUXTCPCommunicator - micro - class
#==============================================================================
class TUXmicro(object):
    """
    Class which manages the microphone functions.

        Global variables of this class:
        "on_buffer" as EventControl : Event on new buffer from micro

        Example of associating a function to 'on_buffer' event:

            >>> def new_buffer(values):
            >>> ... print values
            >>> ...
            >>> tux.micro.on_buffer.connect(new_buffer)
            >>> tux.micro.on()

        Functions list for the users:
            tux.micro.on
            tux.micro.off
            tux.micro.capture_start
            tux.micro.capture_start_free
            tux.micro.capture_stop
    """

    def __init__(self,parent):
        self.parent = parent
        self.__state = False
        self.__state_mutex = threading.Lock()
        self.__process = None
        self.__process_mutex = threading.Lock()
        self.__mic_on_mutex = threading.Lock()
        self.__mic_on_flag = False
        self.__thread = None
        self.on_buffer = EventControl()
        self.on_capture_stop = EventControl()
        self.on_capture_start = EventControl()
        self.__capturing = False
        self.__capture_path = ""
        self.__capture_length = 0
        self.__capture_buffer = []
        self.__capture_idx = 0
        self.__capture_mutex = threading.Lock()

    def destroy(self):
        self.off()
        self.on_buffer.destroy()
        if self.__thread != None:
            if self.__thread.isAlive():
                self.__thread.join()

    def __on_capture_buffer(self, buffer):
        self.__capture_mutex.acquire()
        if not self.__capturing:
            self.__capture_mutex.release()
            return
        for val in buffer:
            self.__capture_buffer.append(val)
            if self.__capture_length != 0:
                if (self.__capture_length * 8000) <= len(self.__capture_buffer):
                    self.__capture_mutex.release()
                    self.capture_stop()
                    return
        self.__capture_mutex.release()

    def capture_start(self, out_path, length = 0):
        """
        Write the stream in a wav file.

            Parameters:
            "out_path" as string    : path of the wave file
            "length" as float       : duration of the capture in seconds
                                      When this parameters is omitted, the length
                                      is infinite. You must stop the recording
                                      with 'tux.micro.capture_stop()'

            Examples:
            >>> tux.micro.capture_start('/home/remi/Desktop/test.wav', 10.0)
            >>> tux.micro.capture_start('/home/remi/Desktop/test.wav')
        """
        self.capture_start_free(out_path, length)
        while self.__capturing:
            time.sleep(0.05)

    def capture_start_free(self, out_path, length = 0):
        """
        Write the stream in a wav file.

            Parameters:
            "out_path" as string    : path of the wave file
            "length" as float       : duration of the capture in seconds
                                      When this parameters is omitted, the length
                                      is infinite. You must stop the recording
                                      with 'tux.micro.capture_stop()'

            Examples:
            >>> tux.micro.capture_start_free('/home/remi/Desktop/test.wav', 10.0)
            >>> tux.micro.capture_start_free('/home/remi/Desktop/test.wav')
        """
        time.sleep(0.1)
        if self.__capturing:
            return False
        if not self.__get_state():
            return False
        self.__capture_path = out_path
        self.__capture_buffer = []
        self.__capture_length = length
        self.__capturing = True
        self.on_capture_start.notify()
        self.__capture_idx = self.on_buffer.connect(self.__on_capture_buffer)

    def capture_stop(self):
        """
        Stop the capture of the stream.
        """
        if not self.__capturing:
            return
        self.__capture_mutex.acquire()
        self.__capturing = False
        self.on_buffer.disconnect(self.__capture_idx)
        time.sleep(0.2)
        self.__capture_mutex.release()
        self.__write_capture()
        self.on_capture_stop.notify()

    def __write_capture(self):
        try:
            import wave
        except:
            return
        freqech = 8000
        sound_str = ""
        for val in self.__capture_buffer:
            sound_str += chr(val)
        try:
            wavfile = wave.open(self.__capture_path, 'w')
            wavfile.setparams((1, 1, freqech , len(self.__capture_buffer), 'NONE', 'not compressed'))
            wavfile.writeframes(sound_str)
            wavfile.close()
        except:
            pass
            
    def __set_state(self, value):
        self.__state_mutex.acquire()
        self.__state = value
        self.__state_mutex.release()
        
    def __get_state(self):
        self.__state_mutex.acquire()
        ret = self.__state
        self.__state_mutex.release()
        return ret
        
    def __set_mic_on_flag(self, value):
        self.__state_mutex.acquire()
        self.__mic_on_flag = value
        self.__state_mutex.release()
        
    def __get_mic_on_flag(self):
        self.__state_mutex.acquire()
        ret = self.__mic_on_flag
        self.__state_mutex.release()
        return ret

    def on(self):
        """
        Function to turn on the micro capture.

            Example:
            >>> tux.micro.on()
        """
        def get_micro_data():
            device = self.parent.hw.alsa_device
            cmd = ["arecord", "-D", device, "-t", "raw"]
            try:
                time.sleep(0.1)
                self.__process = subprocess.Popen(cmd, stdout = subprocess.PIPE, stderr = subprocess.PIPE)
            except:
                return 
            print 'MICRO STREAM: ACQUISITION ON'
            self.__set_state(True)
            while (self.__process.poll() == None):
                self.__process_mutex.acquire()
                buff = self.__process.stdout.read(800)
                self.__on_new_buffer(buff)
                self.__process_mutex.release()
                time.sleep(0.01)
            print 'MICRO STREAM: ACQUISITION OFF'
            self.__process_mutex.acquire()
            self.__process = None
            self.__process_mutex.release()
            self.__set_state(False)
        
        self.__mic_on_mutex.acquire()    
        if self.__get_state():
            self.__mic_on_mutex.release()
            return

        if self.__thread != None:
            if self.__thread.isAlive():
                self.__mic_on_mutex.release()
                self.__thread._Thread__stop()
                return
        
        self.__thread = threading.Thread(target=get_micro_data)
        self.__thread.setName('micro.on')
        self.__thread.start()
        self.__mic_on_mutex.release()

    def off(self):
        """
        Function to turn off the micro capture.

            Example:
            >>> tux.micro.off()
        """
        if not self.__get_state():
            return
        self.__process_mutex.acquire()
        try:
            if self.__process != None:
                os.kill(self.__process.pid, signal.SIGKILL)
                os.waitpid(-1, os.WNOHANG)
        except:
            pass
        self.__process_mutex.release()
        self.capture_stop()

    def __on_new_buffer(self, buffer):
        i_buffer = []
        for c in buffer:
            i_buffer.append(ord(c))
        if self.__get_state():
            self.__send_energy_monitoring(i_buffer)
            self.on_buffer.notify(i_buffer)

    def __send_energy_monitoring(self, buffer):
        def log_value(value):
            if value == 0:
                return 0
            return int(math.log(value) / math.log(128) * 128)

        try:
            e_total = 0
            for val in buffer:
                e_total += abs(val - 127)
            e_total /= 800
            e_total = log_value(e_total)

            e_table = []
            for i in range(4):
                e_m = 0
                i_b = i * 200
                i_e = i_b + 200
                for j in range(i_b, i_e):
                    e_m += abs(buffer[j] - 127)
                e_m /= 200
                e_m = log_value(e_m)
                e_table.append(e_m)
        except:
            return

        tmp_tcp_data = [chr(0)] * 16
        tmp_tcp_data[0] = chr(SOURCE_TUX)
        tmp_tcp_data[1] = chr(0)
        tmp_tcp_data[2] = chr(DATA_TP_RSP)
        tmp_tcp_data[3] = chr(SUBDATA_TP_STATUS)
        tmp_tcp_data[4] = chr(STATUS_MICRO_ENERGY)
        tmp_tcp_data[5] = chr(e_total)
        tmp_tcp_data[6] = chr(e_table[0])
        tmp_tcp_data[7] = chr(e_table[1])
        tmp_tcp_data[8] = chr(e_table[2])
        tmp_tcp_data[9] = chr(e_table[3])
        self.parent.misc.simulate_tcpip_frame(tmp_tcp_data)

#==============================================================================
# TUXTCPCommunicator - misc - class
#==============================================================================
class TUXmisc(object):
    """
    Class which manages the miscellaneous functions

        Functions list for the users:
            tux.misc.doc
            tux.misc.build_documentation
            tux.misc.print_api_version
            tux.misc.simulate_remote_key
            tux.misc.simulate_tcpip_frame
    """

    def __init__(self,parent):
        """
        Constructor of this class
        """
        self.parent=parent
        self.header_doc=''
        self.h_titre_b='<b><u><font size="3">'
        self.h_titre_e='</font></u></b>'
        self.h_class_b='<b><u><font size="2">'
        self.h_class_e='</font></u></b>'
        self.h_funct_b='<b><u><i><font size="2">'
        self.h_funct_e='</font></i></u></b>'

    def doc(self,element):
        """
        Print the docstring of an element of tux api

            Parameters:
            "element" as methode or class

            Examples:
            >>> tux.misc.doc(tux)
            >>> tux.misc.doc(tux.cmd.eyes_on)
        """
        c_header=''
        for i in range(80): c_header=c_header+'-'
        print c_header
        print element.__doc__
        print c_header

    def parse_class(self,class_num,class_obj,class_name,class_str,indent):
        """
        Not a user function
        """
        test=class_str.split("\n")
        # print class
        c_header=''
        my_doc=''
        for i in range(80-len(indent)): c_header=c_header+'-'
        my_doc='%s%s) Object : %s (%s)<br>'%(my_doc,class_num, \
                class_name,str(type(class_obj))[8:-2])
        self.header_doc=self.header_doc+indent+'<a href="#%s">'%(class_num) \
                +my_doc+'</a>'
        my_doc=indent+'<a name=%s></a>'%(class_num)+self.h_class_b+ \
                my_doc+self.h_class_e
        for line in test:
            if line.find('Functions list')!=-1:
                break
            my_doc=my_doc+indent+line[4:]+'<br>'
        # affine class str
        class_str=string.replace(class_str,' ','')
        test=class_str.split("\n")
        # functions
        i=0
        funct_ok=False
        for line in test:
            if line=='':
                funct_ok=False
            if funct_ok:
                line=line[line.rfind('.')+1:]
                i=i+1
                my_doc=my_doc+self.parse_function("%s.%d"%(class_num,i), \
                        class_name+'.'+line, getattr(class_obj,line).__doc__, \
                        indent+'   ')
            if line.find('Functionslist')!=-1:
                funct_ok=True
        # sub class
        for line in test:
            if line.find('asclass')!=-1:
                line=line[1:line[1:].find('"')+1]
                i=i+1
                my_doc=my_doc+self.parse_class("%s.%d"%(class_num,i), \
                        getattr(class_obj,line),class_name+'.'+line, \
                        getattr(class_obj,line).__doc__,indent+'   ')
        return my_doc

    def parse_function(self,funct_num,funct_name,funct_str,indent):
        """
        Not a user function
        """
        test=funct_str.split("\n")
        c_header=''
        my_doc=''
        for i in range(80-len(indent)): c_header=c_header+'-'
        my_doc='%s%s)\tMethode : %s<br>'%(my_doc,funct_num,funct_name)
        self.header_doc=self.header_doc+indent+'<a href="#%s">'%(funct_num) \
                +my_doc+'</a>'
        my_doc=indent+'<a name=%s></a>'%(funct_num)+self.h_funct_b+ \
                my_doc+self.h_funct_e
        for line in test:
            my_doc=my_doc+indent+line[4:]+'<br>'
        return my_doc

    def build_documentation(self,doc_path):
        """
        Build the documentation of this api

            Parameters:
            "doc_path" as string    : path of the output text file

            Example:
            >>> tux.misc.build_documentation('/home/remi/tuxapi_doc')
        """
        main_class=self.parent.__doc__
        c_header=''
        for i in range(80): c_header=c_header+'-'
        documentation='<html><HEAD>\
        <STYLE type="text/css">\
            A:LINK    {text-decoration : none;color : black;}\
            A:VISITED {text-decoration : none;color : black;}\
            A:HOVER   {text-decoration : none;color : red;}\
        </STYLE>\
        </HEAD>'
        documentation=documentation+'<body><pre>'
        documentation=documentation+self.h_titre_b+\
                'DOCUMENTATION OF TUXDROID PYTHON API %s'%(api_version)+ \
                self.h_titre_e+'<br>'
        documentation=documentation+'\n'
        self.header_doc='<br>'+self.h_class_b+'Table of content :'+ \
                self.h_class_e+'<br><br>'
        body_doc=self.parse_class('1',self.parent,'tux',main_class,'')
        self.header_doc=self.header_doc+'<br><br>'
        documentation=documentation+self.header_doc+body_doc+ \
                '</pre></body></html>'
        f=open(doc_path,'w')
        f.write(documentation)
        f.close()

    def print_api_version(self):
        """
        To print the version of the API

            Example:
            >>> tux.misc.print_api_version()
        """
        print "---------------------------------------------------------------"
        print "TUXDROID PYTHON API %s"%(api_version)
        print "---------------------------------------------------------------"

    def simulate_tcpip_frame(self, frame):
        """
        To simulate the receiving of a frame

            Parameters:
            "frame" as list of 16 char : fake frame

            Example:
            >>> tux.misc.simulate_tcpip_frame(<list of 16 chars>)
        """
        self.parent.tcp_data_fifo_lock_mutex.acquire()
        self.parent.tcp_data_fifo_lock.append(frame)
        self.parent.tcp_data_fifo_lock_mutex.release()
        self.parent.tcp_data_fifo_event_mutex.acquire()
        self.parent.tcp_data_fifo_event.append(frame)
        self.parent.tcp_data_fifo_event_mutex.release()
        if not self.parent.daemon.connected:
            self.parent._dispatch_data_main(frame)

    def simulate_remote_key(self, key):
        """
        To simulate the receiving of a remote key

            Parameters:
            "key" as integer    : remote key

            Example:
            >>> tux.misc.simulate_remote_key(K_OK)
        """
        tmp_tcp_data = [chr(0)] * 16
        tmp_tcp_data[0] = chr(SOURCE_TUX)
        tmp_tcp_data[1] = chr(0)
        tmp_tcp_data[2] = chr(DATA_TP_RSP)
        tmp_tcp_data[3] = chr(SUBDATA_TP_STATUS)
        tmp_tcp_data[4] = chr(DATAS_STATUS_IR_CODE)
        tmp_tcp_data[5] = chr(key)
        self.simulate_tcpip_frame(tmp_tcp_data)

#==============================================================================
# TUXTCPCommunicator - switch - class
#==============================================================================
class TuxSwitch(object):

    def __init__(self, parent, status):
        self.parent = parent
        self.__status = status
        self.on_press = EventControl()
        self.on_release = EventControl()
        self.parent._switches.append(self)

    def store_events(self):
        self.on_press.push()
        self.on_release.push()

    def restore_events(self):
        self.on_press.pop()
        self.on_release.pop()

    def clear_events(self):
        self.on_press.clear()
        self.on_release.clear()

    def _notify(self, status, value):
        if status == self.__status:
            if value == 0:
                self.on_release.notify()
            else:
                self.on_press.notify()

    def simulate(self, value):
        self._notify(self.__status, value)

    def get_status(self):
        return self.parent.status.get_one_status(self.__status)

