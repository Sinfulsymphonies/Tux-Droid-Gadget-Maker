#!/usr/bin/python
# -*- coding: latin-1 -*-

import sys
from tuxapi_const import *
import tuxapi_class
import tuxapi_wav_merger
import signal
import atexit

global tux

# If run as main, print version banner. Otherwise, keep quiet.
if __name__ == "__main__":
    misc = tuxapi_class.TUXmisc(None)
    misc.print_api_version()
    del misc
    # Trick to detect whether python is in interactive mode
    if not 'readline' in sys.modules:
        print "For interactive use, run: python -i tux.py"
        sys.exit(0)

tux=tuxapi_class.TUXTCPCommunicator()
wavs=tuxapi_wav_merger.WavMerger(tux)
tux.daemon.connect()
tux.tts.connect()
tux.daemon.set_my_client_name("Py Client")
tux.print_warnings=True
tux.daemon.auto_connect(True)
tux.tts.auto_connect(True)

def exit(signum,frame):
    sys.exit(signum)

def my_exitfunct():
    tux.destroy()

signal.signal(signal.SIGTERM, exit)
signal.signal(signal.SIGINT, exit)
atexit.register(my_exitfunct)

