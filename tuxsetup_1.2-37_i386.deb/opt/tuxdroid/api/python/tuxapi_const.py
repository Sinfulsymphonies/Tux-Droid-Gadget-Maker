# -----------------------------------------------------------------------------
# Tux Droid - API constants
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: tuxapi_const.py 155 2007-03-14 12:24:21Z remi $
# -----------------------------------------------------------------------------

#==============================================================================
# BEHAVIOR USB DAEMON constants
#==============================================================================

# Commands for move TUX Droid
# DEPRECATED! These are the commands used in the protocol between the dongle
# and Tux Droid, the daemon should do an abstraction of this by providing it's
# own commands. These are only useful when sending raw commands but they are
# probably out of date. Refer to commands.h if you want to send raw commands.
#
# TODO remove these commands and check that nothing is broken.
BLINK_EYES_CMD = 0x40
STOP_EYES_CMD = 0x32
MOVE_MOUTH_CMD = 0x41
STOP_MOUTH_CMD = 0x34
WAVE_WINGS_CMD = 0x80
STOP_WINGS_CMD = 0x30
SPIN_LEFT_CMD = 0x82
SPIN_RIGHT_CMD = 0x83
STOP_SPIN_CMD = 0x36

TURN_IR_ON_CMD = 0x17
TURN_IR_OFF_CMD = 0x18
IR_SEND_RC5_CMD = 0x91
IR_GET_RC5_CMD = 0x1A
IR_STOP_REC_CMD = 0x1B

LED_ON_CMD = 0x1A
LED_OFF_CMD = 0x1B
LED_L_ON_CMD = 0x1C
LED_L_OFF_CMD = 0x1D
LED_R_ON_CMD = 0x1E
LED_R_OFF_CMD = 0x1F

PLAY_SOUND_CMD = 0x90
STORE_SOUND_CMD = 0x52
STORE_INDEX_CMD = 0xD0
TEST_SOUND_CMD = 0x10

PING_TUX_CMD = 0x7F
SLEEP_MODE_ON_CMD = 0x20
SLEEP_MODE_OFF_CMD = 0x21

# Remote key enum
# TODO to be moved to tuxremote_const.py
K_0 = 0x00
K_1 = 0x01
K_2 = 0x02
K_3 = 0x03
K_4 = 0x04
K_5 = 0x05
K_6 = 0x06
K_7 = 0x07
K_8 = 0x08
K_9 = 0x09
K_STANDBY = 0X0C
K_MUTE = 0X0D
K_VOLUMEPLUS = 0X10
K_VOLUMEMINUS = 0X11
K_ESCAPE = 0X12
K_YES = 0X13
K_NO = 0X14
K_BACKSPACE = 0X15
K_STARTVOIP = 0X16
K_RECEIVECALL = 0X17
K_HANGUP = 0X18
K_STAR = 0X19
K_SHARP = 0X1A
K_RED = 0X1B
K_GREEN = 0X1C
K_BLUE = 0X1D
K_YELLOW = 0X1E
K_CHANNELPLUS = 0X20
K_CHANNELMINUS = 0X21
K_UP = 0X22
K_DOWN = 0X23
K_LEFT = 0X24
K_RIGHT = 0X25
K_OK = 0X26
K_FASTREWIND = 0X32
K_FASTFORWARD = 0X34
K_PLAYPAUSE = 0X35
K_STOP = 0X36
K_RECORDING = 0X37
K_PREVIOUS = 0X38
K_NEXT = 0X39
K_MENU = 0X3A
K_MOUSE = 0X3B
K_ALT = 0X3C

remote_bt_name=["K_0","K_1","K_2","K_3","K_4","K_5","K_6","K_7","K_8","K_9",\
"None","None","K_STANDBY","K_MUTE","None","None","K_VOLUMEPLUS","K_VOLUMEMINUS",\
"K_ESCAPE","K_YES","K_NO","K_BACKSPACE","K_STARTVOIP","K_RECEIVECALL","K_HANGUP",\
"K_STAR","K_SHARP","K_RED","K_GREEN","K_BLUE","K_YELLOW","None","K_CHANNELPLUS",\
"K_CHANNELMINUS","K_UP","K_DOWN","K_LEFT","K_RIGHT","K_OK","None","None","None","None",\
"None","None","None","None","None","None","None","K_FASTREWIND","None",\
"K_FASTFORWARD","K_PLAYPAUSE","K_STOP","K_RECORDING","K_PREVIOUS","K_NEXT",\
"K_MENU","K_MOUSE","K_ALT","None","None","None"]

# Status datas
DATAS_STATUS_WINGS_MOTOR_BACKWARD = 0x01
DATAS_STATUS_SPIN_MOTOR_BACKWARD = 0x02
DATAS_STATUS_SPIN_MOTOR_FORWARD = 0x03
DATAS_STATUS_MOUTH_OPEN_POSITION = 0x04
DATAS_STATUS_MOUTH_CLOSED_POSITION = 0x05
DATAS_STATUS_HEAD_PUSH_POSITION = 0x06
DATAS_STATUS_CHARGER_INHIBIT_SIGNAL = 0x07
DATAS_STATUS_WINGS_POSITION_SWITCH = 0x08
DATAS_STATUS_MOTOR_FOR_WINGS = 0x09
DATAS_STATUS_LEFT_BLUE_LED = 0x0A
DATAS_STATUS_I2C_SDA_LINE = 0x0B
DATAS_STATUS_I2C_SCL_LINE = 0x0C
DATAS_STATUS_HEAD_MOTOR_FOR_MOUTH = 0x0D
DATAS_STATUS_HEAD_MOTOR_FOR_EYES = 0x0E
DATAS_STATUS_IR_RECEIVER_SIGNAL = 0x0F
DATAS_STATUS_SPIN_POSITION_SWITCH = 0x10
DATAS_STATUS_WINGS_MOTOR_FORWARD = 0x11
DATAS_STATUS_IR_LED = 0x12
DATAS_STATUS_EYES_OPEN_POSITION_SWITCH = 0x13
DATAS_STATUS_EYES_CLOSED_POSITION_SWITCH = 0x14
DATAS_STATUS_LEFT_WING_PUSH = 0x15
DATAS_STATUS_RIGHT_WING_PUSH = 0x16
DATAS_STATUS_POWER_PLUG_SWITCH = 0x17
DATAS_STATUS_HEAD_PUSH_SWITCH = 0x18
DATAS_STATUS_CHARGER_LED_STATUS = 0x19
DATAS_STATUS_MUTE_STATUS = 0x1A
DATAS_STATUS_LIGHT_LEVEL = 0x1B
DATAS_STATUS_EYES_POSITION_COUNTER = 0x1C
DATAS_STATUS_MOUTH_POSITION_COUNTER = 0x1D
DATAS_STATUS_WINGS_POSITION_COUNTER = 0x1E
DATAS_STATUS_SPIN_POSITION_COUNTER = 0x1F
DATAS_STATUS_RIGHT_BLUE_LED = 0x20
DATAS_STATUS_RF_CONNECTED = 0x21
DATAS_STATUS_IR_CODE = 0x22
DATAS_STATUS_SOUND_COUNT = 0x23
DATAS_STATUS_PONG = 0x24
DATAS_STATUS_BATTERY = 0x25
DATAS_STATUS_MICRO_ENERGY = 0xF0
DATAS_STATUS_AUDIO = 0x26

STATUS_WINGS_MOTOR_BACKWARD = 0x01
STATUS_SPIN_MOTOR_BACKWARD = 0x02
STATUS_SPIN_MOTOR_FORWARD = 0x03
STATUS_MOUTH_OPEN_POSITION = 0x04
STATUS_MOUTH_CLOSED_POSITION = 0x05
STATUS_HEAD_PUSH_POSITION = 0x06
STATUS_CHARGER_INHIBIT_SIGNAL = 0x07
STATUS_WINGS_POSITION_SWITCH = 0x08
STATUS_MOTOR_FOR_WINGS = 0x09
STATUS_LEFT_BLUE_LED = 0x0A
STATUS_I2C_SDA_LINE = 0x0B
STATUS_I2C_SCL_LINE = 0x0C
STATUS_HEAD_MOTOR_FOR_MOUTH = 0x0D
STATUS_HEAD_MOTOR_FOR_EYES = 0x0E
STATUS_IR_RECEIVER_SIGNAL = 0x0F
STATUS_SPIN_POSITION_SWITCH = 0x10
STATUS_WINGS_MOTOR_FORWARD = 0x11
STATUS_IR_LED = 0x12
STATUS_EYES_OPEN_POSITION_SWITCH = 0x13
STATUS_EYES_CLOSED_POSITION_SWITCH = 0x14
STATUS_LEFT_WING_PUSH = 0x15
STATUS_RIGHT_WING_PUSH = 0x16
STATUS_POWER_PLUG_SWITCH = 0x17
STATUS_HEAD_PUSH_SWITCH = 0x18
STATUS_CHARGER_LED = 0x19
STATUS_MUTE_STATUS = 0x1A
STATUS_LIGHT_LEVEL = 0x1B
STATUS_EYES_POSITION_COUNTER = 0x1C
STATUS_MOUTH_POSITION_COUNTER = 0x1D
STATUS_WINGS_POSITION_COUNTER = 0x1E
STATUS_SPIN_POSITION_COUNTER = 0x1F
STATUS_RIGHT_BLUE_LED = 0x20
STATUS_RF_CONNECTED = 0x21
STATUS_IR_CODE = 0x22
STATUS_SOUND_COUNT = 0x23
STATUS_PONG = 0x24
STATUS_BATTERY = 0x25
STATUS_AUDIO = 0x26
STATUS_MICRO_ENERGY = 0xF0

# Tux connection commands
TUX_CONNECTION_DISCONNECT = 1
TUX_CONNECTION_CONNECT = 2
TUX_CONNECTION_RANDOM = 3
TUX_CONNECTION_ID_REQUEST = 4
TUX_CONNECTION_ID_LOOKUP = 5
TUX_CONNECTION_CHANGE_ID = 6
TUX_CONNECTION_SLEEP = 7
TUX_CONNECTION_WAKEUP = 8
TUX_CONNECTION_WIRELESS_CHANNEL = 9

# Tux connection command ack
TUX_CONNECTION_NACK = 0
TUX_CONNECTION_ACK = 1
TUX_CONNECTION_NOTFOUND = 2

# Datas TuxDroid
DATAS_STATUS_DONGLE = 0x00
DATAS_STATUS_RF = 0x01
DATAS_STATUS_CMD = 0x02

# ------------------ Frame encapsulation ---------------------------------
# ------ Destination header ------//
# Destinations
DEST_MASTER_DAEMON = 0x00
DEST_SUB_DAEMON = 0x01
DEST_TUX = 0x02
DEST_RESOURCE = 0x03
DEST_CLIENT = 0x04
# Sub destination
SD_DEFAULT = 0x00
SD_ALL = 0xFF
# ------ Source header ------/
# Source
SOURCE_MASTER_DAEMON = 0x00
SOURCE_SUB_DAEMON = 0x01
SOURCE_TUX = 0x02
SOURCE_RESOURCE = 0x03
SOURCE_CLIENT = 0x04
# Sub source
SS_DEFAULT = 0x00
# ------ Data header ------//
# Data types
DATA_TP_CMD = 0x01
DATA_TP_REQ = 0x02
DATA_TP_RSP = 0x03
DATA_TP_ACK_CMD = 0x04
DATA_TP_ACK_DP  = 0x05
USB_CONNECTION_CMD = 0x06
# Sub data types
SUBDATA_TP_RAW = 0x01
SUBDATA_TP_STRUCT = 0x02
SUBDATA_TP_STATUS = 0x03
SUBDATA_TP_INFO = 0x04
# ------------------------------ ACK --------------------------------------//
# ACK daemon processing
ACK_DP_OK = 0x01
ACK_DP_UKN_DEST = 0x02
ACK_DP_UKN_SUBDEST = 0x03
ACK_DP_UKN_DATA_TP = 0x04
ACK_DP_UKN_SUBDATA_TP = 0x05
ACK_DP_NI = 0xFF
# ACK CMD
ACK_CMD_DONGLE_NOT_PRESENT = 0x00
ACK_CMD_TIMEOUT = 0x01
ACK_CMD_OK = 0x02
ACK_CMD_KO = 0x03
ACK_CMD_ERROR = 0xFF
# ----------------------------- Sub daemon const --------------------------//
# Sub daemon commands
SUB_D_CMD_STRUC_DISCONNECT_CLIENT = 0x01
SUB_D_CMD_STRUC_KILL_DAEMON = 0x02
SUB_D_CMD_STRUC_DEFINE_CLIENT_NAME = 0x03
SUB_D_CMD_STRUC_DISCONNECT_CLIENT_ME = 0x04
# Sub daemon infos
SUB_D_REQ_INFO_VERSION = 0x01
SUB_D_REQ_INFO_CLIENT_COUNT = 0x02
SUB_D_REQ_INFO_CLIENT_NAME = 0x03
SUB_D_REQ_INFO_MY_CLIENT_ID = 0x04
# ----------------------------- TUX const ---------------------------------//
# Tux structured commands
TUX_CMD_STRUCT_EYES = 0x01
TUX_CMD_STRUCT_MOUTH = 0x02
TUX_CMD_STRUCT_WINGS = 0x03
TUX_CMD_STRUCT_SPINL = 0x04
TUX_CMD_STRUCT_SPINR = 0x05
TUX_CMD_STRUCT_IR = 0x06
TUX_CMD_STRUCT_LEDS = 0x07
TUX_CMD_STRUCT_LEDL = 0x08
TUX_CMD_STRUCT_LEDR = 0x09
TUX_CMD_STRUCT_SOUND = 0x0A
TUX_CMD_STRUCT_PING = 0x0B
TUX_CMD_STRUCT_SLEEP = 0x0C
TUX_CMD_STRUCT_AUDIO_CHANNEL = 0x0D
# Tux structured sub commands
TUX_CMD_STRUCT_SUB_ON = 0x01
TUX_CMD_STRUCT_SUB_OFF = 0x02
TUX_CMD_STRUCT_SUB_ON_DURING = 0x03
TUX_CMD_STRUCT_SUB_SEND = 0x04
TUX_CMD_STRUCT_SUB_PLAY = 0x05
TUX_CMD_STRUCT_SUB_STORING = 0x06
TUX_CMD_STRUCT_SUB_STORE_INDEX = 0x07
TUX_CMD_STRUCT_SUB_TEST = 0x08
TUX_CMD_STRUCT_SUB_BLINK = 0x09
TUX_CMD_STRUCT_SUB_CH_GENERAL = 0x0A
TUX_CMD_STRUCT_SUB_CH_TTS = 0x0B
# Tux request information
TUX_REQ_INFO_VERSION = 0x01

#==============================================================================
# TTS DAEMON constants
#==============================================================================

# Commands type
CMD_TYPE_SOUND_CONF = 0x01
CMD_TYPE_TTS = 0x02
CMD_TYPE_DAEMON = 0x03
CMD_TYPE_INFO = 0x04
CMD_TYPE_WAV = 0x05
# Sound conf commands
CMD_SOUNDCONF_REINIT = 0X01
CMD_SOUNDCONF_STOP = 0X02
# WAV commands
CMD_WAV_INSERT_PLAY	= 0x01
CMD_WAV_BEGIN_END = 0x02
# TTS commands
CMD_TTS_CHOOSE_VOICE = 0x01
CMD_TTS_INSERT_PLAY_SPEECH = 0x02
CMD_TTS_PLAY = 0x03
CMD_TTS_PAUSE = 0x04
CMD_TTS_STOP = 0x05
# Daemon commands
CMD_DAEMON_DISCONNECT_CLIENT = 0x01
CMD_DAEMON_PRINT_FIFO_STATE = 0x02
CMD_DAEMON_PRINT_TUX_SOUND_CARDS = 0x03
CMD_DAEMON_KILL = 0x04
# Speakers
SPK_FR_MALE = 0x01
SPK_FR_MALE_NAME = "Bruno8k"
SPK_FR_FEMALE = 0x02
SPK_FR_FEMALE_NAME = "Julie8k"
SPK_US_MALE = 0x03
SPK_US_MALE_NAME = "Ryan8k"
SPK_US_FEMALE = 0x04
SPK_US_FEMALE_NAME = "Heather8k"
SPK_B_FEMALE = 0x05
SPK_B_FEMALE_NAME = "Sofie8k"
SPK_D_MALE = 0x06
SPK_D_MALE_NAME = "Klaus8k"
SPK_D_FEMALE = 0x07
SPK_D_FEMALE_NAME = "Sarah8k"
SPK_GB_MALE = 0x08
SPK_GB_MALE_NAME = "Graham8k"
SPK_GB_FEMALE = 0x09
SPK_GB_FEMALE_NAME = "Lucy8k"
SPK_AR_FEMALE = 0x0A
SPK_AR_FEMALE_NAME = "Salma8k"
SPK_DK_FEMALE = 0x0B
SPK_DK_FEMALE_NAME = "Mette8k"
SPK_E_FEMALE = 0x0C
SPK_E_FEMALE_NAME = "Maria8k"
SPK_I_FEMALE = 0x0D
SPK_I_FEMALE_NAME = "Chiara8k"
SPK_NL_FEMALE = 0x0E
SPK_NL_FEMALE_NAME = "Femke8k"
SPK_N_FEMALE = 0x0F
SPK_N_FEMALE_NAME = "Kari8k"
SPK_P_FEMALE = 0x10
SPK_P_FEMALE_NAME = "Celia8k"
SPK_S_MALE = 0x11
SPK_S_MALE_NAME = "Erik8k"
SPK_S_FEMALE = 0x12
SPK_S_FEMALE_NAME = "Emma8k"
SPK_VOICE_LIST = (SPK_FR_MALE, SPK_FR_FEMALE, SPK_US_MALE, SPK_US_FEMALE, \
    SPK_B_FEMALE, SPK_D_MALE, SPK_D_FEMALE, SPK_GB_MALE, SPK_GB_FEMALE, \
    SPK_AR_FEMALE, SPK_DK_FEMALE, SPK_E_FEMALE, SPK_I_FEMALE, SPK_NL_FEMALE, \
    SPK_N_FEMALE, SPK_P_FEMALE, SPK_S_MALE, SPK_S_FEMALE)
SPK_NAMES_LIST = ("Bruno8k", "Julie8k", "Ryan8k", "Heather8k","Sofie8k", "Klaus8k",\
"Sarah8k", "Graham8k","Lucy8k", "Salma8k", "Mette8k", "Maria8k", "Chiara8k",\
"Femke8k", "Kari8k", "Celia8k", "Erik8k", "Emma8k")
LANG_OF_SPK_LIST = (    "FRENCH : Bruno",
                        "FRENCH : Julie",
                        "US_ENGLISH : Ryan",
                        "US_ENGLISH : Heather",
                        "BE_DUTCH : Sofie",
                        "GERMAN : Klaus",
                        "GERMAN : Sarah",
                        "GB_ENGLISH : Graham",
                        "GB_ENGLISH : Lucy",
                        "ARABIC : Salma",
                        "DANISH : Mette",
                        "SPANISH : Maria",
                        "ITALIAN : Chiara",
                        "NL_DUTCH : Femke",
                        "NORWEGIAN : Kari",
                        "PORTUGUESE : Celia",
                        "SWEDISH : Erik",
                        "SWEDISH : Emma")
SPK_LIST_BY_LANG = (    ("D", "German","Sarah8k", "Klaus8k"),
                        ("GB", "English","Lucy8k", "Graham8k"),
                        ("US", "English", "Heather8k", "Ryan8k"),
                        ("AR", "Arabic", "Salma8k", ""),
                        ("DK", "Danish", "Mette8k", ""),
                        ("E", "Spanish", "Maria8k", ""),
                        ("F", "French", "Julie8k", "Bruno8k"),
                        ("I", "Italian", "Chiara8k", ""),
                        ("B", "Dutch", "Sofie8k", ""),
                        ("NL", "Dutch", "Femke8k", ""),
                        ("N", "Norwegian", "Kari8k", ""),
                        ("P", "Portuguese", "Celia8k", ""),
                        ("S", "Swedish", "Emma8k", "Erik8k")
                    )
# Return type
RET_ACK = 0x01
TTS_INFO = 0x02
DAEMON_INFO = 0x03
WAV_INFO = 0x04
# ACK return
ACK_OK = 0x01
ACK_UNKNOW_CMD_TYPE = 0x02
ACK_UNKNOW_CMD = 0x03
ACK_BAD_PARAMETER = 0x04
ACK_ERROR = 0x05
# TTS INFO type
CMD_INFO_TTS_PLAYER_STATE = 0x01
CMD_INFO_SOUND_STATE = 0x02
CMD_INFO_VOICE_LIST = 0x03
CMD_INFO_VOICE_OK = 0x04
# TTS INFO return
TTS_SOUND_ON = 0x01
TTS_SOUND_OFF = 0x02
TTS_PAUSED = 0x03
TTS_PLAYED = 0x04
TTS_STOPED = 0x05
# DAEMON INFO return
DAEMON_INFO_KILLED = 0x01

#==============================================================================
# Misc constants
#==============================================================================

HEAD_BT =1
LEFT_WING_BT =2
RIGHT_WING_BT =3
NONE_BT =0
NULL_BT =0xFF

HEAD_BUTTON_PUSHED =1
HEAD_BUTTON_RELEASED =2
LEFT_WING_PUSHED =3
LEFT_WING_RELEASED =4
RIGHT_WING_PUSHED =5
RIGHT_WING_RELEASED =6

CT_SHELL =1
CT_FUNCTION =2
