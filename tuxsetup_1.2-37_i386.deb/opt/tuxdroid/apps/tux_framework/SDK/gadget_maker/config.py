# editor command
# %s will be replaced by the filename
editor = "gedit %s"
