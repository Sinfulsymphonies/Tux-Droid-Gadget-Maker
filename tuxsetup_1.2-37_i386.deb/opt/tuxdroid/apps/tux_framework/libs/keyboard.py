#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - Keyboard
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import thread
import threading
import time
import fcntl
import os
import sys
import tty
import termios

_KEYB_UP = [27, 91, 65]
KEYB_UP = 'keyb_up'

_KEYB_DOWN = [27, 91, 66]
KEYB_DOWN = 'keyb_down'

_KEYB_BACKSPACE = [127]
KEYB_BACKSPACE = 'keyb_backspace'

_KEYB_ESC = [27]
KEYB_ESC = 'keyb_esc'

_KEYB_DEL = [27, 91, 51]
KEYB_DEL = 'keyb_del'

_KEYB_RETURN = [13]
KEYB_RETURN = 'keyb_return'

_KEYB_SPACE = [32]
KEYB_SPACE = 'keyb_space'

def read_timeout(timeout):
    t = time.time()
    ch = chr(0)
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    fcntl.fcntl(sys.stdin.fileno(), fcntl.F_SETFL, os.O_NONBLOCK)
    tty.setraw(sys.stdin.fileno())
    backsp = ""
    for i in range(30):
        backsp = backsp + '\b'
    sys.stdout.write(backsp)
    sys.stdout.flush()
    try:
        while (ch == chr(0)) and (time.time() < t + timeout):
            try:
                ch = sys.stdin.read(3)
            except IOError:
                pass
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch

class tuxdroid_keyboard(object):

    def __init__(self):
        self.paused = True
        self.terminate = False
        self.run_th = None
        self.clear()

    def set_on_key_pressed(self, name, funct, *params):
        self.on_key_pressed[name].pop()
        self.on_key_pressed[name].pop()
        self.on_key_pressed[name].append(funct)
        self.on_key_pressed[name].append(*params)

    def store(self):
        self.on_key_pressed_save_list.append(self.on_key_pressed)

    def restore(self):
        if len(self.on_key_pressed_save_list) > 0:
            self.on_key_pressed = self.on_key_pressed_save_list.pop()

    def clear(self):
        self.on_key_pressed = {}
        self.on_key_pressed[KEYB_UP] = [_KEYB_UP, None, ()]
        self.on_key_pressed[KEYB_DOWN] = [_KEYB_DOWN, None, ()]
        self.on_key_pressed[KEYB_BACKSPACE] = [_KEYB_BACKSPACE, None, ()]
        self.on_key_pressed[KEYB_ESC] = [_KEYB_ESC, None, ()]
        self.on_key_pressed[KEYB_RETURN] = [_KEYB_RETURN, None, ()]
        self.on_key_pressed[KEYB_DEL] = [_KEYB_DEL, None, ()]
        self.on_key_pressed[KEYB_SPACE] = [_KEYB_SPACE, None, ()]
        self.on_key_pressed_save_list = []

    def _run(self):
        while not self.terminate:
            while not self.paused:
                if self.terminate:
                    break
                keyb_int = read_timeout(0.1)
                keys = [ord(key) for key in keyb_int]
                if keys != [0]:
                    #print keys
                    if keys in [[3], [4]]:
                        self.terminate = True
                        break
                    for okp in self.on_key_pressed:
                        if self.on_key_pressed[okp][1] != None:
                            if self.on_key_pressed[okp][0] == keys:
                                self.on_key_pressed[okp][1](*self.on_key_pressed[okp][2])
            time.sleep(0.1)

    def run(self):
        self.run_th = threading.Thread(target = self._run)
        self.run_th.setName('tuxdroid_keyboard.run')
        self.run_th.start()

    def join(self):
        if self.run_th == None:
            return
        if self.run_th.isAlive():
            self.run_th.join()
