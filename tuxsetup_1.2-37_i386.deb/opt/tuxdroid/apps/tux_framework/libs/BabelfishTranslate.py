#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Babelfish translate
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import urllib
import httplib
import socket
import string
from GdgDownload import check_server_available

GT_ENGLISH = 'en'
GT_FRENCH = 'fr'
GT_ITALIAN = 'it'
GT_SPANISH = 'es'
GT_DUTCH = 'nl'
GT_PORTUGUESE = 'pt'

BABELFISH_LANGPAIRS = [
    'en_nl',
    'nl_en',
    'nl_fr',
    'fr_it',
    'fr_pt',
    'fr_nl',
    'fr_es',
    'it_fr',
    'pt_fr',
    'es_fr',
]

def clean(text):
    return ' '.join(string.replace(text.strip(), "\n", ' ').split())

def babelfish_translate(from_lang, to_lang, text):

    #check if server is available
    if not check_server_available("babelfish.altavista.com", 4):
        return ""
    
    text = clean(text)
    params = urllib.urlencode({ "lp":"%s_%s"%(from_lang, to_lang), 
                                "urltext":text, 
                                "doit":"done", 
                                'BabelFishFrontPage':'yes',
                              })
    socket.setdefaulttimeout(7)
    try:
        resp = urllib.urlopen('http://babelfish.altavista.com/tr', params)
    except:
        return ""
    s = resp.read()
    
    idx_b = s.find('<input type=hidden name="q" value="')
    if idx_b == -1:
        idx_b = s.find('<td bgcolor=white class=s><div style=padding:10px;>')
        if idx_b == -1:
            return ""
        else:
            idx_b += 51
            idx_e = s[idx_b:].find('</div>') + idx_b
            trad = s[idx_b:idx_e]
    else:
        idx_b += 35
        idx_e = s[idx_b:].find('">') + idx_b
        trad = s[idx_b:idx_e]

    if len(trad) > 0:
        return trad
    else:
        return ""
