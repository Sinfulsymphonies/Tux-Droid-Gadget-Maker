#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget Format - Parser
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import sys
import os
import string
from copy import deepcopy

from TGFCanvas import *
from TGFXml import *

class TGFError(Exception):
    """
    Class which show an error message when an exception occured
    """

    def __init__(self, value):
        """
        Constructor
        """
        self.value = value

    def __str__(self):
        """
        Methode which return the string value to showing
        """
        return self.value


class TGFParser(object):
    """
    Class which parse a TGF file.

        Global variables of this class:
        "tgf_path" as string     : Path of the TGF file.
        "version" as string      : Version of this class.

        Objects in this class:
        "about" as instance of class(TGFParseAbout) :
                    Object which manages the 'about' xml file.
        "GUI" as instance of class(TGFParseGUI )    :
                    Object which manages the GUI files.
        "i18n" as instance of class(TGFParseI18N)   :
                    Object which manages the internationalization files
        "icons" as instance of class(TGFParseIcons) :
                    Object which manages the 'png' icons.
        "libs" as instance of class(TGFParseLibs)   :
                    Object which manages the added python libraries.
        "scripts" as instance of class(TGFParseScripts)  :
                    Object which manages the script files of the TGF file.
        "settings" as instance of class(TGFParseSettings)  :
                    Object which manages the 'settings' xml file.
        "sounds" as instance of class(TGFParseSounds) :
                    Object which manages the wav files.

        Defines:
        "lang_country_list" as list of strings:
            This list contains the supported languages by the TGF files.
            ['de_ALL', 'en_GB', 'en_US', 'ar_ALL', 'da_ALL', 'es_ALL',
            'fr_ALL', 'it_ALL', 'nl_BE', 'nl_NL', 'no_ALL', 'pt_ALL',
            'sv_ALL']
        "lang_ab_to_lang_country" as dictionary:
            Is a tux api - TGF translation of the languages name.
            {'D' : 'de_ALL',
            'GB' : 'en_GB',
            'US' : 'en_US',
            'AR' : 'ar_ALL',
            'DK' : 'da_ALL',
            'E' : 'es_ALL',
            'F' : 'fr_ALL',
            'I' : 'it_ALL',
            'B' : 'nl_BE',
            'NL' : 'nl_NL',
            'N' : 'no_ALL',
            'P' : 'pt_ALL',
            'S' : 'sv_ALL'}

        Functions list for the users:
            parser.__init__
            parser.create
            parser.read
            parser.write

    """

    version = '0.0.1-beta'

    def __init__(self, tgf_path):
        """
        Constructor

            Parameters:
            'tgf_path' as string    : Path of the TGF file.
        """
        tgf_path = tgf_path.replace('%20', ' ')
        # Main path of tgf file
        if not os.path.exists(tgf_path):
            raise TGFError("'%s' is not a valid path" % tgf_path)
            return
        self.tgf_path = tgf_path
        self.settings = TGFParseSettings(self)
        self.about = TGFParseAbout(self)
        self.i18n = TGFParseI18N(self)
        self.GUI = TGFParseGUI(self)
        self.scripts = TGFParseScripts(self)
        self.libs = TGFParseLibs(self)
        self.icons = TGFParseIcons(self)
        self.sounds = TGFParseSounds(self)

    def read(self):
        """
        Read a TGF file.
        """
        # Attempt to read 'settings.xml'
        if not self.settings.read():
            raise TGFError("'settings.xml' file can't be read")
        # Attempt to read 'about.xml'
        if not self.about.read():
            raise TGFError("'about.xml' file can't be read")
        # Attempt to read 'strings.xml'
        if not self.i18n.read('en_US'):
            raise TGFError("'strings.xml' file can't be read")

        # Attempt to read the language string files
        self.lang_files = []
        for root, dirs, files in os.walk(self.tgf_path + '/Strings'):
            self.lang_files = files
        for filee in self.lang_files:
            lang_country = filee.replace('.xml', '')
            lang_country = lang_country.replace('.XML', '')
            if not self.i18n.read(lang_country):
                return
        # Read GUIs
        self.GUI.read()
        # Read scripts
        self.scripts.read()
        # Read libraries
        self.libs.read()
        # Read icons
        self.icons.read()
        # Read sounds
        self.sounds.read()
        # Set icon path
        ico_path = self.tgf_path + gadget_png_rel_path
        if os.path.exists(ico_path):
            self.gadget_png_path = ico_path
        # Create missing paths
        data_path = self.tgf_path + '/Data'
        behav_path = self.tgf_path + '/Data/Behaviors'
        filt_path = self.tgf_path + '/Data/Filters'
        if not os.path.exists(data_path): os.makedirs(data_path, 511)
        if not os.path.exists(behav_path): os.makedirs(behav_path, 511)
        if not os.path.exists(filt_path): os.makedirs(filt_path, 511)
        ### patch
        self.i18n.add_message('help_text', '')

    def write(self):
        """
        Write the TGF file.
        """
        # Ensure that the directories structure exists
        self.__create_directories_structure()
        # Write 'settings.xml'
        if not self.settings.write():
            raise TGFError("'settings.xml' file can't be written")
        # Write 'about.xml'
        if not self.about.write():
            raise TGFError("'about.xml' file can't be written")
        # Write 'strings.xml'
        if not self.i18n.write('en_US'):
            return
        # Attempt to read the language string files
        for key in self.i18n.languages_struct.keys():
            if key == 'en_US':
                continue
            if not self.i18n.write(key):
                return

    def create(self):
        """
        Create a new TGF file.
        """
        # Ensure that the directories structure exists
        self.__create_directories_structure()
        self.settings.create()
        self.about.create()
        self.i18n.create('en_US')
        self.languages_struct_array['en_US'] = self.strings_struct

    def __create_directories_structure(self):
        """
        Create the directories structure
        """
        # 'Strings' Directory
        if not os.path.exists(self.tgf_path + '/Strings'):
            os.makedirs(self.tgf_path + '/Strings', 511)
        # 'Pictures/Icons' Directory
        if not os.path.exists(self.tgf_path + '/Pictures/Icons'):
            os.makedirs(self.tgf_path + '/Pictures/Icons', 511)
        # 'Pictures/GUI' Directory
        if not os.path.exists(self.tgf_path + '/Pictures/GUI'):
            os.makedirs(self.tgf_path + '/Pictures/GUI', 511)
        # 'Sounds' Directory
        if not os.path.exists(self.tgf_path + '/Sounds'):
            os.makedirs(self.tgf_path + '/Sounds', 511)
        # 'Data' Directory
        if not os.path.exists(self.tgf_path + '/Data'):
            os.makedirs(self.tgf_path + '/Data', 511)

    def get_file(self, src_path):
        return self.__get_file(src_path)

    def __get_file(self, src_path):
        """
        Read a file
        """
        dest = ''
        try:
            f = open(src_path, 'rb')
        except IOError:
            return False, dest
        dest = f.read()
        f.close()
        dest = dest.replace(' thread.start_new_thread', ' gadget_thread.start_new_thread')
        return True, dest

    def __set_file(self, dest_path, src):
        """
        Read a file
        """
        try:
            f = open(dest_path, 'w')
        except IOError:
            return False
        f.write(src)
        f.close()
        return True

    def build_documentation(self, doc_path, self_class, self_name, version):
        """
        Build the documentation of a class

            Parameters:
            "doc_path" as string    : path of the output text file
        """
        import C2MEDoc
        doc = C2MEDoc.C2MEDoc()
        doc.write(doc_path, self_class, self_name, version)

class TGFParseI18N(object):
    """
    Class which manages the internationalization files of the TGF file.

        Global variables of this class:
        "languages_struct" as dict      : Dictionary of languages

        Functions list for the users:
            parser.i18n.add_language
            parser.i18n.delete_language
            parser.i18n.get_languages_list
            parser.i18n.add_message
            parser.i18n.delete_message
            parser.i18n.get_messages_list
            parser.i18n.get_message_value_dict
            parser.i18n.set_message_value
    """

    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent
        self.default_struct = {}
        self.languages_struct = {}

    def read(self, lang_country = 'en_US'):
        """
        Read a I18N xml file.

            Parameters:
            "lang_country" as string    : Language acronym

            Returns:
            "True" if the language has been read.
        """
        if lang_country == 'en_US':
            strings_path = self.parent.tgf_path + strings_xml_rel_path
            val, self.default_struct = xml_to_struct(self.default_struct, strings_path)
            self.languages_struct['en_US'] = self.default_struct
            return val
        else:
            strings_dir_path = self.parent.tgf_path + '/Strings'
            ln_path = '%s/%s.xml' % (strings_dir_path, lang_country)
            if not f_language_dict.has_key(lang_country):
                raise TGFError("Language '%s' not accepted" % lang_country)
                return False
            language_struct = None
            val, language_struct = xml_to_struct(language_struct, ln_path)
            self.languages_struct[lang_country] = deepcopy(language_struct)
            return val

    def write(self, lang_country = 'en_US'):
        """
        Write a I18N xml file.

            Parameters:
            "lang_country" as string    : Language acronym

            Returns:
            "True" if the language has been written.
        """
        if lang_country == 'en_US':
            ln_path = self.parent.tgf_path + strings_xml_rel_path
        else:
            strings_dir_path = self.parent.tgf_path + '/Strings'
            ln_path = '%s/%s.xml' % (strings_dir_path, lang_country)
            if not f_language_dict.has_key(lang_country):
                raise TGFError("I18N : language '%s' not accepted" % lang_country)
                return False

        return struct_to_xml(self.languages_struct[lang_country], ln_path)

    def create(self, lang_country):
        """
        Create a new I18N xml file.

            Parameters:
            "lang_country" as string    : Language acronym

            Returns:
            "True" if the language has been created.
        """
        if lang_country == 'en_US':
            strings_path = self.parent.tgf_path + strings_xml_rel_path
            struct_to_xml(strings_struct, strings_path)
            self.default_struct = strings_struct
            return True
        else:
            if not f_language_dict.has_key(lang_country):
                raise TGFError("I18N : language '%s' not accepted" % lang_country)
                return False
            new_lang = deepcopy(self.default_struct)
            if self.languages_struct.has_key(lang_country):
                return True
            self.languages_struct[lang_country] = new_lang
            strings_dir_path = self.parent.tgf_path + '/Strings'
            if not os.path.exists(strings_dir_path):
                os.mkdir(strings_dir_path)
            new_lang_path = '%s/%s.xml' % (strings_dir_path, lang_country)
            return struct_to_xml(new_lang, new_lang_path)

    def add_language(self, lang_country):
        """
        Add a language.

            Parameters:
            "lang_country" as string    : Language acronym

            Returns:
            A boolean which indicates if the language has been added.
        """
        return self.create(lang_country)

    def delete_language(self, lang_country):
        """
        Remove a language.

            Parameters:
            "lang_country" as string    : Language acronym

            Returns:
            A boolean which indicates if the language has been deleted.
        """
        if not f_language_dict.has_key(lang_country):
            raise TGFError("I18N : anguage '%s' not accepted" % lang_country)
            return False
        if self.languages_struct.has_key(lang_country):
            # Delete file
            strings_dir_path = self.parent.tgf_path + '/Strings'
            ln_path = '%s/%s.xml' % (strings_dir_path, lang_country)
            if os.path.exists(ln_path):
                os.remove(ln_path)
            # Delete struct
            self.languages_struct.pop(lang_country)
            return True
        else:
            return False

    def get_languages_list(self):
        """
        Get the list of the languages supported.

            Returns:
            the list of languages acronym.
        """
        return self.languages_struct.keys()

    def get_messages_list(self):
        """
        Get the list of the messages.

            Returns:
            The list of the messages name.
        """
        return self.languages_struct['en_US']['strings'].keys()

    def get_message_value_dict(self, msg_name):
        """
        Get the translations of a message.

            Parameters:
            "msg_name" as string    : Name of the message

            Returns:
            A dictionary of values by language acronym.
        """
        result = {}
        lns = self.get_languages_list()
        if self.languages_struct['en_US']['strings'].has_key(msg_name):
            for ln in lns:
                result[ln] = self.languages_struct[ln]['strings'][msg_name]
        return result

    def set_message_value(self, msg_name, msg_value, lang_country):
        """
        Set the value of a message for the specified language.

            Parameters:
            "msg_name" as string     : Name of the message
            "msg_value" as string    : Value of the message
            "lang_country" as string : Language acronym

            Returns:
            A boolean which indicates if the value of the message
            has been set.
        """
        if not f_language_dict.has_key(lang_country):
            raise TGFError("I18N : language '%s' not accepted" % lang_country)
            return False
        if not self.languages_struct[lang_country]['strings'].has_key(msg_name):
            return False
        else:
            self.languages_struct[lang_country]['strings'][msg_name] = msg_value
            return True

    def add_message(self, msg_name, default_value):
        """
        Add a new message.

            Parameters:
            "msg_name" as string      : Name of the message
            "default_value" as string : Value of the message

            Returns:
            A boolean which indicates if the message has been added.

            Comments:
            The value of message for all languages is set with
            the "default_value" value.
            We recommend to using a default message in english.
        """
        if self.languages_struct['en_US']['strings'].has_key(msg_name):
            return False
        lns = self.get_languages_list()
        for ln in lns:
            self.languages_struct[ln]['strings'][msg_name] = default_value
        return True

    def delete_message(self, msg_name):
        """
        Delete a message.

            Parameters:
            "msg_name" as string      : Name of the message

            Returns:
            A boolean which indicates if the message has been deleted.
        """
        if (msg_name == 'name_to_read') or (msg_name == 'speaker_name') or (msg_name == 'help_text'):
            return False
        lns = self.get_languages_list()
        for ln in lns:
            if self.languages_struct[ln]['strings'].has_key(msg_name):
                self.languages_struct[ln]['strings'].pop(msg_name)
        return True

class TGFParseSettings(object):
    """
    Class which manages the 'settings' file of the TGF file.

        Global variables of this class:
        "struct" as dict        : Dictionary of settings

        Functions list for the users:
            parser.settings.get_generals_list
            parser.settings.get_general_value
            parser.settings.set_general_value
            parser.settings.get_parameters_list
            parser.settings.add_parameter
            parser.settings.delete_parameter
            parser.settings.get_parameter_value
            parser.settings.set_parameter_value
    """

    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent
        self.struct = {}

    def read(self):
        """
        Read 'settings.xml' file
        """
        settings_path = self.parent.tgf_path + settings_xml_rel_path
        val, self.struct = xml_to_struct(self.struct, settings_path)
        return val

    def write(self):
        """
        Write 'settings.xml' file
        """
        settings_path = self.parent.tgf_path + settings_xml_rel_path
        return struct_to_xml(self.struct, settings_path)

    def create(self):
        """
        Create'settings.xml' file
        """
        settings_path = self.parent.tgf_path + settings_xml_rel_path
        struct_to_xml(settings_struct, settings_path)
        self.struct = deepcopy(settings_struct)

    def get_generals_list(self):
        """
        Get the list of the general settings.

            Returns:
            The list of general settings.
        """
        # Insert default priorities if not exists
        if 'main_priority' not in self.struct['settings']['general'].keys():
            self.set_general_value('main_priority', 4)
        if 'notify_priority' not in self.struct['settings']['general'].keys():
            self.set_general_value('notify_priority', 4)
        if 'framework_version' not in self.struct['settings']['general'].keys():
            self.set_general_value('framework_version', '0.0.0')
        if 'have_main_part' not in self.struct['settings']['general'].keys():
            self.set_general_value('have_main_part', True)
        if 'have_settings_part' not in self.struct['settings']['general'].keys():
            self.set_general_value('have_settings_part', True)
        if 'have_widget_part' not in self.struct['settings']['general'].keys():
            self.set_general_value('have_widget_part', True)
        return self.struct['settings']['general'].keys()

    def get_parameters_list(self):
        """
        Get the list of the parameters.

            Returns:
            The list of parameters.
        """
        return self.struct['settings']['parameters'].keys()

    def set_general_value(self, name, value):
        """
        Set the value of a general setting.

            Parameters:
            "name" as string    : Name of the general item
            "value" as untyped  : Value of the general item

            Returns:
            A boolean which indicates value has been set.
        """
        #if self.struct['settings']['general'].has_key(name):
        if True:
            self.struct['settings']['general'][name] = value
            return True
        else:
            return False

    def get_general_value(self, name):
        """
        Get the value of a general setting.

            Parameters:
            "name" as string    : Name of the general item

            Returns:
            The value of the general item.
        """
        if self.struct['settings']['general'].has_key(name):
            return self.struct['settings']['general'][name]
        else:
            return None

    def set_parameter_value(self, name, value):
        """
        Set the value of a parameter.

            Parameters:
            "name" as string    : Name of the parameter
            "value" as untyped  : Value of the parameter

            Returns:
            A boolean which indicates if value has been set.
        """
        if self.struct['settings']['parameters'].has_key(name):
            self.struct['settings']['parameters'][name] = value
            return True
        else:
            return False

    def get_parameter_value(self, name):
        """
        Get the value of a parameter.

            Parameters:
            "name" as string    : Name of the parameter

            Returns:
            The value of the parameter.
        """
        if self.struct['settings']['parameters'].has_key(name):
            return self.struct['settings']['parameters'][name]
        else:
            return None

    def add_parameter(self, name, value):
        """
        Add a new parameter.

            Parameters:
            "name" as string    : Name of the parameter
            "value" as untyped  : Value of the parameter

            Returns:
            A boolean which indicates if the parameter has
            been added.
        """
        if not self.struct['settings']['parameters'].has_key(name):
            self.struct['settings']['parameters'][name] = value
            return True
        else:
            return False

    def delete_parameter(self, name):
        """
        Delete a parameter.

            Parameters:
            "name" as string    : Name of the parameter

            Returns:
            A boolean which indicates if the parameter has
            been deleted.
        """
        if self.struct['settings']['parameters'].has_key(name):
            self.struct['settings']['parameters'].pop(name)
            return True
        else:
            return False

class TGFParseAbout(object):
    """
    Class which manages the 'about' file of the TGF file.

        Global variables of this class:
        "struct" as dict        : Dictionary of 'about' values

        Functions list for the users:
            parser.about.get_name
            parser.about.set_name
            parser.about.get_author
            parser.about.set_author
            parser.about.get_version
            parser.about.set_version
            parser.about.get_description
            parser.about.set_description
    """
    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent
        self.struct = {}

    def read(self):
        """
        Read 'about.xml' file
        """
        about_path = self.parent.tgf_path + about_xml_rel_path
        val, self.struct = xml_to_struct(self.struct, about_path)
        return val

    def write(self):
        """
        Write 'about.xml' file
        """
        about_path = self.parent.tgf_path + about_xml_rel_path
        return struct_to_xml(self.struct, about_path)

    def create(self):
        """
        Create 'about.xml' file
        """
        about_path = self.parent.tgf_path + about_xml_rel_path
        struct_to_xml(about_struct, about_path)
        self.struct = deepcopy(about_struct)

    def get_name(self):
        """
        Get the value of 'gadget_name'.

            Returns:
            A string.
        """
        return self.struct['about']['gadget_name']

    def get_author(self):
        """
        Get the value of 'gadget_author'

            Returns:
            A string.
        """
        return self.struct['about']['gadget_author']

    def get_version(self):
        """
        Get the value of 'gadget_version'

            Returns:
            A string.
        """
        return self.struct['about']['gadget_version']

    def get_description(self):
        """
        Get the value of 'gadget_description'

            Returns:
            A string.
        """
        return self.struct['about']['gadget_description']

    def set_name(self, name):
        """
        Set the value of 'gadget_name'

            Parameters:
            "name" as string    : Name of the gadget

            Returns:
            "True"
        """
        name = name.replace(' ', '_')
        self.struct['about']['gadget_name'] = name
        return True

    def set_author(self, author):
        """
        Set the value of 'gadget_author'

            Parameters:
            "author" as string    : Author of the gadget

            Returns:
            "True"
        """
        self.struct['about']['gadget_author'] = author
        return True

    def set_version(self, version):
        """
        Set the value of 'gadget_version'

            Parameters:
            "version" as string    : Version of the gadget

            Returns:
            "True"
        """
        self.struct['about']['gadget_version'] = version
        return True

    def set_description(self, description):
        """
        Set the value of 'gadget_description'

            Parameters:
            "description" as string    : Description of the gadget

            Returns:
            "True"
        """
        self.struct['about']['gadget_description'] = description
        return True

class TGFParseGUI(object):
    """
    Class which manages the GUI files of the TGF file.

        Global variables of this class:
        "struct" as dict        : Dictionary of GUI '.pyp' code

        Functions list for the users:
            parser.GUI.insert_pyp_file
            parser.GUI.insert_glade_file
    """
    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent
        self.struct = {}

    def read(self):
        """
        Read the GUIs of the TGF file
        """
        self.struct = {}
        guis_path = self.parent.tgf_path + gui_rel_path
        if os.path.exists(guis_path):
            gui_lst = os.listdir(guis_path)
            for gui_path in gui_lst:
                pyp_code = ''
                m_path = guis_path + '/' + gui_path + '/other.pyp'
                val, pyp_code = self.parent.get_file(m_path)
                if val:
                    self.struct[gui_path] = pyp_code

    def insert_pyp_file(self, pyp_path, gui_name):
        """
        Insert a pyp file.

            Parameters:
            "pyp_path" as string    : Path of the 'pyp' source file
            "gui_name" as string    : Name of the GUI

            Returns:
            A boolean which indicates if the file has been inserted
        """
        gui_path = self.parent.tgf_path + gui_rel_path + '/' + gui_name
        if not os.path.exists(gui_path):
            os.makedirs(gui_path, 511)
        m_path = gui_path + '/other.pyp'
        if os.path.exists(pyp_path):
            os.system("cp %s %s" % (pyp_path, m_path))
            self.read()
            return True
        else:
            return False

    def insert_glade_file(self, glade_path, gui_name):
        """
        Insert a glade file.

            Parameters:
            "glade_path" as string  : Path of the 'glade' source file
            "gui_name" as string    : Name of the GUI

            Returns:
            A boolean which indicates if the file has been inserted
        """
        gui_path = self.parent.tgf_path + gui_rel_path + '/' + gui_name
        if not os.path.exists(gui_path):
            os.makedirs(gui_path, 511)
        m_path = gui_path + '/other.glade'
        if os.path.exists(glade_path):
            os.system("cp %s %s" % (glade_path, m_path))
            return True
        else:
            return False

class TGFParseScripts(object):
    """
    Class which manages the script files of the TGF file.

        Global variables of this class:
        "struct" as dict        : Dictionary of '.pyp' script codes

        Functions list for the users:
            parser.scripts.insert
    """
    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent

    def read(self):
        """
        Read 'pyp' script files
        """
        self.struct = {}
        scripts_path = self.parent.tgf_path + python_rel_path
        if os.path.exists(scripts_path):
            scripts_lst = os.listdir(scripts_path)
            for script_path in scripts_lst:
                if script_path.lower().find('.pyp') != -1:
                    script_name = script_path.lower().replace('.pyp', '')
                    script_fpath = scripts_path + '/' + script_path
                    val, pyp_code = self.parent.get_file(script_fpath)
                    if val:
                        self.struct[script_name] = pyp_code

    def insert(self, pyp_path):
        """
        Insert a pyp script file.

            Parameters:
            "pyp_path" as string    : Path of the 'pyp' source file

            Returns:
            A boolean which indicates if the file has been inserted.
        """
        idxb = pyp_path.rfind('/')
        if idxb == -1:
            idxb = pyp_path.rfind("\\")
        script_name = pyp_path[idxb + 1:]
        script_path = self.parent.tgf_path + python_rel_path + '/' + script_name
        print script_path
        if os.path.exists(pyp_path):
            os.system("cp %s %s" % (pyp_path, script_path))
            self.read()
            return True
        else:
            return False

class TGFParseLibs(object):
    """
    Class which manages the added libraries in the TGF file.

        Global variables of this class:
        "struct" as dict        : Dictionary of '.py' libraries

        Functions list for the users:
            parser.libs.insert
            parser.libs.remove
    """
    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent

    def read(self):
        """
        Read
        """
        self.struct = {}
        libs_path = self.parent.tgf_path + python_rel_path
        if os.path.exists(libs_path):
            libs_lst = os.listdir(libs_path)
            for lib_path in libs_lst:
                if lib_path.lower().find('.py') != -1:
                    if lib_path.lower().find('.pyp') == -1:
                        lib_fpath = libs_path + '/' + lib_path
                        self.struct[lib_path] = lib_fpath

    def insert(self, path):
        """
        Insert a python library in the TGF file.

            Parameters:
            "path" as string    : Path a the python file

            Returns:
            A boolean which indicates if the library has been
            inserted.
        """
        py_name = path.replace(os.path.dirname(path), '')
        py_path = self.parent.tgf_path + python_rel_path + py_name
        if os.path.exists(path):
            os.system("cp %s %s" % (path, py_path))
            self.read()
            return True
        else:
            return False

    def remove(self, lib_name):
        """
        Remove an library from the TGF file

            Parameters:
            "lib_name" as string   : Name of the 'py' library

            Returns:
            A boolean which indicates if the icon has been
            removed.
        """
        if self.struct.has_key(lib_name):
            py_path = self.struct[lib_name]
            os.system("rm -f %s" % py_path)
            self.read()
            return True
        else:
            return False

class TGFParseIcons(object):
    """
    Class which manages the 'png' icons in the TGF file.

        Global variables of this class:
        "struct" as dict        : Dictionary of '.png' icons

        Functions list for the users:
            parser.icons.insert
            parser.icons.remove
    """
    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent

    def read(self):
        """
        Read
        """
        self.struct = {}
        icons_path = self.parent.tgf_path + icons_rel_path
        if os.path.exists(icons_path):
            icons_lst = os.listdir(icons_path)
            for icon_path in icons_lst:
                if icon_path.lower().find('.png') != -1:
                    icon_fpath = icons_path + '/' + icon_path
                    self.struct[icon_path] = icon_fpath

    def insert(self, path):
        """
        Insert a 'png' icon in the TGF file.

            Parameters:
            "path" as string    : Path of the 'png' icon

            Returns:
            A boolean which indicates if the icon has been
            inserted.
        """
        if not os.path.exists(self.parent.tgf_path + '/Pictures/Icons'):
            os.makedirs(self.parent.tgf_path + '/Pictures/Icons', 511)
        png_name = path.replace(os.path.dirname(path), '')
        png_path = self.parent.tgf_path + icons_rel_path + png_name
        if os.path.exists(path):
            os.system("cp %s %s" % (path, png_path))
            self.read()
            return True
        else:
            return False

    def remove(self, icon_name):
        """
        Remove an icon from the TGF file

            Parameters:
            "icon_name" as string   : Name of the icon

            Returns:
            A boolean which indicates if the icon has been
            removed.
        """
        if self.struct.has_key(icon_name):
            os.system("rm -f %s" % self.struct[icon_name])
            self.read()
            return True
        else:
            return False

class TGFParseSounds(object):
    """
    Class which manages the wav files in the TGF file.

        Global variables of this class:
        "struct" as dict        : Dictionary of wav files

        Functions list for the users:
            parser.sounds.insert
            parser.sounds.remove
    """
    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent

    def read(self):
        """
        Read
        """
        self.struct = {}
        sounds_path = self.parent.tgf_path + sounds_rel_path
        if os.path.exists(sounds_path):
            sounds_lst = os.listdir(sounds_path)
            for sound_path in sounds_lst:
                if sound_path.lower().find('.wav') != -1:
                    sound_fpath = sounds_path + '/' + sound_path
                    self.struct[sound_path] = sound_fpath

    def insert(self, path):
        """
        Insert a wav file in the TGF file.

            Parameters:
            "path" as string    : Path of the wav file

            Returns:
            A boolean which indicates if the wav file has been
            inserted.
        """
        if not os.path.exists(self.parent.tgf_path + '/Sounds'):
            os.makedirs(self.parent.tgf_path + '/Sounds', 511)
        wav_name = path.replace(os.path.dirname(path), '')
        wav_path = self.parent.tgf_path + sounds_rel_path + wav_name
        if os.path.exists(path):
            os.system("cp %s %s" % (path, wav_path))
            self.read()
            return True
        else:
            return False

    def remove(self, wav_name):
        """
        Remove a wav file from the TGF file

            Parameters:
            "wav_name" as string   : Name of the wav file

            Returns:
            A boolean which indicates if the wav file has been
            removed.
        """
        if self.struct.has_key(wav_name):
            os.system("rm -f %s" % self.struct[wav_name])
            self.read()
            return True
        else:
            return False
