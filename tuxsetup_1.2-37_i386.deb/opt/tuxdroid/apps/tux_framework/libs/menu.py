#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - Menu
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import sys
sys.path.append('/opt/tuxdroid/api/python')
from tuxapi_const import *
from tuxapi_class import *
from keyboard import *
import thread
import threading
import gtk
import os

# ------------------------------- Defines -------------------------------------
EXIT_MENU = 9999
SND_ENTERING = 13
SND_LEAVE = 16
SND_UPDOWN = 10
SND_SKIPMENU = 16
SND_INFO_MENU = 12
# ------------------------------- Class ---------------------------------------

def is_menu_class(pointer):
    if str(type(pointer)) == "<class 'menu.tuxdroid_menu'>":
        return True
    else:
        return False

def is_instancemethod(pointer):
    if (str(type(pointer)) == "<type 'instancemethod'>") or \
    (str(type(pointer)) == "<type 'function'>"):
        return True
    else:
        return False

class tuxdroid_menu(object):

    def __init__(   self,
                    menu_name,
                    tux_object,
                    keyb_object,
                    str_dict,
                    speaker = SPK_US_MALE,
                    voice_pitch = 100):
        self.is_running = False
        self.sub_menu_list = []
        self.menu_index = 0
        self.voice_pitch = voice_pitch
        self.menu_name = menu_name
        self.speaker = speaker
        skp_name = SPK_NAMES_LIST[self.speaker - 1]
        self.language = 'US'
        for spk_lang in SPK_LIST_BY_LANG:
            if skp_name in spk_lang:
                self.language = spk_lang[0]
        self.tux = tux_object
        self.keyboard_interface = keyb_object
        self.parent_menu = None
        self.main_parent = self.get_main_parent()
        self.inside_function = False
        self.on_enter_code_dict = {}
        self.on_leave_code_dict = {}
        self.on_index_changed = []
        self.on_sub_menu_instance_begin = []
        self.on_sub_menu_instance_end = []
        self.current_menu = self
        self.get_main_parent().current_menu = self
        self.muted = False
        self.on_exit = None
        self.lang_str = str_dict
        self.menu_mutex = threading.Lock()
        self.__thread_list = []
        
    def destroy(self):
        for t in self.__thread_list:
            if t.isAlive():
                t._Thread__stop()
                t.join()
                

    def get_main_parent(self):
        p_menu = self
        while p_menu.parent_menu != None:
            p_menu = p_menu.parent_menu
        return p_menu

    def propage_enter_leave_code_dict(self):
        for sub_menu in self.sub_menu_list:
            if is_menu_class(sub_menu[1]):
                sub_menu[1].on_enter_code_dict = self.on_enter_code_dict
                sub_menu[1].on_leave_code_dict = self.on_leave_code_dict
                sub_menu[1].propage_enter_leave_code_dict()

    def goto_menu_element_by_name(self, name):
        for i, sub_menu in enumerate(self.sub_menu_list):
            if is_instancemethod(sub_menu[1]):
                if sub_menu[0] == name:
                    for oic in self.on_index_changed:
                        if oic != None:
                            oic(i, self.menu_index)
                    self.menu_index = i
                    self._say_current_menu()
                    self._on_k_ok()

    def set_active_menu_element_by_name(self, name, value = True):
        for i, sub_menu in enumerate(self.sub_menu_list):
            if sub_menu[0] == name:
                sub_menu[4] = value

    def set_menu_order(self, menu_order):
        tmp_sub_menu_list = []
        for sub_menu in self.sub_menu_list:
            tmp_sub_menu_list.append(sub_menu)
        self.sub_menu_list = []
        for menu_name in menu_order:
            for tmp_sub_menu in tmp_sub_menu_list:
                if tmp_sub_menu[0] == menu_name:
                    self.sub_menu_list.append(tmp_sub_menu)
                    break

    def get_menu_order(self):
        menu_order = []
        for sub_menu in self.sub_menu_list:
            menu_order.append(sub_menu[0])
        return menu_order

    def make_menu_from_list(self, menu_list):
        menu_title = menu_list[0]
        for menu in menu_list[1]:
            if is_instancemethod(menu[1]):
                self.insert_sub_menu([menu[0], menu[1], menu[2]], self.speaker)
                continue
            else:
                new_menu = tuxdroid_menu(menu[0], self.tux,\
                self.speaker, self.voice_pitch)
                self.insert_sub_menu([menu[0], new_menu], self.speaker)
                new_menu.make_menu_from_list(menu)

    def enter(self):
        self.tux.event.store()
        on_remote_s = self.tux.event.on_remote
        self.tux.event.clear()
        self.tux.event.on_remote = on_remote_s
        for enter_code in self.on_enter_code_dict:
            code = self.on_enter_code_dict[enter_code]
            exec str(code)
        self.muted = False
        self.is_running = True
        self.menu_index = 0
        if len(self.sub_menu_list) > 0:
            if not self.sub_menu_list[self.menu_index][4]:
                self._on_k_down()
            else:
                for oic in self.on_index_changed:
                    if oic != None:
                        oic(self.menu_index, 0)
                self._say_current_menu()
        while self.is_running:
            self.tux.sys.wait(0.1)

    def leave(self):
        if not self.is_running: return
        if self.parent_menu != None:
            self.tux.tts.stop()
            if not self.muted:
                self.play_flash(SND_LEAVE)
                self.tux.tts.select_voice(self.parent_menu.speaker, self.voice_pitch)
                self.tux.tts.speak(self.parent_menu.menu_name)
        else:
            self.tux.tts.stop()
            if not self.muted:
                self.play_flash(SND_SKIPMENU)
                self.tux.tts.select_voice(self.speaker, self.voice_pitch)
                self.tux.tts.speak_free(self.lang_str['menu_exit_from'] + self.menu_name)
        for leave_code in self.on_leave_code_dict:
            code = self.on_leave_code_dict[leave_code]
            exec str(code)
        self.tux.event.restore()
        self.is_running = False

    def leave_muted(self):
        if not self.is_running: return
        if self.parent_menu == None:
            self.tux.tts.stop()
            if not self.muted:
                self.play_flash(SND_SKIPMENU)
                self.tux.tts.select_voice(self.speaker, self.voice_pitch)
                self.tux.tts.speak_free(self.lang_str['menu_exit_from'] + self.menu_name)
        for leave_code in self.on_leave_code_dict:
            code = self.on_leave_code_dict[leave_code]
            exec str(code)
        self.tux.event.restore()
        self.is_running = False

    def leave_recursively(self):
        self.tux.sys.wait(0.3)
        if not self.is_running: return
        self.leave_muted()
        if self.parent_menu != None:
            self.parent_menu.leave_muted()
        else:
            if self.on_exit != None:
                self.on_exit()

    def set_language(self, value = 'US'):
        self.language = value

    def set_pitch(self, value = 100):
        self.voice_pitch = value

    def insert_sub_menu(self, submenu, menu_speaker = SPK_US_MALE, active = True):
        if (not is_instancemethod(submenu[1])) and\
        (not is_menu_class(submenu[1])):
            return
        if menu_speaker == None:
            menu_speaker = self.speaker
        submenu.append(menu_speaker)
        submenu.append(active)
        if is_menu_class(submenu[1]):
            submenu[1].parent_menu = self
        self.sub_menu_list.append(submenu)

    def delete_sub_menu(self, submenu_name):
        for i, submenu in enumerate(self.sub_menu_list):
            if submenu[0] == submenu_name:
                self.sub_menu_list.pop(i)

    def clear_sub_menu(self):
        self.sub_menu_list = []

    def _load_function(self, funct, args):
        #self.tux.sys.wait(0.5)
        self.inside_function = True
        ret = funct(*args)
        if ret == EXIT_MENU:
            self.inside_function = False
            self.leave_recursively()
            return
        sub_menu = self.sub_menu_list[self.menu_index]
        self.inside_function = False
        if self.main_parent.is_running:
            self.tux.tts.stop()
            if not self.muted:
                self.play_flash(SND_LEAVE)
                self.tux.tts.select_voice(self.speaker, self.voice_pitch)
                #self.tux.tts.speak_free(self.lang_str['menu_back_to']+self.menu_name)
                self.tux.tts.speak(self.lang_str['menu_back_to']+self.menu_name)
        for smi in self.on_sub_menu_instance_end:
            if smi != None:
                smi(sub_menu[0])

    def _on_k_ok(self):
        if len(self.sub_menu_list) == 0: return
        sub_menu = self.sub_menu_list[self.menu_index]
        if sub_menu[1] != None:
            if is_instancemethod(sub_menu[1]):
                for smi in self.on_sub_menu_instance_begin:
                    if smi != None:
                        smi(sub_menu[0])
                self.tux.tts.stop()
                self.play_flash(SND_ENTERING)
                t = threading.Thread(target = self._load_function, args = (sub_menu[1], sub_menu[2]))
                t.start()
                self.__thread_list.append(t)
            elif is_menu_class(sub_menu[1]):
                self.tux.tts.stop()
                self.play_flash(SND_ENTERING)
                t = threading.Thread(target = sub_menu[1].enter)
                t.start()
                self.__thread_list.append(t)

    def __speak_menu(self, menu_name):
        self.tux.tts.stop()
        self.last_menu = menu_name
        self.tux.sys.wait(0.2)
        if self.last_menu == menu_name:
            if not self.inside_function:
                self.tux.tts.speak_free(menu_name)

    def _on_k_down(self):
        if len(self.sub_menu_list) == 0: return
        self.last_menu = ''
        old_menu_index = self.menu_index
        iter_sm = 0
        while True:
            iter_sm = iter_sm + 1
            if (self.menu_index + 1) > len(self.sub_menu_list) - 1:
                self.menu_index = 0
            else:
                self.menu_index = self.menu_index + 1
            sub_menu = self.sub_menu_list[self.menu_index]
            if sub_menu[4]:
                break
            if iter_sm >= len(self.sub_menu_list):
                return
        for oic in self.on_index_changed:
            if oic != None:
                oic(self.menu_index, old_menu_index)
        self.tux.tts.stop()
        if not self.muted:
            self.play_flash(SND_UPDOWN)
            if is_instancemethod(sub_menu[1]):
                voice = sub_menu[3]
            else:
                voice = sub_menu[2]
            self.tux.tts.select_voice(voice, self.voice_pitch)
            t = threading.Thread(target = self.__speak_menu, args = (sub_menu[0],))
            t.start()
            self.__thread_list.append(t)
        return True

    def _on_k_up(self):
        if len(self.sub_menu_list) == 0: return False
        self.last_menu = ''
        old_menu_index = self.menu_index
        iter_sm = 0
        while True:
            iter_sm = iter_sm + 1
            if self.menu_index == 0:
                self.menu_index = len(self.sub_menu_list) - 1
            else:
                self.menu_index = self.menu_index - 1
            sub_menu = self.sub_menu_list[self.menu_index]
            if sub_menu[4]:
                break
            if iter_sm >= len(self.sub_menu_list):
                return False
        for oic in self.on_index_changed:
            if oic != None:
                oic(self.menu_index, old_menu_index)
        self.tux.tts.stop()
        if not self.muted:
            self.play_flash(SND_UPDOWN)
            if is_instancemethod(sub_menu[1]):
                voice = sub_menu[3]
            else:
                voice = sub_menu[2]
            self.tux.tts.select_voice(voice, self.voice_pitch)
            t = threading.Thread(target = self.__speak_menu, args = (sub_menu[0],))
            t.start()
            self.__thread_list.append(t)
        return True

    def _say_current_menu(self):
        if len(self.sub_menu_list) == 0: return
        sub_menu = self.sub_menu_list[self.menu_index]
        if is_instancemethod(sub_menu[1]):
            voice = sub_menu[3]
        else:
            voice = sub_menu[2]
        self.tux.tts.stop()
        if not self.muted:
            self.play_flash(SND_INFO_MENU)
            self.tux.tts.stop()
            self.tux.tts.select_voice(voice, self.voice_pitch)
            if not self.inside_function:
                self.tux.tts.speak(sub_menu[0])

    def get_menu_tree(self):
        p_menu = self
        while p_menu.parent_menu != None:
            p_menu = p_menu.parent_menu
        result = ''

        def write_menu_branch(menu, ws):
            if menu == self.sub_menu_list[self.menu_index][1]:
                my_result = ws + '|--> ' + menu.menu_name + '\n'
            else:
                my_result = ws + '|' + menu.menu_name + '\n'
            current_menu = menu.menu_name
            space_w = ws
            for i in range(len(current_menu)-2):
                space_w = space_w + ' '
            for sub_menu in menu.sub_menu_list:
                if is_menu_class(sub_menu[1]):
                    my_result = my_result + write_menu_branch(sub_menu[1], space_w)
                else:
                    if sub_menu == self.sub_menu_list[self.menu_index]:
                        if self.inside_function:
                            my_result = my_result + space_w + '|--> ' + sub_menu[0] +\
                            ' ' + self.lang_str['menu_inside'] + '\n'
                        else:
                            my_result = my_result + space_w + '|--> ' + sub_menu[0] + '\n'
                    else:
                        my_result = my_result + space_w + '|' + sub_menu[0] + '\n'
            return my_result

        result = write_menu_branch(p_menu, '')

        return result

    def _show_infos(self):
        if len(self.sub_menu_list) == 0: return
        self._say_current_menu()

    def play_flash(self, sound_idx):
        self.tux.cmd.sound_play(sound_idx)
        self.tux.sys.wait(0.2)
