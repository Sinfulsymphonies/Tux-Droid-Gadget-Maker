import time

PANEL_SPINNING = 4
PANEL_BLANK = 5

SPINNING_LEFT_CANVAS = {'cmd' : 'spinl_on', 'duration': 0.0, 'count' : 2, 'speed': 5}
SPINNING_RIGHT_CANVAS = {'cmd' : 'spinr_on', 'duration': 0.0, 'count' : 2, 'speed': 5}

SPINNING_CMD_TYPES = {
    'Spinning':
        [
            'spinl_on',
            'spinr_on',
        ],
}

def update_spinning_combobox(parent):
    parent._cmd_type_model.clear()
    lst = []
    for cmd_type in SPINNING_CMD_TYPES.keys():
        lst.append(cmd_type)
    lst.sort()
    for n in lst:
        parent._cmd_type_model.append([n])
    parent._cmd_type_cbb.set_model(parent._cmd_type_model)
    time.sleep(0.1)
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_BLANK)
    
def update_spinning_panel(parent, block, cmd):
    if not cmd in SPINNING_CMD_TYPES['Spinning']:
        parent._notebook.set_current_page(PANEL_BLANK)
        return
    sb_turn = parent.get_widget("spinbutton4")
    sb_quarter = parent.get_widget("spinbutton5")
    rb_left = parent.get_widget("radiobutton28")
    rb_right = parent.get_widget("radiobutton29")
    hs_speed = parent.get_widget("hscale2")
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_SPINNING)
    p = block.get_function_params()
    if p['cmd'] == 'spinl_on':
        rb_left.set_active(True)
    elif p['cmd'] == 'spinr_on':
        rb_right.set_active(True)
    hs_speed.set_value(int(p['speed']))
    turn = int(int(p['count']) / 4)
    quarter = int(p['count']) - (turn * 4)
    sb_turn.set_value(turn)
    sb_quarter.set_value(quarter)
    
def update_spinning_block(parent, block):
    sb_turn = parent.get_widget("spinbutton4")
    sb_quarter = parent.get_widget("spinbutton5")
    rb_left = parent.get_widget("radiobutton28")
    rb_right = parent.get_widget("radiobutton29")
    hs_speed = parent.get_widget("hscale2")
    speed = hs_speed.get_value()
    turn = sb_turn.get_value()
    quarter = sb_quarter.get_value()
    if rb_left.get_active():
        cmd = 'spinl_on'
    else:
        cmd = 'spinr_on'
    p = block.get_function_params()
    p['cmd'] = cmd
    p['count'] = int((turn * 4) + quarter)
    p['speed'] = int(speed)
    parent._update_block_params(block, p)
    update_spinning_panel(parent, block, cmd)
