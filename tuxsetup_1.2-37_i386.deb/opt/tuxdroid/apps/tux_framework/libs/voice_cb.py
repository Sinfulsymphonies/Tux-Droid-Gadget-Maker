#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - Voice combobox
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import sys
sys.path.append('/opt/tuxdroid/api/python')
from tuxapi_const import *
from tuxapi_class import *
import thread
import gobject
import gtk

class VoiceComboBoxAdd(object):

    def __init__(self, tux, gtk_combobox_widget):
        self.tux = tux
        self.voice_list = gtk.ListStore(gobject.TYPE_STRING)
        self.voice_dic = {}
        self.current_voice_name = ""
        self.current_lang = ""
        self.current_cb_idx = 0
        self.current_speaker_id = 0
        self.combobox = gtk_combobox_widget

    def get_current_spk_conf(self):
        #if len(self.voice_list) == 0:
        #    return 0, 'US'
        if len(self.voice_list) > 0:
            self.current_voice_name = self.voice_list[self.combobox.get_active()][0]
            self.current_cb_idx = self.combobox.get_active()
            self.current_speaker_id = self.voice_dic[self.current_voice_name]
            skp_name = SPK_NAMES_LIST[self.current_speaker_id - 1]
            for spk_lang in SPK_LIST_BY_LANG:
                if skp_name in spk_lang:
                    self.current_lang = spk_lang[0]
            return self.current_speaker_id, self.current_lang
        else:
            return None, None

    def set_spk(self, speaker):
        self.current_speaker_id = speaker
        self.current_voice_name = LANG_OF_SPK_LIST[speaker - 1]
        if self.voice_dic.has_key(self.current_voice_name):
            for i, voice_name in enumerate(self.voice_list):
                if voice_name[0] == self.current_voice_name:
                    self.combobox.set_active(i)
                    self.current_cb_idx = i
                    break
        else:
            self.combobox.set_active(0)
            self.current_cb_idx = 0

    def update(self):
        self.voice_dic = {}
        self.voice_list.clear()
        for voice_id in self.tux.tts.authorized_voices_list:
            self.voice_list.append([LANG_OF_SPK_LIST[voice_id],])
            self.voice_dic[LANG_OF_SPK_LIST[voice_id]] = voice_id + 1
        self.combobox.set_model(self.voice_list)
        if self.voice_dic.has_key(self.current_voice_name):
            for i, voice_name in enumerate(self.voice_list):
                if voice_name[0] == self.current_voice_name:
                    self.combobox.set_active(i)
                    break
        else:
            self.combobox.set_active(0)
