#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Google translate
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import urllib
import httplib
import tdrss
import socket
import re

GT_ENGLISH = 'en'
GT_FRENCH = 'fr'
GT_GERMAN = 'de'
GT_ITALIAN = 'it'
GT_SPANISH = 'es'

GOOGLE_LANGPAIRS = [
    'de_en',
    'de_fr',
    'en_de',
    'en_ar',
    'en_es',
    'en_fr',
    'en_it',
    'en_pt',
    'es_en',
    'fr_de',
    'fr_en',
    'it_en',
    'pt_en',
]

def google_translate(from_lang, to_lang, text):

    #check if server is available
    if not tdrss.rss_server_available("translate.google.com", 4):
        return ""

    params = urllib.urlencode({"langpair":"%s|%s" %(from_lang, to_lang), "text":text, "ie":"UTF8", "oe":"UTF8"})
    socket.setdefaulttimeout(2)
    conn = httplib.HTTPConnection("translate.google.com")
    conn.request("POST", "/translate_t", params)
    socket.setdefaulttimeout(7)
    try:
        resp = conn.getresponse()
    except:
        return ""
    s = resp.read()
    conn.close()
    idx_b = s.find('id=result_box') + 22
    idx_e = s[idx_b:].find('</div>') + idx_b
    trad = s[idx_b:idx_e]

    if len(trad) > 0:
        return trad
    else:
        return ""
