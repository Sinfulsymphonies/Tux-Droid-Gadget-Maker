#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget Format - Canvas
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------

"""
Structure of 'scene.xml' file
"""
scene_struct = {
    'scene': {
        'header': {
            'name': 'Noname',
            'author': 'Kysoh',
            'version': '0.0.0',
            'description': 'Nodescription',
            'keywords': ['Nokeywords',],
            'length': 0.0,
            'category': 'common',
            'sub_category': 'common'
        },
        'wavs': {
            'count': 0
        },
        'body': {
            'script': {
                'language': 'python',
                'path': 'none'
            }
        }
    }
}

"""
Structure of 'settings.xml' file
"""
settings_struct = {
    'settings': {
            'general': {
                'language': 'en_US',
                'pitch': 100,
                'notified': False,
                'notify_delay': 30,
                'menu_active': True,
                'speaker' : 3,
                'gui_state' : {},
            },
            'parameters': {
            },
    }
}

"""
Structure of 'about.xml' file
"""
about_struct = {
    'about': {
        'gadget_name': 'New gadget',
        'gadget_author': 'Nobody',
        'gadget_version': '0.0.0',
        'gadget_description': 'Empty gadget for Tux Droid.',
    }
}

"""
Structure of 'strings.xml' file
"""
strings_struct = {
    'strings': {
        'name_to_read' : 'Empty gadget',
        'speaker_name' : 'Ryan8k',
    }
}
"""
Structure of a TGF archive
"""
tgf_dir_struct = [
    '/Strings',
    '/Scripts',
    '/Scripts/Python',
    '/Scripts/Python/GUI/',
    '/Scripts/Python/GUI/Configuration',
    '/Scripts/Python/GUI/Widget',
    '/Pictures',
    '/Pictures/Icons',
    '/Pictures/GUI',
    '/Sounds',
    '/Data',
]
