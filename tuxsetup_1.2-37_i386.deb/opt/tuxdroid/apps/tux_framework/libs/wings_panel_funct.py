import time

PANEL_WINGS = 3
PANEL_BLANK = 5

WINGS_ON_CANVAS = {'cmd' : 'wings_on', 'duration': 0.0, 'count' : 2}
WINGS_UP_CANVAS = {'cmd' : 'wings_up', 'duration': 0.0}
WINGS_DOWN_CANVAS = {'cmd' : 'wings_down', 'duration': 0.0}

WINGS_CMD_TYPES = {
    'Wings':
        [
            'wings_on',
            'wings_up',
            'wings_down',
        ],
}

def update_wings_combobox(parent):
    parent._cmd_type_model.clear()
    lst = []
    for cmd_type in WINGS_CMD_TYPES.keys():
        lst.append(cmd_type)
    lst.sort()
    for n in lst:
        parent._cmd_type_model.append([n])
    parent._cmd_type_cbb.set_model(parent._cmd_type_model)
    time.sleep(0.1)
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_BLANK)
    
def update_wings_panel(parent, block, cmd):
    if not cmd in WINGS_CMD_TYPES['Wings']:
        parent._notebook.set_current_page(PANEL_BLANK)
        return
    sb_count = parent.get_widget("spinbutton3")
    rb_move = parent.get_widget("radiobutton26")
    rb_up = parent.get_widget("radiobutton25")
    rb_down = parent.get_widget("radiobutton27")
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_WINGS)
    p = block.get_function_params()
    if cmd == 'wings_on':
        rb_move.set_active(True)
        sb_count.set_value(p['count'])
    elif cmd == 'wings_up':
        rb_up.set_active(True)
    elif cmd == 'wings_down':
        rb_down.set_active(True)
        
def update_wings_block(parent, block):
    sb_count = parent.get_widget("spinbutton3")
    rb_move = parent.get_widget("radiobutton26")
    rb_up = parent.get_widget("radiobutton25")
    rb_down = parent.get_widget("radiobutton27")
    if rb_move.get_active():
        cmd = 'wings_on'
        count = sb_count.get_value()
    elif rb_up.get_active():
        cmd = 'wings_up'
        count = 0
    elif rb_down.get_active():
        cmd = 'wings_down'
        count = 0
    p = block.get_function_params()
    p['cmd'] = cmd
    p['count'] = int(count)
    parent._update_block_params(block, p)
    update_wings_panel(parent, block, cmd)
