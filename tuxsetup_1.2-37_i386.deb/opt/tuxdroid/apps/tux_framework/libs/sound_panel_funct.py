import time

PANEL_SOUND = 6
PANEL_BLANK = 5

PLAY_FLASH_CANVAS = {'cmd' : 'sound_play', 'index' : 0, 'duration' : 0.0}
PLAY_WAVE_CANVAS = {'cmd' : 'wav_play', 'wav_name' : 'none', 'duration' : 0.0}

SOUND_CMD_TYPES = {
    'Sound':
        [
            'sound_play',
            'wav_play',
        ],
}

def update_sound_combobox(parent):
    parent._cmd_type_model.clear()
    lst = []
    for cmd_type in SOUND_CMD_TYPES .keys():
        lst.append(cmd_type)
    lst.sort()
    for n in lst:
        parent._cmd_type_model.append([n])
    parent._cmd_type_cbb.set_model(parent._cmd_type_model)
    time.sleep(0.1)
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_BLANK)
    
def update_sound_panel(parent, block, cmd):
    if not cmd in SOUND_CMD_TYPES['Sound']:
        parent._notebook.set_current_page(PANEL_BLANK)
        return
    sb_flash = parent.get_widget("spinbutton6")
    cbb_wave = parent._wav_cbb
    rb_flash = parent.get_widget("radiobutton30")
    rb_wave = parent.get_widget("radiobutton31")
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_SOUND)
    p = block.get_function_params()
    if p['cmd'] == 'sound_play':
        rb_flash.set_active(True)
        sb_flash.set_value(int(p['index']))
    elif p['cmd'] == 'wav_play':
        rb_wave.set_active(True)
        cbb_wave.set_active(-1)
        for i, item in enumerate(parent.wavs_ls):
            if item[0] == p['wav_name']:
                cbb_wave.set_active(i)
                break
        
def update_sound_block(parent, block):
    sb_flash = parent.get_widget("spinbutton6")
    cbb_wave = parent.get_widget("comboboxentry3")
    rb_flash = parent.get_widget("radiobutton30")
    rb_wave = parent.get_widget("radiobutton31")
    p = block.get_function_params()
    if rb_flash.get_active():
        cmd = 'sound_play'
        index = int(sb_flash.get_value())
        p['index'] = index
    else:
        cmd = 'wav_play'
        if int(cbb_wave.get_active()) >= 0:
            wav_name = parent.wavs_ls[int(cbb_wave.get_active())][0]
            p['wav_name'] = wav_name
            wav_path = parent._scene.get_wav(p['wav_name'])
            if wav_path != None:
                block.load_wavefile(wav_path)
        else:
            p['wav_name'] = 'none'
        
    p['cmd'] = cmd
    parent._update_block_params(block, p)
    update_sound_panel(parent, block, cmd)
