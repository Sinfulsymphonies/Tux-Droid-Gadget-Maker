#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget Format - Format
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import sys
import os
import string
from zipfile import *

from TGFCanvas import *
from TGFXml import *
from TGFParser import *

def check_filter(path):
    if path.lower().find('~') != -1: return False
    if path.lower().find('.pyc') != -1: return False
    if path.lower().find('.glade.bak') != -1: return False
    if path.lower().find('.gladep') != -1: return False
    if path.lower().find('.gladep.bak') != -1: return False
    if path.lower().find('.bak') != -1: return False
    if path.lower().find('.svn') != -1: return False
    return True

class TGFormat(object):

    def __init__(self):
        self.parser = None
        self.mode = 'r'
        self.path_compressed = True
        self.d_path = ''
        self.c_path = ''

    def open(self, path, mode = 'r', temp = False):
        path = path.replace('%20', ' ')
        if not os.path.isfile(path) and os.path.exists(path):
            self.path_compressed = False
        else:
            self.path_compressed = True
        self.mode = mode
        self.c_path = path
        self.c_path = os.path.abspath(self.c_path)
        if not self.path_compressed:
            self.d_path = self.c_path
            self.c_path = self.c_path + '.tgf'
            self.parser = TGFParser(self.d_path)
            self.parser.read()
        else:
            if temp:
                self.d_path = path.replace('.tgf', '')
                self.d_path = os.path.abspath(self.d_path)
                self.d_path = self.d_path + '@'
            else:
                self.d_path = path.replace('.tgf', '')
                self.d_path = os.path.abspath(self.d_path)
                tgf_basename = os.path.basename(self.d_path)
                self.d_path = "/tmp/%s" % tgf_basename
            # Delete older directory if exists
            if os.path.exists(self.d_path):
                os.system('rm -fR "%s"' % self.d_path)
            # Create base path to work
            os.makedirs(self.d_path, 511)

            if self.mode == 'w':
                self.parser = TGFParser(self.d_path)
                self.parser.create()
            if (self.mode == 'r') or (self.mode == 'a'):
                if not os.path.exists(self.c_path):
                    return False
                zf = ZipFile(self.c_path, 'r')
                for name in zf.namelist():
                    file_path = os.path.join(self.d_path, name)
                    if not os.path.exists(os.path.dirname(file_path)):
                        os.makedirs(os.path.dirname(file_path), 511)
                    f = open(file_path, 'wb')
                    f.write(zf.read(name))
                    f.close()
                zf.close()
                self.parser = TGFParser(self.d_path)
                self.parser.read()
            return True

    def save(self):
        if self.mode != 'r':
            # Check that the path exists
            if not os.path.exists(self.d_path): return
            # Save modifications
            self.parser.write()
            if self.path_compressed:
                # Goto the root directory 'self.d_path'
                last_cwd = os.getcwd()
                os.chdir(os.path.abspath(self.d_path))
                # Create a zip file
                zf = ZipFile(self.c_path, 'w')
                # Loop on tgf directories struct
                for root, dirs, files in os.walk(self.d_path):
                    for ffile in files:
                        full_path = root + '/' + ffile
                        rel_path = full_path.replace(self.d_path + '/', '')
                        if check_filter(rel_path):
                            zf.write(rel_path)
                zf.close()
                # Set the old cwd
                os.chdir(os.path.abspath(last_cwd))

    def close(self, preserve_path = False):
        self.save()
        # Delete directory
        if not preserve_path:
            if os.path.exists(self.d_path):
                if self.path_compressed:
                    os.system('rm -fR "%s"' % self.d_path)

def get_name_of_tgf_file(path):
    tgfile = TGFormat()
    tgfile.open(path, 'r')
    name = tgfile.parser.about.get_name()
    tgfile.close()
    return name
    
def get_fwversion_of_tgf_file(path):
    tgfile = TGFormat()
    tgfile.open(path, 'r')
    fwversion = tgfile.parser.settings.get_general_value('framework_version')
    tgfile.close()
    return fwversion
