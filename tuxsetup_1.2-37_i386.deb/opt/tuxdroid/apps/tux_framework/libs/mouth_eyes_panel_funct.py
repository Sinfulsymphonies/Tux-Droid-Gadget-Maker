import time

PANEL_MOUTH_EYES = 2
PANEL_BLANK = 5

MOUTH_ON_CANVAS = {'cmd' : 'mouth_on', 'duration': 0.0, 'count' : 2}
MOUTH_OPEN_CANVAS = {'cmd' : 'mouth_open', 'duration': 0.0}
MOUTH_CLOSE_CANVAS = {'cmd' : 'mouth_close', 'duration': 0.0}
EYES_ON_CANVAS = {'cmd' : 'eyes_on', 'duration': 0.0, 'count' : 2}
EYES_OPEN_CANVAS = {'cmd' : 'eyes_open', 'duration': 0.0}
EYES_CLOSE_CANVAS = {'cmd' : 'eyes_close', 'duration': 0.0}

MOUTH_EYES_CMD_TYPES = {
    'Mouth':
        [
            'mouth_on',
            'mouth_open',
            'mouth_close'
        ],
    'Eyes':
        [
            'eyes_on',
            'eyes_open',
            'eyes_close'
        ]
}

def update_mouth_eyes_combobox(parent):
    parent._cmd_type_model.clear()
    lst = []
    for cmd_type in MOUTH_EYES_CMD_TYPES.keys():
        lst.append(cmd_type)
    lst.sort()
    for n in lst:
        parent._cmd_type_model.append([n])
    parent._cmd_type_cbb.set_model(parent._cmd_type_model)
    time.sleep(0.1)
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_BLANK)
    
def update_mouth_panel(parent, block, cmd):
    if not cmd in MOUTH_EYES_CMD_TYPES['Eyes']:
        if not cmd in MOUTH_EYES_CMD_TYPES['Mouth']:
            parent._notebook.set_current_page(PANEL_BLANK)
            return
    sb_count = parent.get_widget("spinbutton2")
    rb_move = parent.get_widget("radiobutton22")
    rb_open = parent.get_widget("radiobutton23")
    rb_close = parent.get_widget("radiobutton24")
    parent._cmd_type_cbb.set_active(1)
    parent._notebook.set_current_page(PANEL_MOUTH_EYES)
    p = block.get_function_params()
    if cmd == 'mouth_on':
        rb_move.set_active(True)
        sb_count.set_value(p['count'])
    elif cmd == 'mouth_open':
        rb_open.set_active(True)
    elif cmd == 'mouth_close':
        rb_close.set_active(True)
        
def update_mouth_block(parent, block):
    sb_count = parent.get_widget("spinbutton2")
    rb_move = parent.get_widget("radiobutton22")
    rb_open = parent.get_widget("radiobutton23")
    rb_close = parent.get_widget("radiobutton24")
    if rb_move.get_active():
        cmd = 'mouth_on'
        count = sb_count.get_value()
    elif rb_open.get_active():
        cmd = 'mouth_open'
        count = 0
    elif rb_close.get_active():
        cmd = 'mouth_close'
        count =0
    p = block.get_function_params()
    p['cmd'] = cmd
    p['count'] = int(count)
    parent._update_block_params(block, p)
    update_mouth_panel(parent, block, cmd)
    
def update_eyes_panel(parent, block, cmd):
    if not cmd in MOUTH_EYES_CMD_TYPES['Eyes']:
        if not cmd in MOUTH_EYES_CMD_TYPES['Mouth']:
            parent._notebook.set_current_page(PANEL_BLANK)
            return
    sb_count = parent.get_widget("spinbutton2")
    rb_move = parent.get_widget("radiobutton22")
    rb_open = parent.get_widget("radiobutton23")
    rb_close = parent.get_widget("radiobutton24")
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_MOUTH_EYES)
    p = block.get_function_params()
    if cmd == 'eyes_on':
        rb_move.set_active(True)
        sb_count.set_value(p['count'])
    elif cmd == 'eyes_open':
        rb_open.set_active(True)
    elif cmd == 'eyes_close':
        rb_close.set_active(True)
        
def update_eyes_block(parent, block):
    sb_count = parent.get_widget("spinbutton2")
    rb_move = parent.get_widget("radiobutton22")
    rb_open = parent.get_widget("radiobutton23")
    rb_close = parent.get_widget("radiobutton24")
    if rb_move.get_active():
        cmd = 'eyes_on'
        count = sb_count.get_value()
    elif rb_open.get_active():
        cmd = 'eyes_open'
        count = 0
    elif rb_close.get_active():
        cmd = 'eyes_close'
        count =0
    p = block.get_function_params()
    p['cmd'] = cmd
    p['count'] = int(count)
    parent._update_block_params(block, p)
    update_eyes_panel(parent, block, cmd)
