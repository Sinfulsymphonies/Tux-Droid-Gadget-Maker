#!/usr/bin/python
import sys, gtk, gobject
import math, cairo, os
import time
import thread
import threading
from copy import *

from params_canvas import *
from led_panel_funct import *
from mouth_eyes_panel_funct import *
from wings_panel_funct import *
from spinning_panel_funct import *
from sound_panel_funct import *
from tts_panel_funct import *

BLOCK_TYPE_LEDS = 0
BLOCK_TYPE_EYESMOUTH = 1
BLOCK_TYPE_WINGS = 2
BLOCK_TYPE_SPIN = 3
BLOCK_TYPE_WAV = 4
BLOCK_TYPE_TTS = 5
BLOCK_COUNT_TYPE = 6

BLOCK_UNFOCUSED_COLOR = (0, 0, 1)
BLOCK_FOCUSED_COLOR = (1, 0, 0)
BLOCK_UNASSIGNED_COLOR = (0.2, 0.2, 0.2)
BLOCK_NODURATION_COLOR = (0.6, 0.6, 0.9)

ROWS_WHITE_COLOR = (1, 1, 1)
ROWS_GRAY_COLOR = (0.95, 0.95, 0.95)
ROWS_FOCUSED_COLOR = (0.75, 0.45, 0.45)

SCROLLBAR_BACKGROUND_FILL_COLOR = (1, 1, 1)
SCROLLBAR_BACKGROUND_LINE_COLOR = (0, 0, 0)
SCROLLBAR_FRONT_FILL_COLOR = (0, 0, 0)
SCROLLBAR_FRONT_LINE_COLOR = (0.5, 0.5, 0.5)
SCROLLBAR_HEIGHT = 16
SCROLLBAR_TOP_BORDER = 5

INDICES_PER_PIXEL = 0.0159
VIEW_TOP = 25
VIEW_BOTTOM_BORDER = 60
VIEW_LEFT = 100
VIEW_RIGHT_BORDER = 30

ZOOM_DEPTH_COEFF = 1.666666

class STMBlock(object):

    def __init__(self, block_type):
        self._block_type = block_type
        self.__time_begin = 0.0
        self.__length = 1.0
        self._function = {}
        self._alive = True
        self._visible = True
        self._cell_view = {
            'top' : 0,
            'left' : 0,
            'width' : 0,
            'height' : 0
        }
        self.__focused = False
        self.last_clicked_point = [0, 0]
        self._wcoeff = 0.0
        self._view_position = 0.0
        self._view_width = 0.0
        self.__is_on_collision = False
        
    def set_focused(self, value):
        self.__focused = value
        
    def get_focused(self):
        return self.__focused
        
    def set_collision(self, value):
        self.__is_on_collision = value
        
    def set_position(self, value):
        if (value >= 0.0) and (value <= 600.0 - self.__length):
            self.__time_begin = value
        
    def get_position(self):
        return self.__time_begin
        
    def set_length(self, value):
        if value < 0.3:
            value = 0.3
        self.__length = value
        self._function['duration'] = value
        
    def get_length(self):
        return self.__length
        
    def set_function_params(self, fp = {}):
        if fp.has_key('duration'):
            if fp['duration'] > 0.0:
                self.set_length(fp['duration'])
            else:
                self.set_length(0.3)
        else:
            fp['duration'] = 0.0
            self.set_length(0.3)
        self._function = fp
        
    def get_function_params(self):
        return self._function
        
    def is_assigned(self):
        if self._function == {}:
            return False
        else:
            return True
            
    def have_duration(self):
        if self._function.has_key('duration'):
            if self._function['duration'] > 0.0:
                return True
            else:
                return False
        else:
            return False
        
    def draw(self, context):
        if not self._alive:
            return
        if not self._visible:
            return
        context.rectangle(  self._cell_view['left'], 
                            self._cell_view['top'],
                            self._cell_view['width'],
                            self._cell_view['height'])
        if self.__is_on_collision:
            context.set_source_rgb(*BLOCK_UNASSIGNED_COLOR)
        elif self.__focused:
            context.set_source_rgb(*BLOCK_FOCUSED_COLOR)
        else:
            if not self.is_assigned():
                context.set_source_rgb(*BLOCK_UNASSIGNED_COLOR)
            else:
                if not self.have_duration():
                    context.set_source_rgb(*BLOCK_NODURATION_COLOR)
                else:
                    context.set_source_rgb(*BLOCK_UNFOCUSED_COLOR)
        context.fill_preserve()
        context.set_source_rgb(0, 0, 0)
        context.set_line_width(1)
        context.stroke()
     
    def update_coord(self, view, time_position, time_length, cursor_position):
        border = int(view['height'] / 8)
        self._cell_view['top'] = view['top'] + border
        self._cell_view['height'] = view['height'] - (border * 2)
        w_coeff = float(time_length) / view['width']
        self._wcoeff = float(time_length) / view['width']
        self._view_position = time_position
        self._view_width = view['width']
        t_b = time_position
        t_e = time_position + time_length
        if self.__time_begin > t_e:
            self._visible = False
            return
        if (self.__time_begin + self.__length) < t_b:
            self._visible = False
            return
        if self.__time_begin < t_b:
            mt_b = t_b
        else:
            mt_b = self.__time_begin
        if (self.__time_begin + self.__length) > t_e:
            mt_e = t_e
        else:
            mt_e = (self.__time_begin + self.__length)
        self._cell_view['left'] = int(mt_b / w_coeff) - (time_position / w_coeff) + view['left']
        self._cell_view['width'] = int((mt_e - mt_b) / w_coeff)
        self._visible = True
        
    def point_in_block(self, x, y, cursor_position):
        ret = False
        if (x > self._cell_view['left']) and (x < self._cell_view['left'] + self._cell_view['width']):
            if (y > self._cell_view['top']) and (y < self._cell_view['top'] + self._cell_view['height']):
                ret = True
                xb = int(self.__time_begin / self._wcoeff)
                mx = int(cursor_position / self._wcoeff)
                self.last_clicked_point[0] = mx - xb
                self.last_clicked_point[1] = y - self._cell_view['top']
        return ret
        
class STMBlockWav(STMBlock):

    def __init__(self, block_type):
        STMBlock.__init__(self, block_type)
        self.__wavefile = ""
        self.__energy_table = []
        
    def get_wav_path(self):
        return self.__wavefile
        
    def load_wavefile(self, path):
    
        def log_val(val):
            if val < 1:
                val = 1
            return int((float(math.log(val) / math.log(128))) * 128)
            
        if not os.path.isfile(path):
            return False
        f = open(path, 'r')
        f.seek(44, 0)
        st = f.read()
        f.close
        self.__wavefile = path
        self.__energy_table = []
        waveform = []
        for val in st:
            waveform.append(ord(val) - 127)
        e_c = len(waveform) / 200
        for i in range(e_c):
            buff = waveform[i*200:(i+1)*200]
            e = 0
            for val in buff:
                e += abs(val)
            e /= 200
            e = log_val(e)
            self.__energy_table.append(e)
        self.set_length(float(len(self.__energy_table)) / 40)
        self._function['duration'] = float(len(self.__energy_table)) / 40
        
    def draw(self, context):
        STMBlock.draw(self, context)
        context.move_to(self._cell_view['left'], self._cell_view['top'])
        v_coeff = float(self._cell_view['height']) / 128.0
        for i, val in enumerate(self.__energy_table):
            idx_time = (i * 0.025)
            x = int(idx_time / self._wcoeff)
            b_x = int(self.get_position() / self._wcoeff)
            x_abs = x + b_x
            v_x = int(self._view_position / self._wcoeff)
            v_w = self._view_width
            if (x_abs >= v_x) and (x_abs <= (v_x + v_w)):
                context.set_line_width(1)
                context.set_source_rgb(0, 0, 0)
                y = self._cell_view['top'] +  (self._cell_view['height'] - (val * v_coeff))
                x_abs += VIEW_LEFT
                x_abs -= v_x
                context.line_to(x_abs, y)
        context.stroke()
        
class STMZoomButton(object):

    def __init__(self, label):
        self.__label = label
        self.__area = {
            'top' : 0,
            'left' : 0,
            'width' : 20,
            'height' : 20,
        }
        self.__x_align_label = 5
        self.__y_align_label = 14
        self.__size_label = 12
        self.__is_focused = False
        self.on_clicked = None
        
    def set_position(self, left, top):
        self.__area['left'] = left
        self.__area['top'] = top
        
    def set_focused(self, value):
        self.__is_focused = value
        
    def set_label_align(self, x_align, y_align, size):
        self.__x_align_label = x_align
        self.__y_align_label = y_align
        self.__size_label = size
        
    def draw(self, context):
        if self.__is_focused:
            line_color = (0, 0, 0.9)
        else:
            line_color = (0, 0, 0)
        context.rectangle(  self.__area['left'], 
                            self.__area['top'],
                            self.__area['width'],
                            self.__area['height'])
        context.set_source_rgb(1, 1, 1)
        context.fill_preserve()
        context.set_source_rgb(*line_color)
        context.set_line_width(1.5)
        context.stroke()
        x = self.__area['left'] + 10
        y = self.__area['top'] + 10
        context.move_to(x, y)
        x = self.__area['left'] + self.__area['width']
        y = self.__area['top'] + self.__area['height']
        context.set_line_width(3)
        context.line_to(x, y)
        context.stroke()
        context.set_line_width(1)
        context.arc(self.__area['left'] + 10, self.__area['top'] + 10, 6, 0, 2.0 * math.pi)
        context.set_source_rgb(1, 1, 1)
        context.fill_preserve()
        context.set_source_rgb(*line_color)
        context.arc(self.__area['left'] + 10, self.__area['top'] + 10, 7.7, 0, 2.0 * math.pi)
        context.stroke()
        x = self.__area['left'] + self.__x_align_label
        y = self.__area['top'] + self.__y_align_label
        context.move_to(x, y)
        context.set_font_size(self.__size_label)
        context.show_text(self.__label)
        context.stroke()
        
    def point_in_button(self, x, y):
        ret = False
        if (x > self.__area['left']) and (x < self.__area['left'] + self.__area['width']):
            if (y > self.__area['top']) and (y < self.__area['top'] + self.__area['height']):
                ret = True
                if self.on_clicked != None:
                    self.on_clicked()
        return ret
        
class STMBlockContainer(object):

    def __init__(self, block_type, min_ecart, background_color = (1, 1, 1)):
        self._blocks = []
        self.block_type = block_type
        self.__row_view = {
            'top' : 0,
            'left' : 0,
            'width' : 0,
            'height' : 0
        }
        self.__background_color = background_color
        self.__focused = False
        self.__label = "Undefined"
        self.__min_ecart = min_ecart
        
    def get_block_list(self):
        lst = []
        for block in self._blocks:
            if block._alive == True:
                lst.append([block.get_position(), block.get_function_params(), block])
        return lst
        
    def set_label(self, text):
        self.__label = text
        
    def get_label(self):
        return self.__label
        
    def set_focused(self, value):
        self.__focused = value
        
    def get_focused(self):
        return self.__focused
        
    def draw(self, context):
        context.rectangle(  self.__row_view['left'], 
                            self.__row_view['top'],
                            self.__row_view['width'],
                            self.__row_view['height'])
        if self.__focused:
            context.set_source_rgb(*ROWS_FOCUSED_COLOR)
        else:
            context.set_source_rgb(*self.__background_color)
        context.fill_preserve()
        context.set_source_rgb(0, 0, 0)
        context.set_line_width(1)
        context.stroke()
        x = self.__row_view['left'] - VIEW_LEFT + 5
        y = self.__row_view['top'] + (self.__row_view['height'] / 2) + 4
        context.set_source_rgb(0, 0, 0)
        context.set_font_size(11)
        context.move_to(x, y)
        context.show_text(self.__label)
        context.stroke()
        
    def draw_all(self, context):
        self.draw(context)
        for block in self._blocks:
            if block._alive:
                block.draw(context)
                
    def check_ecart(self, other_container = None):
        m_tbl = []
        if self.__min_ecart != None:
            for block in self._blocks:
                if block._alive:
                    m_tbl.append({
                        'block' : block, 
                        'begin' : block.get_position(), 
                        'end' : block.get_position() + block.get_length()
                    })
            if other_container != None:
                for block in other_container._blocks:
                    if block._alive:
                        m_tbl.append({
                            'block' : block, 
                            'begin' : block.get_position(), 
                            'end' : block.get_position() + block.get_length()
                        })
            for b in m_tbl:
                b['block'].set_collision(False)
            for b1 in m_tbl:
                for b2 in m_tbl:
                    if b2['block'] == b1['block']:
                        continue
                    test = (b2['begin'] - b1['end'])
                    if test > 0.0:
                        if test < self.__min_ecart:
                            b2['block'].set_collision(True)
                            b1['block'].set_collision(True)
                    if (b2['begin'] <= b1['end']) and (b2['begin'] >= b1['begin']):
                        b2['block'].set_collision(True)
                        b1['block'].set_collision(True)
                    if (b2['end'] <= b1['end']) and (b2['end'] >= b1['begin']):
                        b2['block'].set_collision(True)
                        b1['block'].set_collision(True)
                
    def update_coord(self, view, cursor_position):
        block_height = float(view['height']) / BLOCK_COUNT_TYPE
        self.__row_view['top'] = int(block_height * self.block_type) + view['top']
        tmp_val = int(block_height * (self.block_type + 1)) + view['top']
        self.__row_view['height'] = tmp_val - self.__row_view['top']
        self.__row_view['width'] = view['width']
        self.__row_view['left'] = view['left']                  
        for block in self._blocks:
            if block._alive:
                block.update_coord(self.__row_view, view['time_position'], view['time_length'], cursor_position)
            
    def new_block(self):
        block = STMBlock(self.block_type)
        block = STMBlockWav(self.block_type)
        block_id = len(self._blocks)
        self._blocks.append(block)
        return block
        
    def delete_block(self, block_id):
        if block_id <= len(self._blocks):
            self._blocks[block_id]._alive = False
            return True
        return False
        
    def clear_blocks(self):
        self._blocks = []
        
    def point_in_row(self, x, y):
        ret = False
        if (x >= self.__row_view['left']) and (x <= self.__row_view['left'] + self.__row_view['width']):
            if (y >= self.__row_view['top']) and (y <= self.__row_view['top'] + self.__row_view['height']):
                ret = True
        return ret
        
class SceneScrollbar(object):

    def __init__(self):
        self._back_area = {
            'top' : 0,
            'left' : 0,
            'width' : 0,
            'height' : 0
        }
        self._bar_area = {
            'top' : 0,
            'left' : 0,
            'width' : 0,
            'height' : 0
        }
        self.last_clicked_point = [0, 0]
        
    def update_coord(self, view, full_length, current_position):
        self._back_area['top'] = view['top'] + view['height'] + SCROLLBAR_TOP_BORDER
        self._back_area['height'] = SCROLLBAR_HEIGHT - 2
        self._back_area['left'] = view['left']
        self._back_area['width'] = view['width']
        self._bar_area['width'] = int(float(self._back_area['width']) * (view['time_length'] / full_length))
        if self._bar_area['width'] < 7:
            self._bar_area['width'] = 7
        self._bar_area['width'] -= 1
        self._bar_area['height'] = self._back_area['height'] - 4
        self._bar_area['top'] = self._back_area['top'] + 2
        lcoeff = (view['time_position'] / full_length)
        ll = self._back_area['width'] * lcoeff
        self._bar_area['left'] = self._back_area['left'] + 1 + ll
        if (self._bar_area['left'] + self._bar_area['width']) > (self._back_area['left'] + self._back_area['width']):
            self._bar_area['left'] = (self._back_area['left'] + self._back_area['width']) - self._bar_area['width']
        
    def draw(self, context):
        context.rectangle(  self._back_area['left'], 
                            self._back_area['top'],
                            self._back_area['width'],
                            self._back_area['height'])
        context.set_source_rgb(*SCROLLBAR_BACKGROUND_FILL_COLOR)
        context.fill_preserve()
        context.set_source_rgb(*SCROLLBAR_BACKGROUND_LINE_COLOR)
        context.set_line_width(2)
        context.stroke()
        context.rectangle(  self._bar_area['left'], 
                            self._bar_area['top'],
                            self._bar_area['width'],
                            self._bar_area['height'])
        context.set_source_rgb(*SCROLLBAR_FRONT_FILL_COLOR )
        context.fill_preserve()
        context.set_source_rgb(*SCROLLBAR_FRONT_LINE_COLOR )
        context.set_line_width(1)
        context.stroke()
        
    def point_in_bar(self, x, y):
        ret = False
        if (x > self._bar_area['left']) and (x < self._bar_area['left'] + self._bar_area['width']):
            if (y > self._bar_area['top']) and (y < self._bar_area['top'] + self._bar_area['height']):
                ret = True
                self.last_clicked_point[0] = x - self._bar_area['left']
                self.last_clicked_point[1] = y - self._bar_area['top']
        return ret
        
class SceneTimeLineViewer(gtk.DrawingArea):

    def __init__(self, width = 640, height = 350):
        gtk.DrawingArea.__init__(self)
        self.set_events(
                             gtk.gdk.POINTER_MOTION_MASK |
                             gtk.gdk.BUTTON_PRESS_MASK |
                             gtk.gdk.BUTTON_RELEASE_MASK |
                             gtk.gdk.KEY_PRESS_MASK |
                             gtk.gdk.KEY_RELEASE_MASK )
        self.set_flags(gtk.HAS_FOCUS|gtk.CAN_FOCUS)
        self.connect("expose_event", self.expose)
        self.connect("button_press_event", self.mousedown)
        self.connect("button_release_event", self.mouseup)
        self.connect("motion_notify_event", self.mousemove)
        self.connect("key_press_event", self.keypress)
        self.__context = None
        self.set_property("width-request", width)
        self.set_property("height-request", height)
        self.__width = width
        self.__height = height
        self.__cells_view = {
            'left' : VIEW_LEFT,
            'top' : VIEW_TOP,
            'width' : 0,
            'height' : 0,
            'time_length' : 0.0,
            'time_position' : 0.0
        }
        self.__events_list = {
            'time_position_changed' : None,
            'block_selected' : None,
            'block_move' : None,
            'block_drag_acquire' : None,
            'block_drag_release' : None,
            'full_time_changed' : None,
            'zoom_changed' : None,
            'row_selected' : None,
        }
        self.__info = {
            'full_time_length' : 10.0,
        }
        self.__strings = {
            'leds_label' : 'Leds',
            'mouth_eyes_label' : 'Mouth & eyes',
            'wings_label' : 'Wings',
            'spinning_label' : 'Spinning',
            'wavs_label' : 'Sound',
            'tts_label' : 'TTS',
            'legend_block_not_configured' : 'Block have bad position',
            'legend_block_without_duration' : 'Block without duration',
            'legend_block_with_duration' : 'Block with duration',
            'legend_block_is_focused' : 'Block is focused',
        }
        self.block_containers = []
        self.__focused_row = -1
        self.__focused_block = None
        self.__focused_scrollbar = False
        self.__create_block_containers()
        self.__current_position = 0.0
        self.__zoom_factor = 1
        self.__scrollbar = SceneScrollbar()
        self.__major_indice = 1
        self.__indices_tables = []
        self.__dragging_block = False
        self.__zoom_plus_button = STMZoomButton('+')
        self.__zoom_plus_button.set_label_align(3, 14, 16)
        self.__zoom_minus_button = STMZoomButton('-')
        self.__zoom_minus_button.set_label_align(6, 16, 20)
        self.__zoom_full_button = STMZoomButton('1:1')
        self.__zoom_full_button.set_label_align(4, 12, 6)
        
    def connect_event(self, event_name, function):
        if event_name in self.__events_list.keys():
            self.__events_list[event_name] = function
            
    def destroy(self):
        for event in self.__events_list.keys():
            self.__events_list[event] = None
            
    def set_strings(self, strings):
        self.__strings = strings
        self.__set_block_containers_label()
        
    def __set_block_containers_label(self):
        self.block_containers[0].set_label(self.__strings['leds_label'])
        self.block_containers[1].set_label(self.__strings['mouth_eyes_label'])
        self.block_containers[2].set_label(self.__strings['wings_label'])
        self.block_containers[3].set_label(self.__strings['spinning_label'])
        self.block_containers[4].set_label(self.__strings['wavs_label'])
        self.block_containers[5].set_label(self.__strings['tts_label'])
        
    def __create_block_containers(self):
        bc = STMBlockContainer(BLOCK_TYPE_LEDS, None, ROWS_GRAY_COLOR)
        self.block_containers.append(bc)
        bc = STMBlockContainer(BLOCK_TYPE_EYESMOUTH, None, ROWS_WHITE_COLOR)
        self.block_containers.append(bc)
        bc = STMBlockContainer(BLOCK_TYPE_WINGS, None, ROWS_GRAY_COLOR)
        self.block_containers.append(bc)
        bc = STMBlockContainer(BLOCK_TYPE_SPIN, None, ROWS_WHITE_COLOR)
        self.block_containers.append(bc)
        bc = STMBlockContainer(BLOCK_TYPE_WAV, 1.0, ROWS_GRAY_COLOR)
        self.block_containers.append(bc)
        bc = STMBlockContainer(BLOCK_TYPE_TTS, 1.0, ROWS_WHITE_COLOR)
        self.block_containers.append(bc)
        self.__set_block_containers_label()
        
    def __check_blocks_ecart(self):
        self.block_containers[0].check_ecart()
        self.block_containers[1].check_ecart()
        self.block_containers[2].check_ecart()
        self.block_containers[3].check_ecart()
        self.block_containers[4].check_ecart(self.block_containers[5])
        
    def expose(self, widget, event):
        self.__context = widget.window.cairo_create()
        self.__context.rectangle(event.area.x, event.area.y,
                               event.area.width, event.area.height)
        self.__context.clip()
        self.__update_coord()
        self.draw(self.__context)
        return False
        
    def __get_time_position_of_coord(self, x, y):
        if (y > self.__cells_view['top']) and (y < self.__cells_view['top'] + self.__cells_view['height']):
            coeff = self.__cells_view['time_length'] / self.__cells_view['width']
            val = float((x - self.__cells_view['left']) * coeff) + self.__cells_view['time_position']
            if (val >= 0.0) and (val <= self.__info['full_time_length']):
                return val
            else:
                return None
        else:
            return None
        
    def __coord_to_time_position(self, x, y):
        val = self.__get_time_position_of_coord(x, y)
        if val != None:
            self.__current_position = val
            if self.__events_list['time_position_changed'] != None:
                self.__events_list['time_position_changed'](self.__current_position)
        
    def mousedown(self, widget, event):
        self.grab_focus()
        n_pos = self.__get_time_position_of_coord(event.x, event.y)
        if event.button == 1:
            self.__coord_to_time_position(event.x, event.y)
            self.__update_coord()
            self.__focused_scrollbar = self.__scrollbar.point_in_bar(event.x, event.y)
            if self.__zoom_plus_button.point_in_button(event.x, event.y):
                self.__zoom_plus_button.set_focused(True)
                self.__zoom_minus_button.set_focused(False)
                self.__zoom_full_button.set_focused(False)
                self.set_zoom_factor(self.__zoom_factor + 1)
            if self.__zoom_minus_button.point_in_button(event.x, event.y):
                self.__zoom_plus_button.set_focused(False)
                self.__zoom_minus_button.set_focused(True)
                self.__zoom_full_button.set_focused(False)
                self.set_zoom_factor(self.__zoom_factor - 1)
            if self.__zoom_full_button.point_in_button(event.x, event.y):
                self.__zoom_plus_button.set_focused(False)
                self.__zoom_minus_button.set_focused(False)
                self.__zoom_full_button.set_focused(True)
                self.set_zoom_factor(1)
        idx = -1
        for i, block_container in enumerate(self.block_containers):
            if block_container.point_in_row(event.x, event.y):
                idx = i
                break
        if idx >= 0:
            self.set_focused_row(idx)
            if self.__events_list['row_selected'] != None:
                self.__events_list['row_selected'](idx)
            for block in self.block_containers[idx]._blocks:
                if block.point_in_block(event.x, event.y, n_pos):
                    self.set_focused_block(block)
                    if self.__events_list['block_selected'] != None:
                        self.__events_list['block_selected'](self.__focused_block)
                    if event.button == 3:
                        self.__dragging_block = True
                        if self.__events_list['block_drag_acquire'] != None:
                            self.__events_list['block_drag_acquire'](self.__focused_block)
            self.refresh()
            
    def mouseup(self, widget, event):
        self.__zoom_plus_button.set_focused(False)
        self.__zoom_minus_button.set_focused(False)
        self.__zoom_full_button.set_focused(False)
        self.__focused_scrollbar = False
        if self.__dragging_block:
            self.__dragging_block = False
            if self.__events_list['block_drag_release'] != None:
                self.__events_list['block_drag_release'](self.__focused_block)
        self.refresh()
        
    def mousemove(self, widget, event):
        if self.__focused_scrollbar:
            if True:
                x = event.x - self.__scrollbar.last_clicked_point[0]
                s_idx = (x - self.__scrollbar._back_area['left'])
                t_pcent = s_idx / (self.__scrollbar._back_area['width'])
                time_index = t_pcent * self.__info['full_time_length']
                if time_index < 0:
                    time_index = 0
                if time_index > (self.__info['full_time_length'] - self.__cells_view['time_length']):
                    time_index = (self.__info['full_time_length'] - self.__cells_view['time_length'])
                self.__cells_view['time_position'] = time_index
                self.refresh()
        if self.__dragging_block:
            x = event.x - self.__focused_block.last_clicked_point[0]
            time_b = self.__get_time_position_of_coord(x, event.y)
            if time_b != None:
                self.__focused_block.set_position(time_b)
                self._recalc_full_time()
                if self.__events_list['block_move'] != None:
                    self.__events_list['block_move'](self.__focused_block)
                self.refresh()
                
    def keypress(self, widget, event):
        print 'Key pressed'
        key = gtk.gdk.keyval_name(event.keyval)
        if key == 'Up':
            self.set_zoom_factor(self.__zoom_factor + 1)
        elif key == 'Down':
            self.set_zoom_factor(self.__zoom_factor - 1)
        return True
                   
    def refresh(self):
        if self.window:
            width, height = self.window.get_size()
            self.window.invalidate_rect(gtk.gdk.Rectangle(0,0,width,height),False)
        
    def __update_coord(self):
        rect = self.get_allocation()
        if rect.width < 10:
            width = self.__width
        else:
            width = rect.width
        if rect.height < 10:
            height = self.__height
        else:
            height = rect.height
        self.__cells_view['width'] = width - self.__cells_view['left'] - VIEW_RIGHT_BORDER
        self.__cells_view['height'] = height - self.__cells_view['top'] - VIEW_BOTTOM_BORDER
        self.__scrollbar.update_coord(self.__cells_view, self.__info['full_time_length'], self.__current_position)
        for block_container in self.block_containers:
            block_container.update_coord(self.__cells_view, self.__current_position)
        y = self.__cells_view['top'] + self.__cells_view['height'] + 8 + SCROLLBAR_HEIGHT + SCROLLBAR_TOP_BORDER
        x = width - VIEW_RIGHT_BORDER - 80
        self.__zoom_plus_button.set_position(x, y)
        x = width - VIEW_RIGHT_BORDER - 50
        self.__zoom_minus_button.set_position(x, y)
        x = width - VIEW_RIGHT_BORDER - 20
        self.__zoom_full_button.set_position(x, y)
            
    def __update_timeline_indic(self):
        self.__indices_tables = []
        if self.__cells_view['width'] == 0:
            return
        ft_view_size = (self.__info['full_time_length'] / self.__cells_view['time_length']) * self.__cells_view['width']
        indices_per_view = INDICES_PER_PIXEL * self.__cells_view['width']
        indices_per_second = indices_per_view / self.__cells_view['time_length']
        if indices_per_second >= 1.0:
            self.__major_indice = 1
            indices_per_second = int(indices_per_second)
            indices_ecart = 1.0 / indices_per_second
            t_length = int(self.__info['full_time_length']) + 1
            for i in range(t_length):
                for j in range(indices_per_second):
                    val = float(i) + (float(j) * indices_ecart)
                    self.__indices_tables.append(val)
        elif indices_per_second >= 0.1:
            self.__major_indice = 10
            indices_per_10second = int(indices_per_second * 10)
            indices_ecart = 10.0 / indices_per_10second
            t_length = int(self.__info['full_time_length'] / 10) + 1
            for i in range(t_length):
                for j in range(indices_per_10second):
                    val = float(i * 10) + (float(j) * indices_ecart)
                    self.__indices_tables.append(val)
        elif indices_per_second >= 0.01666666:
            self.__major_indice = 60
            indices_per_60second = int(indices_per_second * 60)
            indices_ecart = 60.0 / indices_per_60second
            t_length = int(self.__info['full_time_length'] / 60) + 1
            for i in range(t_length):
                for j in range(indices_per_60second):
                    val = float(i * 60) + (float(j) * indices_ecart)
                    self.__indices_tables.append(val)          
        elif indices_per_second >= 0.001666666:
            self.__major_indice = 600
            indices_per_600second = int(indices_per_second * 600)
            indices_ecart = 600.0 / indices_per_600second
            t_length = int(self.__info['full_time_length'] / 600) + 1
            for i in range(t_length):
                for j in range(indices_per_600second):
                    val = float(i * 600) + (float(j) * indices_ecart)
                    self.__indices_tables.append(val)
        
    def __time_to_x(self, time):
        width = self.__cells_view['width']
        tb = time - self.__cells_view['time_position']
        length = self.__cells_view['time_length']
        x = int((tb / length) * width) + self.__cells_view['left']
        return x
            
    def draw_timeline_indic(self, context):
    
        def draw_indice(x, context, ismajor, time_str):
            if ismajor:
                yb = VIEW_TOP / 2
                ye = VIEW_TOP
                context.set_source_rgb(0.0, 0.0, 0.0)
                context.move_to(x - 25, 10)
                context.set_font_size(10)
                context.show_text("[%s]" % time_str)
                context.stroke()
                context.set_line_width(1.5)
            else:
                yb = VIEW_TOP / 1.5
                ye = VIEW_TOP
                context.set_source_rgb(0.4, 0.4, 0.4)
                context.move_to(x - 22, 15)
                context.set_font_size(10)
                context.show_text("%s" % time_str)
                context.stroke()
                context.set_line_width(0.75)
            context.set_source_rgb(0, 0, 0)
            context.move_to(x, yb)
            context.line_to(x, ye)
            context.stroke()
            
        for indice in self.__indices_tables:
            if indice >= self.__cells_view['time_position']:
                if indice <= (self.__cells_view['time_position'] + self.__cells_view['time_length']):
                    x = self.__time_to_x(indice)
                    if self.__major_indice == 1:
                        if indice == int(indice):
                            draw_indice(x, context, True, self._time_to_str(indice))
                        else:
                            draw_indice(x, context, False, self._time_to_str(indice))
                    elif self.__major_indice == 10:
                        if indice == int(indice / 10) * 10:
                            draw_indice(x, context, True, self._time_to_str(indice))
                        else:
                            draw_indice(x, context, False, self._time_to_str(indice))
                    elif self.__major_indice == 60:
                        if indice == int(indice / 60) * 60:
                            draw_indice(x, context, True, self._time_to_str(indice))
                        else:
                            draw_indice(x, context, False, self._time_to_str(indice))
                    elif self.__major_indice == 600:
                        if indice == int(indice / 600) * 600:
                            draw_indice(x, context, True, self._time_to_str(indice))
                        else:
                            draw_indice(x, context, False, self._time_to_str(indice))
                else:
                    break
                    
    def draw_legend(self, context):
        legend_top = VIEW_TOP + self.__cells_view['height'] + SCROLLBAR_HEIGHT + SCROLLBAR_TOP_BORDER
        # Unassigned block
        x = VIEW_LEFT
        y = legend_top + 6
        context.rectangle(x, y, 10, 10)
        context.set_source_rgb(*BLOCK_UNASSIGNED_COLOR)
        context.fill_preserve()
        context.set_source_rgb(0, 0, 0)
        context.set_line_width(1)
        context.stroke()
        x = VIEW_LEFT + 20
        y = legend_top + 15
        context.set_source_rgb(0, 0, 0)
        context.move_to(x, y)
        context.set_font_size(10)
        context.show_text(self.__strings['legend_block_not_configured'])
        context.stroke()
        # Undefined duration
        x = VIEW_LEFT
        y = legend_top + 21
        context.rectangle(x, y, 10, 10)
        context.set_source_rgb(*BLOCK_NODURATION_COLOR)
        context.fill_preserve()
        context.set_source_rgb(0, 0, 0)
        context.set_line_width(1)
        context.stroke()
        x = VIEW_LEFT + 20
        y = legend_top + 30
        context.set_source_rgb(0, 0, 0)
        context.move_to(x, y)
        context.set_font_size(10)
        context.show_text(self.__strings['legend_block_without_duration'])
        context.stroke()
        # Unfocused
        x = VIEW_LEFT + 200
        y = legend_top + 6
        context.rectangle(x, y, 10, 10)
        context.set_source_rgb(*BLOCK_UNFOCUSED_COLOR)
        context.fill_preserve()
        context.set_source_rgb(0, 0, 0)
        context.set_line_width(1)
        context.stroke()
        x = VIEW_LEFT + 220
        y = legend_top + 15
        context.set_source_rgb(0, 0, 0)
        context.move_to(x, y)
        context.set_font_size(10)
        context.show_text(self.__strings['legend_block_with_duration'])
        context.stroke()
        # Focused
        x = VIEW_LEFT + 200
        y = legend_top + 21
        context.rectangle(x, y, 10, 10)
        context.set_source_rgb(*BLOCK_FOCUSED_COLOR)
        context.fill_preserve()
        context.set_source_rgb(0, 0, 0)
        context.set_line_width(1)
        context.stroke()
        x = VIEW_LEFT + 220
        y = legend_top + 30
        context.set_source_rgb(0, 0, 0)
        context.move_to(x, y)
        context.set_font_size(10)
        context.show_text(self.__strings['legend_block_is_focused'])
        context.stroke()
        
    def draw(self, context):
        rect = self.get_allocation()
        # Background
        context.rectangle(rect.x, rect.y, rect.width, rect.height)
        context.set_source_rgb(1, 1, 1)
        context.fill_preserve()
        context.set_source_rgb(0, 0, 0)
        context.set_line_width(1)
        context.stroke()
        # Scrollbar
        self.__scrollbar.draw(context)
        # Timeline indices
        self.draw_timeline_indic(context)
        # Cells area
        context.rectangle(  self.__cells_view['left'], 
                            self.__cells_view['top'],
                            self.__cells_view['width'],
                            self.__cells_view['height'])
        context.set_source_rgb(1, 1, 1)
        context.fill_preserve()
        context.set_source_rgb(0, 0, 0)
        context.set_line_width(1)
        context.stroke()
        for block_container in self.block_containers:
            block_container.draw_all(context)
        # Dragging bars
        if self.__dragging_block:
            x = self.__time_to_x(self.__focused_block.get_position())
            if (x >= self.__cells_view['left']) and (x <= self.__cells_view['left'] + self.__cells_view['width']):
                context.set_line_width(0.5)
                context.set_source_rgb(0.0, 0.0, 0.5)
                context.move_to(x, self.__cells_view['top'])
                context.line_to(x, self.__cells_view['top'] + self.__cells_view['height'])
                context.stroke()
            x = self.__time_to_x(self.__focused_block.get_position() + self.__focused_block.get_length())
            if (x >= self.__cells_view['left']) and (x <= self.__cells_view['left'] + self.__cells_view['width']):
                context.set_line_width(0.5)
                context.set_source_rgb(0.0, 0.0, 0.5)
                context.move_to(x, self.__cells_view['top'])
                context.line_to(x, self.__cells_view['top'] + self.__cells_view['height'])
                context.stroke()
        # Current pos bar
        if True:
            coeff = float(self.__cells_view['time_length']) / self.__cells_view['width']
            nx = self.__cells_view['time_position'] / coeff
            x = (self.__current_position / coeff) + self.__cells_view['left'] - nx
            if (x >= self.__cells_view['left']) and (x <= self.__cells_view['left'] + self.__cells_view['width']):
                context.set_line_width(2)
                context.set_source_rgb(0.0, 0.0, 0.0)
                context.move_to(x, self.__cells_view['top'])
                context.line_to(x, self.__cells_view['top'] + self.__cells_view['height'])
                context.stroke()
                context.set_source_rgba(0, 0, 0)
                context.arc(x, self.__cells_view['top'], 3, 0, 2.0 * math.pi)
                context.fill()
                context.stroke()
                
        # Draw legend
        self.draw_legend(context)
        # Draw buttons
        self.__zoom_plus_button.draw(context)
        self.__zoom_minus_button.draw(context)
        self.__zoom_full_button.draw(context)
            
    def set_focused_row(self, row_index):
        self.__focused_row = row_index
        for i, block_container in enumerate(self.block_containers):
            if i == row_index:
                block_container.set_focused(True)
            else:
                block_container.set_focused(False)
                
    def set_focused_block(self, block):
        for block_container in self.block_containers:
            for mblock in block_container._blocks:
                mblock.set_focused(False)
        self.__focused_block = block
        block.set_focused(True)
        
    def create_block(self, row_index, function_params, time_begin, time_length):
        block = self.block_containers[row_index].new_block()
        block.set_position(time_begin)
        block.set_function_params(function_params)
        block.set_length(time_length)
        self._recalc_full_time()
        self.refresh()
        return block
        
    def delete_block(self, block):
        if block == None:
            return
        for block_container in self.block_containers:
            for j, mblock in enumerate(block_container._blocks):
                if mblock == block:
                    if block._alive:
                        block_container.delete_block(j)
                        self._recalc_full_time()
                        self.refresh()
                    break
    
    def clear_blocks(self):
        for block_container in self.block_containers:
            block_container.clear_blocks()
                
    def get_focused_row(self):
        return self.__focused_row
        
    def set_zoom_factor(self, zoom_factor):
        zoom_max = math.sqrt(self.__info['full_time_length'] / ZOOM_DEPTH_COEFF) + 1
        if zoom_factor > zoom_max:
            zoom_factor = zoom_max
        if zoom_factor < 1:
            zoom_factor = 1
        self.__zoom_factor = int(zoom_factor)
        zoom_factor = zoom_factor * zoom_factor
        t_range = self.__info['full_time_length'] / zoom_factor
        center = self.__current_position
        start = center - (t_range / 2)
        if start < 0:
            start = 0
        end = start + t_range
        if end > self.__info['full_time_length']:
            end = self.__info['full_time_length']
            start = end - t_range
        self.__cells_view['time_length'] = float(end - start)
        self.__cells_view['time_position'] = float(start)
        if self.__events_list['zoom_changed'] != None:
            self.__events_list['zoom_changed'](self.__zoom_factor)
        self.__update_coord()
        self.__update_timeline_indic()
        self.refresh()
        
    def set_current_position(self, value):
        self.__current_position = value
        if self.__events_list['time_position_changed'] != None:
                self.__events_list['time_position_changed'](self.__current_position)
        self.refresh()
        
    def get_current_position(self):
        return self.__current_position
    
    def get_length(self):
        return self.__info['full_time_length']
        
    def get_view_length(self):
        return self.__cells_view['time_length']
        
    def get_view_position(self):
        return self.__cells_view['time_position']
        
    def get_block_list(self):
        lst = []
        for block_container in self.block_containers:
            mlst = block_container.get_block_list()
            for b in mlst:
                lst.append(b)
        return lst
        
    def _recalc_full_time(self):
        self.__check_blocks_ecart()
        max_time = 0.0
        for block_container in self.block_containers:
            for mblock in block_container._blocks:
                if mblock._alive:
                    val = mblock.get_position() + mblock.get_length()
                    if val > max_time:
                        max_time = val
        if max_time > 600.0:
            return
        if max_time == 0.0:
            max_time = 10.0
        if self.__info['full_time_length'] != max_time:
            self.__info['full_time_length'] = max_time
            if self.__info['full_time_length'] < 10.0:
                self.__info['full_time_length'] = 10.0
            if self.__current_position > self.__info['full_time_length']:
                self.__current_position = self.__info['full_time_length']
            self.set_zoom_factor(self.__zoom_factor)
            if self.__events_list['full_time_changed'] != None:
                self.__events_list['full_time_changed'](max_time)
        
    def _time_to_str(self, time):
        d_msec = int(time * 1000)
        minutes = d_msec / 60000
        reste = d_msec % 60000
        seconds = reste / 1000
        reste = reste % 1000
        mseconds = reste / 10
        ret = "%.2d:%.2d:%.2d" % (minutes, seconds, mseconds)
        return ret
        
class TimelineReader(object):

    def __init__(self, tux, timeline, scene):
        self.__block_list = []
        self.__instant_list = []
        self.__time_begin = 0.0
        self.__current_time = 0.0
        self.tux = tux
        self.timeline = timeline
        self.scene = scene
        self.__stop_flag_mutex = threading.Lock()
        self.__stop_flag = True
        
    def set_list(self, lst):
        self.__block_list = lst
    
    def set_scene(self, scene):
        self.scene = scene
         
    def _to_instant_list(self):
        self.__instant_list = []
        for st in self.__block_list:
            tb = float(int(st[0] * 100)) / 100
            delay = 0.0
            if st[1]['cmd'] in ['tts_play', 'wav_play']:
                delay = 0.5
            self.__instant_list.append([tb, st[1], st[2], delay])
            
    def to_xml_struct(self):
        self._to_instant_list()
        blk_struct = {}
        counter = 0
        while True:
            blk = self.get_next()
            if blk == None:
                break
            params = copy(blk[1])
            params['start_time'] = blk[0]
            blk_name = "block_%.3d" % counter
            counter += 1
            blk_struct[blk_name] = params
        if self.scene != None:
            self.scene.set_timeline_struct(blk_struct)
            
    def from_xml_struct(self):
    
        def get_row(cmd):
            for cmd_type in LEDS_CMD_TYPES:
                if cmd in LEDS_CMD_TYPES[cmd_type]:
                    return CHANNEL_LEDS
            for cmd_type in MOUTH_EYES_CMD_TYPES:
                if cmd in MOUTH_EYES_CMD_TYPES[cmd_type]:
                    return CHANNEL_EYESMOUTH
            for cmd_type in WINGS_CMD_TYPES:
                if cmd in WINGS_CMD_TYPES[cmd_type]:
                    return CHANNEL_WINGS
            for cmd_type in SPINNING_CMD_TYPES:
                if cmd in SPINNING_CMD_TYPES[cmd_type]:
                    return CHANNEL_SPIN
            for cmd_type in SOUND_CMD_TYPES:
                if cmd in SOUND_CMD_TYPES[cmd_type]:
                    return CHANNEL_SOUND
            for cmd_type in TTS_CMD_TYPES:
                if cmd in TTS_CMD_TYPES[cmd_type]:
                    return CHANNEL_TTS
                    
        self.__instant_list = []
        struct = self.scene.get_timeline_struct()
        keys = struct.keys()
        keys.sort()
        for key in keys:
            params = copy(struct[key])
            row = get_row(params['cmd'])
            time_pos = params['start_time']
            params.pop('start_time')
            block = STMBlockWav(row)
            block.set_position(time_pos)
            block.set_function_params(params)
            duration = 0.0
            #if params.has_key('duration'):
            #    duration = params['duration']
            block.set_length(duration)
            if params['cmd'] == 'wav_play':
                wav_path = self.scene.get_wav(params['wav_name'])
                if wav_path != None:
                    block.load_wavefile(wav_path)
                    
            tb = float(int(block.get_position() * 100)) / 100
            delay = 0.0
            if params['cmd'] in ['tts_play', 'wav_play']:
                delay = 0.5
            self.__instant_list.append([tb, params, block, delay])
    
    def get_next(self):
        result = None
        lower_time = 1000000000.0
        idx = -1
        for i, st in enumerate(self.__instant_list):
            if (st[0] - st[3]) < lower_time:
                lower_time = st[0]
                idx = i
        if idx != -1:
            result = copy(self.__instant_list[idx])
            self.__instant_list.pop(idx)
        return result
        
    def get_first(self, position_begin):
        r_block = None
        while True:
            m_block = self.get_next()
            if m_block == None:
                break
            if m_block[0] >= position_begin:
                r_block = m_block
                break
        return r_block
        
    def play_cmd(self, block):
        if not self.__get_stop_flag():
            return
        self.__set_stop_flag(False)
        params = block.get_function_params()
        delay = 0.0
        if params['cmd'] in ['tts_play', 'wav_play']:
            delay = 0.5
        self.__eval_cmd(params, block, delay)
        self.__set_stop_flag(True)
        
    def __eval_cmd(self, params, block, delay):
        def update_length(t):
            duration = (time.time() - t) - delay
            params['duration'] = duration
            block.set_length(duration)
            if self.timeline != None:
                self.timeline._recalc_full_time()
                self.timeline.refresh()
    
        cmd = params['cmd']
        if cmd == 'leds_on':
            self.tux.cmd.leds_on()
        elif cmd == 'leds_off':
            self.tux.cmd.leds_off()
        elif cmd == 'ledl_on':
            self.tux.cmd.ledl_on()
        elif cmd == 'ledl_off':
            self.tux.cmd.ledl_off()
        elif cmd == 'ledr_on':
            self.tux.cmd.ledr_on()
        elif cmd == 'ledr_off':
            self.tux.cmd.ledr_off()
        elif cmd == 'leds_blink':
            self.tux.cmd.leds_blink(int(params['count']), int(params['speed']))
        elif cmd == 'mouth_on':
            t = time.time()
            self.tux.cmd.mouth_on(params['count'])
            update_length(t)
        elif cmd == 'mouth_open':
            t = time.time()
            self.tux.cmd.mouth_open()
            update_length(t)
        elif cmd == 'mouth_close':
            t = time.time()
            self.tux.cmd.mouth_close()
            update_length(t)
        elif cmd == 'eyes_on':
            t = time.time()
            self.tux.cmd.eyes_on(params['count'])
            update_length(t)
        elif cmd == 'eyes_open':
            t = time.time()
            self.tux.cmd.eyes_open()
            update_length(t)
        elif cmd == 'eyes_close':
            t = time.time()
            self.tux.cmd.eyes_close()
            update_length(t)
        elif cmd == 'wings_on':
            t = time.time()
            self.tux.cmd.wings_on(int(params['count']))
            update_length(t)
        elif cmd == 'wings_up':
            t = time.time()
            self.tux.cmd.wings_up()
            update_length(t)
        elif cmd == 'wings_down':
            t = time.time()
            self.tux.cmd.wings_down()
            update_length(t)
        elif cmd == 'spinl_on':
            t = time.time()
            self.tux.cmd.spinl_on(int(params['count']), int(params['speed']))
            update_length(t)
        elif cmd == 'spinr_on':
            t = time.time()
            self.tux.cmd.spinr_on(int(params['count']), int(params['speed']))
            update_length(t)
        elif cmd == 'tts_play':
            if params['speaker'] <= 0:
                speaker = 3
            else:
                speaker = int(params['speaker'])
            self.tux.tts.select_voice(speaker, int(params['pitch']))
            t = time.time()
            self.tux.tts.stop()
            self.tux.tts.speak(params['text'])
            update_length(t)
        elif cmd == 'sound_play':
            self.tux.cmd.sound_play(params['index'])
        elif cmd == 'wav_play':
            path = params['wav_name']
            if self.scene != None:
                self.tux.wav.stop()
                self.scene.play_wav(path)
            
    def __set_stop_flag(self, value):
        self.__stop_flag_mutex.acquire()
        self.__stop_flag = value
        self.__stop_flag_mutex.release()
        
    def __get_stop_flag(self):
        self.__stop_flag_mutex.acquire()
        value = self.__stop_flag
        self.__stop_flag_mutex.release()
        return value
        
    def stop_read(self):
        self.__set_stop_flag(True)
        self.tux.wav.stop()
        
    def read_loop(self, time_position, time_end):
        if not self.__get_stop_flag():
            return
        if time_position < 0.05:
            time_position = 0.0
        time_begin = time.time() - time_position
        m_block = self.get_first(time_position)
        if m_block == None:
            return
        self.__set_stop_flag(False)
        # First block
        if time_position > (m_block[0] - m_block[3]):
            delay = (time_position - (m_block[0] - m_block[3]))
            t = threading.Thread(target = self.__eval_cmd, args = (m_block[1], m_block[2], m_block[3]))
            t.start()
            time.sleep(delay)
            time_begin += delay
        else:
            while (time.time() - time_begin) < (m_block[0] - m_block[3]):
                if self.__get_stop_flag():
                    if self.timeline != None:
                        self.timeline.set_current_position(time_position)
                    self.__set_stop_flag(True)
                    return
                if (time.time() - time_begin) >= time_end:
                    if self.timeline != None:
                        self.timeline.set_current_position(time_position)
                    self.tux.wav.stop()
                    self.__set_stop_flag(True)
                    return
                time.sleep(0.01)
                if self.timeline != None:
                    self.timeline.set_current_position(time.time() - time_begin)
            t = threading.Thread(target = self.__eval_cmd, args = (m_block[1], m_block[2], m_block[3]))
            t.start()
        # Other bocks
        while True:
            m_block = self.get_next()
            if m_block == None:
                break
            while (time.time() - time_begin) < (m_block[0] - m_block[3]):
                if self.__get_stop_flag():
                    if self.timeline != None:
                        self.timeline.set_current_position(time_position)
                    self.__set_stop_flag(True)
                    return
                if (time.time() - time_begin) >= time_end:
                    if self.timeline != None:
                        self.timeline.set_current_position(time_position)
                    self.tux.wav.stop()
                    self.__set_stop_flag(True)
                    return
                time.sleep(0.01)
                if self.timeline != None:
                    self.timeline.set_current_position(time.time() - time_begin)
            t = threading.Thread(target = self.__eval_cmd, args = (m_block[1], m_block[2], m_block[3]))
            t.start()
        # Wait end 
        while (time.time() - time_begin) < time_end:
            if self.__get_stop_flag():
                if self.timeline != None:
                    self.timeline.set_current_position(time_position)
                self.__set_stop_flag(True)
                return
            time.sleep(0.01)
            if self.timeline != None:
                self.timeline.set_current_position(time.time() - time_begin)
        if self.timeline != None:
            self.timeline.set_current_position(time_position)
        self.__set_stop_flag(True)
