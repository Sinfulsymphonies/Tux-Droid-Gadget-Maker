import time

PANEL_TTS = 7
PANEL_BLANK = 5

PLAY_TTS_CANVAS = {'cmd' : 'tts_play', 'text' : "Hello world", 'speaker' : 3, 'pitch': 100, 'duration' : 0.0}

TTS_CMD_TYPES = {
    'TTS':
        [
            'tts_play',
        ],
}

def update_tts_combobox(parent):
    parent._cmd_type_model.clear()
    lst = []
    for cmd_type in TTS_CMD_TYPES .keys():
        lst.append(cmd_type)
    lst.sort()
    for n in lst:
        parent._cmd_type_model.append([n])
    parent._cmd_type_cbb.set_model(parent._cmd_type_model)
    time.sleep(0.1)
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_BLANK)
   
def update_tts_panel(parent, block, cmd): 
    if not cmd in TTS_CMD_TYPES['TTS']:
        parent._notebook.set_current_page(PANEL_BLANK)
        return
    sb_pitch = parent.get_widget("spinbutton7")
    tv_text = parent.get_widget("textview1")
    cbb_voices = parent._voice_cbb
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_TTS)
    p = block.get_function_params()
    spk = p['speaker']
    cbb_voices.set_spk(spk)
    buff = tv_text.get_buffer()
    buff.set_text(p['text'])
    sb_pitch.set_value(int(p['pitch']))
    
def update_tts_block(parent, block):
    sb_pitch = parent.get_widget("spinbutton7")
    tv_text = parent.get_widget("textview1")
    cbb_voices = parent._voice_cbb
    cmd = 'tts_play'
    p = block.get_function_params()
    p['cmd'] = cmd
    spk, lng = cbb_voices.get_current_spk_conf()
    p['speaker'] = spk
    p['pitch'] = int(sb_pitch.get_value())
    buffer = tv_text.get_buffer()
    text = buffer.get_text(*buffer.get_bounds())
    p['text'] = text
    parent._update_block_params(block, p)
    update_tts_panel(parent, block, cmd)
