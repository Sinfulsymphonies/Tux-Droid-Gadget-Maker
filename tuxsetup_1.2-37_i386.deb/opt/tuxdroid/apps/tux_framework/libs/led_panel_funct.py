import time

PANEL_LED_ON_OFF = 0
PANEL_LED_BLINK = 1
PANEL_BLANK = 5

LEDS_BLINK_CANVAS = {'cmd' : 'leds_blink', 'count' : 1.0, 'speed' : 1}
LEDS_ON_CANVAS = {'cmd' : 'leds_on', 'duration' : 0.0}
LEDL_ON_CANVAS = {'cmd' : 'ledl_on', 'duration' : 0.0}
LEDR_ON_CANVAS = {'cmd' : 'ledr_on', 'duration' : 0.0}
LEDS_OFF_CANVAS = {'cmd' : 'leds_off', 'duration' : 0.0}
LEDL_OFF_CANVAS = {'cmd' : 'ledl_off', 'duration' : 0.0}
LEDR_OFF_CANVAS = {'cmd' : 'ledr_off', 'duration' : 0.0}

LEDS_CMD_TYPES = {
    'Led on/off': 
        [
            'leds_on', 
            'ledl_on', 
            'ledr_on',
            'leds_off', 
            'ledl_off', 
            'ledr_off'
        ],
    'Leds blink':
        ['leds_blink'],
}

def update_led_combobox(parent):
    parent._cmd_type_model.clear()
    lst = []
    for cmd_type in LEDS_CMD_TYPES.keys():
        lst.append(cmd_type)
    lst.sort()
    for n in lst:
        parent._cmd_type_model.append([n])
    parent._cmd_type_cbb.set_model(parent._cmd_type_model)
    time.sleep(0.1)
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_BLANK)
    
def update_led_on_off_panel(parent, block, cmd):
    if not cmd in LEDS_CMD_TYPES['Leds blink']:
        if not cmd in LEDS_CMD_TYPES['Led on/off']:
            parent._notebook.set_current_page(PANEL_BLANK)
            return
    cbbe_affected = parent.get_widget("comboboxentry2")
    rb_on = parent.get_widget("radiobutton20")
    rb_off = parent.get_widget("radiobutton21")
    parent._cmd_type_cbb.set_active(0)
    parent._notebook.set_current_page(PANEL_LED_ON_OFF)
    if cmd in ['leds_on', 'ledl_on', 'ledr_on']:
        rb_on.set_active(True)
    else:
        rb_off.set_active(True)
    if cmd in ['leds_on', 'leds_off']:
        cbbe_affected.set_active(0)
    elif cmd in ['ledl_on', 'ledl_off']:
        cbbe_affected.set_active(1)
    else:
        cbbe_affected.set_active(2)
        
def update_led_on_off_block(parent, block):
    cbbe_affected = parent.get_widget("comboboxentry2")
    rb_on = parent.get_widget("radiobutton20")
    rb_off = parent.get_widget("radiobutton21")
    if rb_on.get_active():
        cmd = "_on"
    else:
        cmd = "_off"
    if cbbe_affected.get_active() == 0:
        cmd = "leds" + cmd
    elif cbbe_affected.get_active() == 1:
        cmd = "ledl" + cmd
    else:
        cmd = "ledr" + cmd
    p = block.get_function_params()
    p['cmd'] = cmd
    parent._update_block_params(block, p)
    update_led_on_off_panel(parent, block, cmd)
    
def update_led_blink_panel(parent, block, cmd):
    if not cmd in LEDS_CMD_TYPES['Leds blink']:
        if not cmd in LEDS_CMD_TYPES['Led on/off']:
            parent._notebook.set_current_page(PANEL_BLANK)
            return
    parent._cmd_type_cbb.set_active(1)
    parent._notebook.set_current_page(PANEL_LED_BLINK)
    p = block.get_function_params()
    count = 20
    if p.has_key('count'):
        count = p['count']
    parent.get_widget("spinbutton1").set_value(count)
    speed = 200
    if p.has_key('speed'):
        speed = 255 - p['speed']
    parent.get_widget("hscale1").set_value(speed)
        
def update_led_blink_block(parent, block):
    p = block.get_function_params()
    cmd = 'leds_blink'
    p['cmd'] = cmd
    p['speed'] = 255 - parent.get_widget("hscale1").get_value()
    p['count'] = parent.get_widget("spinbutton1").get_value()
    parent._update_block_params(block, p)
    update_led_blink_panel(parent, block, cmd)
