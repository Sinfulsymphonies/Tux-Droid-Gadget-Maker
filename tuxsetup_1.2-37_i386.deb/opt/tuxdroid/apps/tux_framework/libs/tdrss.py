#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - RSS Lib
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------

from GdgDownload import check_server_available, download_file

def rss_server_available(url, timeout):
    """
    Check if a server is available.

        Parameters:
        "url" as string         : url of the server
        "timeout" as integer    : timeout in seconds

        Returns:
        A boolean.
    """
    return check_server_available(url, timeout)

def rss_read_url(url, timeout):
    """
    Download an url.

        Parameters:
        "url" as string         : url of the file
        "timeout" as integer    : timeout in seconds

        Returns:
        A tuple(<boolean>, <string>)
    """
    return download_file(url, timeout)
