#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - Behavior combobox
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import thread
import gobject
import gtk
import os
import sys
from GdgObject import scene_container

class BehaviorComboBoxFull(object):

    def __init__(self, gtk_combobox_widget):
        self.__combobox = gtk_combobox_widget
        self.__scene_list = gtk.ListStore(gobject.TYPE_STRING)

    def update(self):
        self.__scene_list.clear()
        scene_list = scene_container.get_list()
        for scene in scene_list:
            self.__scene_list.append([scene,])
        self.__combobox.set_model(self.__scene_list)

    def set_active(self, scene_name):
        self.update()
        scene_list = scene_container.get_list()
        idx = -1
        for i, scene in enumerate(scene_list):
            if scene == scene_name:
                idx = i
        if idx != -1:
            self.__combobox.set_active(idx)
        elif len(scene_list) > 0:
            self.__combobox.set_active(0)

    def get_active(self):
        if len(self.__scene_list) > 0:
            idx = self.__combobox.get_active()
            return self.__scene_list[idx][0]
        else:
            return None

class BehaviorComboBoxCategories(object):

    def __init__(self, gtk_combobox_widget):
        self.__combobox = gtk_combobox_widget
        self.__cat_list = gtk.ListStore(gobject.TYPE_STRING)

    def update(self):
        self.__cat_list.clear()
        cat_list = scene_container.get_cat_list()
        for cat in cat_list:
            self.__cat_list.append([cat,])
        self.__combobox.set_model(self.__cat_list)

    def set_active(self, cat_name):
        self.update()
        cat_list = scene_container.get_cat_list()
        idx = -1
        for i, cat in enumerate(cat_list):
            if cat == cat_name:
                idx = i
        if idx != -1:
            self.__combobox.set_active(idx)
        elif len(cat_list) > 0:
            self.__combobox.set_active(0)

    def get_active(self):
        if len(self.__cat_list) > 0:
            idx = self.__combobox.get_active()
            return self.__cat_list[idx][0]
        else:
            return None
