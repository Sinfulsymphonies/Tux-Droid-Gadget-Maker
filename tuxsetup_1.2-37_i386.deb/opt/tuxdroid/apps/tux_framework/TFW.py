#!/usr/bin/env python
# -*- coding: latin1 -*-
import os
import sys
PATH_APP = os.path.realpath(os.path.dirname(sys.argv[0]))
try:
    sys.path.append(PATH_APP + '/libs')
    from FWObject import GdgFramework
    from GdgObject import *
except:
    sys.path.append('/opt/tuxdroid/apps/tux_framework/libs')
    from FWObject import GdgFramework
    from GdgObject import *

if len(sys.argv) == 2:
    tgf_path = sys.argv[1]
    framework = GdgFramework(tgf_path)
    framework.run()
else:
    finalize()
