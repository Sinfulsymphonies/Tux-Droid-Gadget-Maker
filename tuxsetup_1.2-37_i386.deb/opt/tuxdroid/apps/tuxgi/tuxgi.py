#!/usr/bin/env python
# -*- coding: utf-8 -*-

# -----------------------------------------------------------------------------
# Tux Droid - Graphique Interface
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------

# -----------------------------------------------
# Initalization of modules
# uses objects "tux" and "tss"
# -----------------------------------------------
import sys
sys.path.append('/opt/tuxdroid/api/python')
from tux import *
# -----------------------------------------------
# Your script
# -----------------------------------------------
import os
from version import app_version
import gtk
import gobject
import thread

from SimpleGladeApp import SimpleGladeApp
from SimpleGladeApp import bindtextdomain

app_name = "tuxgi2"
print "Graphical TuxDroid Interface " + app_version
glade_dir = ""
locale_dir = ""
soundcard = tux.hw.alsa_device

bindtextdomain(app_name, locale_dir)

scommand_window=None
onpause=False
onplay=False
status_list_st=[]
status_list_changed=False
toggled_by_event=False

terminal_shells = [
    ('gnome-terminal', '-x'), # gnome
    ('konsole', '-e'), # kde
    ('Terminal', '-x'), # xfce
    ('xfce4-terminal', '-x'), # xfce
    ('xterm', '-e'), # X
    ] # list of tuple instead of a dictionary as the order matters

voice_list_changed = False
voice_list = gtk.ListStore(gobject.TYPE_STRING)
voice_dic = {}
current_voice = ""
if not os.popen('type ipython 2>/dev/null').close():
    py_cmd = 'ipython'
else:
    py_cmd = 'python'

xterm_cmd = None
for term in terminal_shells:
    if not os.popen('type %s 2>/dev/null' % term[0]).close():
        xterm_cmd = '%s %s %s -i /opt/tuxdroid/api/python/tux.py' \
            % (term[0], term[1], py_cmd)
        break

if xterm_cmd is None:
    sys.stderr.write("Warning: couldn't find any suitable terminal"
                     " to use as Tux Droid shell\n")

#==============================================================================
# Main window class
#==============================================================================
class Window1(SimpleGladeApp):

    #--------------------------------------------------------------------------
    # Class init
    #--------------------------------------------------------------------------
    def __init__(self, path="tuxgi2.glade",
                 root="window1",
                 domain=app_name, **kwargs):
        path = os.path.join(glade_dir, path)
        SimpleGladeApp.__init__(self, path, root, domain, **kwargs)

    #--------------------------------------------------------------------------
    # On new window
    #--------------------------------------------------------------------------
    def new(self):
        self.update_voice_list()
        tux.tts.on_sound_on=self.on_sound_on
        tux.tts.on_sound_off=self.on_sound_off
        tux.tts.on_voice_list=self.on_voice_list
        tux.event.on_status=self.on_status
        tux.event.on_left_blue_led_on=self.on_left_blue_led_on
        tux.event.on_left_blue_led_off=self.on_left_blue_led_off
        tux.event.on_right_blue_led_on=self.on_right_blue_led_on
        tux.event.on_right_blue_led_off=self.on_right_blue_led_off
        tux.event.on_mouth_stop=self.on_mouth_stop
        tux.event.on_eyes_stop=self.on_eyes_stop
        thread.start_new_thread(self.status_viewer_thread,())
        tux.daemon.auto_connect(True)
        tux.tts.auto_connect(True)

    #--------------------------------------------------------------------------
    # On window destroy
    #--------------------------------------------------------------------------
    def on_window1_destroy(self, widget, *args):
        global toggled_by_event
        toggled_by_event=True
        tux.destroy()
        sys.exit(0)

    #--------------------------------------------------------------------------
    # On left blue led status is on
    #--------------------------------------------------------------------------
    def on_left_blue_led_on(self):
        global toggled_by_event
        toggled_by_event=True
        self.get_widget("checkbutton1").set_active(True)
        toggled_by_event=False

    #--------------------------------------------------------------------------
    # On left blue led status is off
    #--------------------------------------------------------------------------
    def on_left_blue_led_off(self):
        global toggled_by_event
        toggled_by_event=True
        self.get_widget("checkbutton1").set_active(False)
        toggled_by_event=False

    #--------------------------------------------------------------------------
    # On right blue led status is on
    #--------------------------------------------------------------------------
    def on_right_blue_led_on(self):
        global toggled_by_event
        toggled_by_event=True
        self.get_widget("checkbutton2").set_active(True)
        toggled_by_event=False

    #--------------------------------------------------------------------------
    # On right blue led status is off
    #--------------------------------------------------------------------------
    def on_right_blue_led_off(self):
        global toggled_by_event
        toggled_by_event=True
        self.get_widget("checkbutton2").set_active(False)
        toggled_by_event=False

    #--------------------------------------------------------------------------
    # On mouth stop
    #--------------------------------------------------------------------------
    def on_mouth_stop(self):
        global toggled_by_event
        toggled_by_event=True
        if tux.status.get_mouth_open_position()==0:
            self.get_widget("radiobutton3").set_active(True)
        else:
            self.get_widget("radiobutton4").set_active(True)
        toggled_by_event=False

    #--------------------------------------------------------------------------
    # On eyes stop
    #--------------------------------------------------------------------------
    def on_eyes_stop(self):
        global toggled_by_event
        toggled_by_event=True
        if tux.status.get_eyes_closed_position_switch()==1:
            self.get_widget("radiobutton1").set_active(True)
        else:
            self.get_widget("radiobutton2").set_active(True)
        toggled_by_event=False

    #--------------------------------------------------------------------------
    # Event on status
    #--------------------------------------------------------------------------
    def on_status(self,frame):
        global status_list_st
        global status_list_changed
        explicite_status=tux.explicit_status(frame)
        if explicite_status.find("RF connected->") != 0:
            status_list_changed=True
            status_list_st.append(explicite_status)
            if len(status_list_st)==50:
                for i in range(1):
                    status_list_st.pop(0)

    #--------------------------------------------------------------------------
    # Status viewer refreshing thread
    #--------------------------------------------------------------------------
    def status_viewer_thread(self):
        global status_list_st
        global status_list_changed
        global onpause
        global onplay
        global voice_list_changed

        last_tuxdaemon_connect=False
        last_tuxttsdaemon_connect=False
        last_rf_state=False
        while True:
            if status_list_changed:
                status_list_changed=False
                statusview_b=self.get_widget("textview1").get_buffer()
                statusview_b.set_text("")
                startiter = statusview_b.get_start_iter()
                string=""
                if self.get_widget("checkbutton3").get_active():
                    for i in range(len(status_list_st)):
                        string=status_list_st[i]+"\n"+string
                else:
                    string=status_list_st[len(status_list_st)-1]+"\n"
                statusview_b.insert(startiter,string)
            if tux.daemon.connected!=last_tuxdaemon_connect:
                last_tuxdaemon_connect=tux.daemon.connected
                if tux.daemon.connected:
                    onpause=False
                    onplay=False
                    global toggled_by_event
                    toggled_by_event=True
                    global soundcard
                    tux.hw.alsa_devices_select(0)
                    soundcard = tux.hw.alsa_device
                    self.get_widget("togglebutton3").set_active(False)
                    toggled_by_event=False
                    self.get_widget("image2").set_from_stock(gtk.STOCK_APPLY\
                    ,gtk.ICON_SIZE_BUTTON)
                    self.on_mouth_stop()
                    self.on_eyes_stop()
                    tux.cmd.leds_blink(2,1)
                else:
                    self.get_widget("image2").set_from_stock(gtk.STOCK_CANCEL\
                    ,gtk.ICON_SIZE_BUTTON)
                    tux.status.rf_connected = False
            if tux.tts.connected!=last_tuxttsdaemon_connect:
                last_tuxttsdaemon_connect=tux.tts.connected
                if tux.tts.connected:
                    self.get_widget("image3").set_from_stock(gtk.STOCK_APPLY\
                    ,gtk.ICON_SIZE_BUTTON)
                else:
                    self.get_widget("image3").set_from_stock(gtk.STOCK_CANCEL\
                    ,gtk.ICON_SIZE_BUTTON)
            if tux.status.rf_state()!=last_rf_state:
                last_rf_state = tux.status.rf_connected
                if last_rf_state:
                    self.get_widget("image4").set_from_stock(gtk.STOCK_APPLY\
                    ,gtk.ICON_SIZE_BUTTON)
                else:
                    self.get_widget("image4").set_from_stock(gtk.STOCK_CANCEL\
                    ,gtk.ICON_SIZE_BUTTON)
            if voice_list_changed:
                voice_list_changed = False
                self.update_voice_list()

            tux.sys.wait(0.5)
# -----------------------------------------------------------------------------
# Tab "main" events
# -----------------------------------------------------------------------------

    #--------------------------------------------------------------------------
    # On left led checkbox toggled
    #--------------------------------------------------------------------------
    def on_ledl_toggled(self, widget, *args):
        global toggled_by_event
        if toggled_by_event: return
        if widget.get_active():
            tux.cmd.ledl_on()
        else:
            tux.cmd.ledl_off()

    #--------------------------------------------------------------------------
    # On right led checkbox toggled
    #--------------------------------------------------------------------------
    def on_ledr_toggled(self, widget, *args):
        global toggled_by_event
        if toggled_by_event: return
        if widget.get_active():
            tux.cmd.ledr_on()
        else:
            tux.cmd.ledr_off()

    #--------------------------------------------------------------------------
    # On flash leds button clicked
    #--------------------------------------------------------------------------
    def on_flash_bt_clicked(self, widget, *args):
        def _funct():
            num_sb=self.get_widget("spinbutton1")
            tux.cmd.leds_blink(int(num_sb.get_value()),15)

        thread.start_new_thread(_funct,())

    #--------------------------------------------------------------------------
    # On eyes open radiobutton toggled
    #--------------------------------------------------------------------------
    def on_eyes_open_toggled(self, widget, *args):
        global toggled_by_event
        if toggled_by_event: return
        if widget.get_active():
            tux.cmd.eyes_open()

    #--------------------------------------------------------------------------
    # On eyes close radiobutton toggled
    #--------------------------------------------------------------------------
    def on_eyes_close_toggled(self, widget, *args):
        global toggled_by_event
        if toggled_by_event: return
        if widget.get_active():
            tux.cmd.eyes_close()

    #--------------------------------------------------------------------------
    # On eyes blink button clicked
    #--------------------------------------------------------------------------
    def on_eyes_blink_bt_clicked(self, widget, *args):
        num_sb=self.get_widget("spinbutton2")
        tux.cmd.eyes_on_free(int(num_sb.get_value()))

    #--------------------------------------------------------------------------
    # On beak open radiobutton toggled
    #--------------------------------------------------------------------------
    def on_beak_open_toggled(self, widget, *args):
        global toggled_by_event
        if toggled_by_event: return
        if widget.get_active():
            tux.cmd.mouth_open()

    #--------------------------------------------------------------------------
    # On beak close radiobutton toggled
    #--------------------------------------------------------------------------
    def on_rbeak_close_toggled(self, widget, *args):
        global toggled_by_event
        if toggled_by_event: return
        if widget.get_active():
            tux.cmd.mouth_close()

    #--------------------------------------------------------------------------
    # On beak talk button clicked
    #--------------------------------------------------------------------------
    def on_beak_talk_bt_clicked(self, widget, *args):
        num_sb=self.get_widget("spinbutton3")
        tux.cmd.mouth_on_free(int(num_sb.get_value()))

    #--------------------------------------------------------------------------
    # On flippers up radiobutton toggled
    #--------------------------------------------------------------------------
    def on_flippers_up_toggled(self, widget, *args):
        def _funct():
            global toggled_by_event
            if toggled_by_event: return
            if widget.get_active():
                tux.cmd.raw(0x39,0,0,0)
                tux.event.wait_status(DATAS_STATUS_WINGS_POSITION_COUNTER,0,5)

        thread.start_new_thread(_funct,())

    #--------------------------------------------------------------------------
    # On flippers down radiobutton toggled
    #--------------------------------------------------------------------------
    def on_flippers_down_toggled(self, widget, *args):
        def _funct():
            global toggled_by_event
            if toggled_by_event: return
            if widget.get_active():
                tux.cmd.raw(0x3A,0,0,0)
                tux.event.wait_status(DATAS_STATUS_WINGS_POSITION_COUNTER,0,5)

        thread.start_new_thread(_funct,())

    #--------------------------------------------------------------------------
    # On flippers flap button clicked
    #--------------------------------------------------------------------------
    def on_flippers_flap_bt_clicked(self, widget, *args):
        num_sb=self.get_widget("spinbutton4")
        tux.cmd.wings_on_free(int(num_sb.get_value()))

    #--------------------------------------------------------------------------
    # On rotation button clicked
    #--------------------------------------------------------------------------
    def on_rotation_spin_bt_clicked(self, widget, *args):
        num_sb=self.get_widget("spinbutton5")
        if self.get_widget("radiobutton7").get_active():
            tux.cmd.spinl_on_free(int(num_sb.get_value()))
        else:
            tux.cmd.spinr_on_free(int(num_sb.get_value()))


    #--------------------------------------------------------------------------
    # On "Send command" button clicked
    #--------------------------------------------------------------------------
    def on_scommand_bt_clicked(self, widget, *args):
        Window2().run()

    #--------------------------------------------------------------------------
    # On "Tux Droid shell" button clicked
    #--------------------------------------------------------------------------
    def on_tdshell_bt_clicked(self, widget, *args):
        tux.sys.shell_free(xterm_cmd)

    #--------------------------------------------------------------------------
    # On "Get light level" button clicked
    #--------------------------------------------------------------------------
    def on_cversion_bt_clicked(self, widget, *args):
        thread.start_new_thread(tux.status.get_light_level,())

    #--------------------------------------------------------------------------
    # On "Ping" button clicked
    #--------------------------------------------------------------------------
    def on_ping_bt_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.ping,(200,))

# -----------------------------------------------------------------------------
# Tab "TTS" events
# -----------------------------------------------------------------------------

    #--------------------------------------------------------------------------
    # On "default" button clicked
    #--------------------------------------------------------------------------
    def on_tts_default_bt_clicked(self, widget, *args):
        self.get_widget("comboboxentry1").set_active(2)
        self.get_widget("spinbutton6").set_value(100)

    #--------------------------------------------------------------------------
    # On "play" button clicked
    #--------------------------------------------------------------------------
    def on_tts_play_bt_clicked(self, widget, *args):
        global toggled_by_event
        global voice_dic
        global voice_list
        global current_voice

        if toggled_by_event: return
        global onplay
        if onplay:
            tux.tts.stop()
        else:
            voice_cb=self.get_widget("comboboxentry1")
            pitch_sb=self.get_widget("spinbutton6")
            voice_id = voice_dic[voice_list[voice_cb.get_active()][0]]
            current_voice = voice_list[voice_cb.get_active()][0]
            tux.tts.select_voice(voice_id,pitch_sb.get_value())
            tux.tts.stop()
            textedit=self.get_widget("textview2")
            buffer=textedit.get_buffer()
            my_text=buffer.get_text(*buffer.get_bounds())
            tux.tts.speak_free(my_text)

    #--------------------------------------------------------------------------
    # On "pause" button clicked
    #--------------------------------------------------------------------------
    def on_tts_pause_bt_clicked(self, widget, *args):
        global onpause
        if onpause:
            tux.tts.play()
            onpause=False
        else:
            tux.tts.pause()
            onpause=True

    #--------------------------------------------------------------------------
    # On "Clear text" button clicked
    #--------------------------------------------------------------------------
    def on_tts_ctext_bt_clicked(self, widget, *args):
        textedit=self.get_widget("textview2")
        buffer=textedit.get_buffer()
        buffer.set_text("")

    #--------------------------------------------------------------------------
    # On TTS sound on event
    #--------------------------------------------------------------------------
    def on_sound_on(self):
        global onplay
        global toggled_by_event
        toggled_by_event=True
        self.get_widget("togglebutton3").set_active(True)
        toggled_by_event=False
        onplay=True
        tux.cmd.mouth_open()

    #--------------------------------------------------------------------------
    # On TTS sound off event
    #--------------------------------------------------------------------------
    def on_sound_off(self):
        global onplay
        global toggled_by_event
        toggled_by_event=True
        self.get_widget("togglebutton3").set_active(False)
        toggled_by_event=False
        onplay=False
        tux.cmd.mouth_close()

    #--------------------------------------------------------------------------
    # On new authorized voices list event
    #--------------------------------------------------------------------------
    def on_voice_list(self):
        global voice_list_changed

        voice_list_changed = True

    #--------------------------------------------------------------------------
    # Update the voices list in the combobox
    #--------------------------------------------------------------------------
    def update_voice_list(self):
        global voice_list
        global voice_dic
        global current_voice

        voice_dic = {}
        voice_list.clear()
        for voice_id in tux.tts.authorized_voices_list:
            voice_list.append([LANG_OF_SPK_LIST[voice_id],])
            voice_dic[LANG_OF_SPK_LIST[voice_id]] = voice_id + 1
        self.get_widget("comboboxentry1").set_model(voice_list)
        if voice_dic.has_key(current_voice):
            for i, voice_name in enumerate(voice_list):
                if voice_name[0] == current_voice:
                    self.get_widget("comboboxentry1").set_active(i)
                    break
        else:
            self.get_widget("comboboxentry1").set_active(0)


# -----------------------------------------------------------------------------
# Tab "Audio" events
# -----------------------------------------------------------------------------

    #--------------------------------------------------------------------------
    # On select external wave file event
    #--------------------------------------------------------------------------
    def on_wave_external_changed(self, widget, *args):
        filename=widget.get_filename()
        ext=len(filename)-filename.find(".wav")
        if ext != 4 :
            widget.unselect_filename(filename)

    #--------------------------------------------------------------------------
    # On "play" external wave file button clicked
    #--------------------------------------------------------------------------
    def on_wave_external_play_bt_clicked(self, widget, *args):
        if str(self.get_widget("filechooserbutton1").get_filename())=="None": return
        tux.sys.shell_free("aplay -D %s %s"% (soundcard,
        self.get_widget("filechooserbutton1").get_filename()))

    #--------------------------------------------------------------------------
    # On select original sounds
    #--------------------------------------------------------------------------
    def on_incl_orig_toggled(self, widget, *args):
        st_wav_paths = wavs.wav_paths
        if widget.get_active():
            wavs.wav_paths=[]
            wavs.wav_sizes=[]
            for i in range(17):
                wavs.add_wav_path('/opt/tuxdroid/apps/tuxgi/sounds/%d.wav'%(i+1))
            for path in st_wav_paths:
                wavs.add_wav_path(path)
        else:
            if len(st_wav_paths) > 17:
                for i in range(17):
                    wavs.wav_sizes.pop(0)
                    wavs.wav_paths.pop(0)
            else:
                wavs.wav_paths=[]
                wavs.wav_sizes=[]
        self.refresh_wav_list()

    #--------------------------------------------------------------------------
    # On select internal wave file event
    #--------------------------------------------------------------------------
    def on_wave_internal_changed(self, widget, *args):
        filename=widget.get_filename()
        ext=len(filename)-filename.find(".wav")
        if ext != 4 :
            widget.unselect_filename(filename)

    #--------------------------------------------------------------------------
    # On "add" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_add_bt_clicked(self, widget, *args):
        if str(self.get_widget("filechooserbutton2").get_filename())=="None": return
        wavs.add_wav_path(self.get_widget("filechooserbutton2").get_filename())
        self.refresh_wav_list()

    #--------------------------------------------------------------------------
    # On "remove" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_remove_bt_clicked(self, widget, *args):
        index=int(self.get_widget("spinbutton8").get_value())
        if index>len(wavs.wav_paths):return
        wavs.wav_sizes.pop(index-1)
        wavs.wav_paths.pop(index-1)
        self.refresh_wav_list()

    #--------------------------------------------------------------------------
    # Refreshing wave list function
    #--------------------------------------------------------------------------
    def refresh_wav_list(self):
        wav_te=self.get_widget("textview3")
        wav_buffer=wav_te.get_buffer()
        wav_buffer.set_text("")
        i=1
        for wavfile in wavs.wav_paths:
            filename=wavfile[wavfile.rfind('/')+1:]
            wav_buffer.insert(wav_buffer.get_end_iter(),"%.2d : %s\n" %(i,filename))
            i=i+1

    #--------------------------------------------------------------------------
    # On "clear" internal wave file list button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_clist_bt_clicked(self, widget, *args):
        wavs.wav_sizes=[]
        wavs.wav_paths=[]
        self.get_widget("checkbutton4").set_active(False)
        self.refresh_wav_list()

    #--------------------------------------------------------------------------
    # On "store" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_store_bt_clicked(self, widget, *args):
        thread.start_new_thread(self.sound_storing,())

    #--------------------------------------------------------------------------
    # Store sound function
    #--------------------------------------------------------------------------
    def sound_storing(self):
        if tux.status.rf_state() == 0: return
        if len(wavs.wav_sizes)==0: return
        wav_te=self.get_widget("textview3")
        wav_buffer=wav_te.get_buffer()
        if not wavs.wavs_merging("merged.wav"):
            print wav_buffer.insert(wav_buffer.get_end_iter(),
            "Sound storing : Error : file merged is too big\n")
            return
        wav_buffer.insert(wav_buffer.get_end_iter(),
        "Sound storing : Erase flash\n")
        tux.cmd.sound_storing(len(wavs.wav_sizes))
        tux.sys.wait(10)
        current_pos=0x0400
        tux.sys.wait(0.1)
        wav_buffer.insert(wav_buffer.get_end_iter(),
        "Sound storing : Indexes\n")
        tux.cmd.sound_store_index(0x00,0x04,0x00)
        for size in wavs.wav_sizes:
            current_pos=current_pos+size
            tux.sys.wait(0.1)
            tux.cmd.sound_store_index((current_pos & 0xFF0000)>>16,
            (current_pos & 0x00FF00)>>8,current_pos & 0x0000FF)
        wav_buffer.insert(wav_buffer.get_end_iter(),"Sound storing : Record\n")
        tux.sys.shell("aplay -D %s merged.wav"%soundcard)
        wav_buffer.insert(wav_buffer.get_end_iter(),
        "Sound storing : Storage done.\n")
        tux.sys.wait(0.3)

    #--------------------------------------------------------------------------
    # On "play" flash sound button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play_bt_clicked(self, widget, *args):
        def _funct():
            index=self.get_widget("spinbutton7").get_value()
            tux.cmd.sound_play(int(index),0)

        thread.start_new_thread(_funct,())

    #--------------------------------------------------------------------------
    # On "play flash sound number 1" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play1_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(1,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 2" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play2_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(2,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 3" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play3_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(3,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 4" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internat_play4_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(4,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 5" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play5_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(5,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 6" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play6_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(6,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 7" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play7_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(7,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 8" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play8_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(8,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 9" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play9_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(9,0,))

    #--------------------------------------------------------------------------
    # On "play flash sound number 10" button clicked
    #--------------------------------------------------------------------------
    def on_wave_internal_play10_clicked(self, widget, *args):
        thread.start_new_thread(tux.cmd.sound_play,(10,0,))

    #--------------------------------------------------------------------------
    # On "Play recorded wave file" button clicked
    #--------------------------------------------------------------------------
    def on_mic_play_bt_clicked(self, widget, *args):
        tux.sys.shell_free("aplay -D %s rec.wav"%soundcard)

    #--------------------------------------------------------------------------
    # On "Record wave file" button clicked
    #--------------------------------------------------------------------------
    def on_mic_record_bt_clicked(self, widget, *args):
        tux.cmd.mouth_open()
        tux.sys.shell("arecord -D %s -d 10 -t wav rec.wav"%soundcard)
        tux.cmd.mouth_close()

#==============================================================================
# Send command window class
#==============================================================================
class Window2(SimpleGladeApp):

    #--------------------------------------------------------------------------
    # Init class
    #--------------------------------------------------------------------------
    def __init__(self, path="tuxgi2.glade",
                 root="window2",
                 domain=app_name, **kwargs):
        path = os.path.join(glade_dir, path)
        SimpleGladeApp.__init__(self, path, root, domain, **kwargs)

    #--------------------------------------------------------------------------
    # On new window
    #--------------------------------------------------------------------------
    def new(self):
        print "A new %s has been created" % self.__class__.__name__

    #--------------------------------------------------------------------------
    # On window destroy
    #--------------------------------------------------------------------------
    def on_window2_destroy(self, widget, *args):
        print "closed"

    #--------------------------------------------------------------------------
    # On "Send command" button clicked
    #--------------------------------------------------------------------------
    def on_sendcommand_bt_clicked(self, widget, *args):
        commandst=self.get_widget("entry1").get_text()
        commands=commandst.split(" ")
        if len(commands)<4:
            return
        else:
            commandp=[0,0,0,0]
            for i in range(len(commands)):
                if commands[i].find("0x")!=-1:
                    commandp[i]=int(commands[i][2:],16)
                else:
                    commandp[i]=int(commands[i])
            tux.cmd.raw(int(commandp[0]),int(commandp[1]),int(commandp[2]),
            int(commandp[3]))


#------------------------------------------------------------------------------
# Main
#------------------------------------------------------------------------------
def main():
    g_tDI = Window1()
    gtk.gdk.threads_init()
    g_tDI.run()

if __name__ == "__main__":
    main()
