# -----------------------------------------------------------------------------
# Tux Droid - API Wav merger
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: tuxapi_wav_merger.py 156 2007-03-14 12:26:52Z remi $
# -----------------------------------------------------------------------------

import tuxapi_class

#==============================================================================
## Class for uploading TUX flash memory
#==============================================================================
class WavMerger(object):

    # -------------------------------------------------------------------------
    ## Constructor of object
    ## @param tux : TUXTCPCommunicator object
    # -------------------------------------------------------------------------
    def __init__(self,tux):
        self.wav_paths =[]
        self.wav_sizes =[]

    # -------------------------------------------------------------------------
    ## Add a wav path to wavs list
    ## @param path : Path of wav file
    # -------------------------------------------------------------------------
    def add_wav_path(self,path):
        self.wav_paths.append(path)
        self.add_wav_length(path)

    # -------------------------------------------------------------------------
    ## SYSTEM function
    # -------------------------------------------------------------------------
    def add_wav_length(self,path):
        f = open(path,'rb')
        wh = f.read(44)
        wav_length = (ord(wh[43]) * 256 ** 3) + (ord(wh[42]) * 256 ** 2) + \
                (ord(wh[41]) * 256 ** 1) + ord(wh[40])
        f.close()
        self.wav_sizes.append(wav_length)

    # -------------------------------------------------------------------------
    ## SYSTEM function
    # -------------------------------------------------------------------------
    def done_wavs_size(self):
        size = 0
        for w_size in self.wav_sizes:
            size = size+w_size
        return size

    # -------------------------------------------------------------------------
    ## Merge all the wav files contained in the wavs list
    ## @param path : Path of output wav file merged
    # -------------------------------------------------------------------------
    def wavs_merging(self,path):
        merged = open(path,'wb')
        whfile = open(self.wav_paths[0],'rb')
        header = whfile.read(40)
        whfile.close()
        merged.write(header)
        full_size = self.done_wavs_size() + int(self.done_wavs_size() * 0.07)
        if full_size>560000:
            print "Wavs selection exceded 70 seconds !"
            return False
        st = chr(full_size & 0x000000FF) + \
        chr((full_size & 0x0000FF00) >> 8) + \
        chr((full_size & 0x00FF0000)>>16) + \
        chr((full_size & 0xFF000000)>>24)
        merged.write(st)
        for i, pathw in enumerate(self.wav_paths):
            wwfile = open(pathw,'rb')
            wwfile.seek(44)
            stream = wwfile.read(self.wav_sizes[i])
            merged.write(stream)
            wwfile.close()
        while(merged.tell() < (full_size + 44) ):
            merged.write("            ")
        merged.close()
        return True
