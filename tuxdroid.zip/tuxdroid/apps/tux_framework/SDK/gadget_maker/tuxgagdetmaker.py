#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget Maker
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import subprocess
import time
import thread
import threading
import signal
import os
import sys
import shutil

import gtk

PATH_APP = os.path.realpath(os.path.dirname(sys.argv[0]))
PATH_LIBS = PATH_APP.replace('/SDK/gadget_maker', '')
TEMPLATE_PATH = PATH_APP + '/Template.tgf'
OTHERPYP_BASE = PATH_APP + '/otherpyp.base'
OTHERGLADE_BASE = PATH_APP + '/otherglade.base'
sys.path.append('%s/libs' % PATH_LIBS)

from SimpleGladeApp import SimpleGladeApp
from SimpleGladeApp import bindtextdomain

from GdgObject import TGFormat, GdgDialog, GdgDialogQuestion

import config

app_name = "tuxgagdetmaker"
app_version = "0.1.1"

glade_dir = ""
locale_dir = ""

bindtextdomain(app_name, locale_dir)

language_dict = {   'ar_ALL' : '<ar_ALL> Arabian',
                    'da_ALL' : '<da_ALL> Danish',
                    'nl_BE' : '<nl_BE> Dutch Belgian',
                    'nl_NL' : '<nl_NL> Dutch Netherland',
                    'en_GB' : '<en_GB> English Great Britain',
                    'en_US' : '<en_US> English United States',
                    'fr_ALL' : '<fr_ALL> French',
                    'de_ALL' : '<de_ALL> German',
                    'it_ALL' : '<it_ALL> Italian',
                    'no_ALL' : '<no_ALL> Norwegian',
                    'pt_ALL' : '<pt_ALL> Portuguese',
                    'es_ALL' : '<es_ALL> Spanish',
                    'sv_ALL' : '<sv_ALL> Swedish',}

class Window1(SimpleGladeApp):

    current_lang_country = 'en_US'
    last_icon = ''
    last_sound = ''
    last_codes_common = ''
    last_codes_lib = ''
    TGF_file = None

    def __init__(self, path="tuxgagdetmaker.glade",
                 root="window1",
                 domain=app_name, **kwargs):
        path = os.path.join(glade_dir, path)
        SimpleGladeApp.__init__(self, path, root, domain, **kwargs)

    def new(self):
        self.create_tree_views()
        self.make_filters()
        self.last_opened_file = ''
        self.get_widget("codes_editor_entry").set_text(config.editor)
        self.fw_process = None
        self.fw_process_mutex = threading.Lock()
        self.fw_loaded = False
        self.get_widget('stop1').set_sensitive(False)
        self.__last_button_press_time = 0

    def make_filters(self):
        # .py
        py_filter = gtk.FileFilter()
        py_filter.add_pattern("*.py")
        self.get_widget("codes_l_filechooserbutton").add_filter(py_filter)
        # .png
        png_filter = gtk.FileFilter()
        png_filter.add_pattern("*.png")
        self.get_widget("icons_filechooserbutton").add_filter(png_filter)
        # .wav
        wav_filter = gtk.FileFilter()
        wav_filter.add_pattern("*.wav")
        self.get_widget("sounds_filechooserbutton").add_filter(wav_filter)

    def on_window1_destroy(self, widget, *args):
        self.kill_gadget()
        self.close_gadget()
        sys.exit(0)

    def on_nouveau1_activate(self, widget, *args):
        if self.fw_process != None:
            GdgDialog('Tux Gadget Maker', 'Please stop the execution of the gadget before!')
            return
        # Make the file chooser
        f_c = gtk.FileChooserDialog('Select a TGF file ...',
            buttons = ( gtk.STOCK_CANCEL,
                        gtk.RESPONSE_CANCEL,
                        gtk.STOCK_SAVE_AS,
                        gtk.RESPONSE_OK))
        f_c.set_modal(True)
        f_c.set_action(gtk.FILE_CHOOSER_ACTION_SAVE)
        if self.last_opened_file != '':
            f_c.set_filename(self.last_opened_file)
        # Make the TGF filter
        tgf_filter = gtk.FileFilter()
        tgf_filter.add_pattern("*.tgf")
        f_c.set_filter(tgf_filter)
        # Show file chooser
        filename = ''
        if f_c.run() == gtk.RESPONSE_OK:
            filename = f_c.get_filename()
            if filename.lower().rfind('.tgf') == -1:
                filename = filename + '.tgf'
        f_c.destroy()
        if filename == '':
            return
        filename = filename.replace('%20', ' ')
        # Create the gadget and load it
        if not os.path.exists(filename):
            shutil.copy(TEMPLATE_PATH, filename)
            self.last_opened_file = filename
            self.load_gadget(filename)

    def on_ouvrir1_activate(self, widget, *args):
        if self.fw_process != None:
            GdgDialog('Tux Gadget Maker', 'Please stop the execution of the gadget before!')
            return
        # Make the file chooser
        f_c = gtk.FileChooserDialog('Select a TGF file ...',
            buttons = ( gtk.STOCK_CANCEL,
                        gtk.RESPONSE_CANCEL,
                        gtk.STOCK_OPEN,
                        gtk.RESPONSE_OK))
        f_c.set_modal(True)
        f_c.set_action(gtk.FILE_CHOOSER_ACTION_OPEN)
        if self.last_opened_file != '':
            f_c.set_filename(self.last_opened_file)
        # Make the TGF filter
        tgf_filter = gtk.FileFilter()
        tgf_filter.add_pattern("*.tgf")
        f_c.set_filter(tgf_filter)
        # Show file chooser
        filename = ''
        if f_c.run() == gtk.RESPONSE_OK:
            filename = f_c.get_filename()
        f_c.destroy()
        # Start the gadget
        if filename != '':
            filename = filename.replace('%20', ' ')
            self.last_opened_file = filename
            self.load_gadget(filename)

    def on_ouvrir2_activate(self, widget, *args):
        if self.fw_process != None:
            GdgDialog('Tux Gadget Maker', 'Please stop the execution of the gadget before!')
            return
        # Make the file chooser
        f_c = gtk.FileChooserDialog('Select a TGF directory ...',
            buttons = ( gtk.STOCK_CANCEL,
                        gtk.RESPONSE_CANCEL,
                        gtk.STOCK_OPEN,
                        gtk.RESPONSE_OK))
        f_c.set_modal(True)
        f_c.set_action(gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER)
        if self.last_opened_file != '':
            f_c.set_filename(self.last_opened_file)
        # Show file chooser
        filename = ''
        if f_c.run() == gtk.RESPONSE_OK:
            filename = f_c.get_filename()
        f_c.destroy()
        # Start the gadget
        if filename != '':
            filename = filename.replace('%20', ' ')
            self.last_opened_file = filename
            self.load_gadget(filename)

    def on_enregistrer1_activate(self, widget, *args):
        self.save_gadget()

    def on_enregistrer2_activate(self, widget, *args):
        self.save_gadget_dir()
        
    def on_recharger1_activate(self, widget, *args):
        self.reload_gadget()

    def on_execute1_activate(self, widget, *args):
        self.execute_gadget()

    def on_stop1_activate(self, widget, *args):
        self.kill_gadget()

    def on_quitter1_activate(self, widget, *args):
        if self.fw_process != None:
            GdgDialog('Tux Gadget Maker', 'Please stop the execution of the gadget before!')
            return
        self.get_widget("window1").destroy()

    def on_about1_activate(self, widget, *args):
        GdgDialog('Tux Gadget Maker', 'Tux Gadget Maker V%s\n\n(C) 2007 C2ME Sa\nremi.jocaille@c2me.be' %app_version, False, True)

    def on_about_modify_button_clicked(self, widget, *args):
        name = self.get_widget("about_name_entry").get_text()
        self.TGF_file.parser.about.set_name(name)
        author = self.get_widget("about_author_entry").get_text()
        self.TGF_file.parser.about.set_author(author)
        version = self.get_widget("about_version_entry").get_text()
        self.TGF_file.parser.about.set_version(version)
        buff = self.get_widget("about_description_textview").get_buffer()
        description = buff.get_text(*buff.get_bounds())
        self.TGF_file.parser.about.set_description(description)

    def on_general_modify_button_clicked(self, widget, *args):
        name = self.get_widget("general_name_entry").get_text()
        if name == "":
            return
        value = self.get_widget("general_value_entry").get_text()
        value = self.__interpret_value(value)
        if name in self.TGF_file.parser.settings.get_generals_list():
            self.TGF_file.parser.settings.set_general_value(name, value)
            self.load_general_settings()

    def on_params_delete_button_clicked(self, widget, *args):
        def on_yes_action():
            name = self.get_widget("params_name_entry").get_text()
            if name in self.TGF_file.parser.settings.get_parameters_list():
                self.TGF_file.parser.settings.delete_parameter(name)
                self.load_params_settings()
        if self.get_widget("params_name_entry").get_text() == "":
            return
        GdgDialogQuestion('Tux Gadget Maker', 'This action will definitively remove this parameter ! Continue ?', on_yes_action)

    def on_params_add_button_clicked(self, widget, *args):
        name = self.get_widget("params_name_entry").get_text()
        if name == "":
            return
        value = self.get_widget("params_value_entry").get_text()
        value = self.__interpret_value(value)
        if not name in self.TGF_file.parser.settings.get_parameters_list():
            self.TGF_file.parser.settings.add_parameter(name, value)
            self.load_params_settings()

    def on_params_modify_button_clicked(self, widget, *args):
        name = self.get_widget("params_name_entry").get_text()
        if name == "":
            return
        value = self.get_widget("params_value_entry").get_text()
        value = self.__interpret_value(value)
        if name in self.TGF_file.parser.settings.get_parameters_list():
            self.TGF_file.parser.settings.set_parameter_value(name, value)
            self.load_params_settings()

    def on_strings_lg_add_button_clicked(self, widget, *args):
        if self.TGF_file == None:
            return
        model = self.get_widget("strings_lang_comboboxentry").get_model()
        i = self.get_widget("strings_lang_comboboxentry").get_active()
        lang = model[i][0]
        idxb = lang.find('<') + 1
        idxe = lang.find('>')
        lang_country = lang[idxb:idxe]
        if not lang_country in self.TGF_file.parser.i18n.get_languages_list():
            self.TGF_file.parser.i18n.add_language(lang_country)
            self.load_languages_strings()

    def on_strings_lg_delete_button_clicked(self, widget, *args):
        def on_yes_action():
            model = self.get_widget("strings_lang_comboboxentry").get_model()
            i = self.get_widget("strings_lang_comboboxentry").get_active()
            lang = model[i][0]
            idxb = lang.find('<') + 1
            idxe = lang.find('>')
            lang_country = lang[idxb:idxe]
            if lang_country in self.TGF_file.parser.i18n.get_languages_list():
                if lang_country != 'en_US':
                    self.TGF_file.parser.i18n.delete_language(lang_country)
                    self.load_languages_strings()
        if self.TGF_file == None:
            return     
        GdgDialogQuestion('Tux Gadget Maker', 'This action will definitively remove this language ! Continue ?', on_yes_action)

    def to_legal_string(self, message):
        if len(message) < 2:
            message = '"%s"' % message
        elif (message[0] != "[") or (message[len(message)-1] != "]"):
            message = '"%s"' % message
        message = message.replace(chr(10), '\\n')
        return message

    def on_strings_st_modify_button_clicked(self, widget, *args):
        name = self.get_widget("strings_st_name_entry").get_text()
        if name == "":
            return
        value_buff = self.get_widget("strings_st_value_tw").get_buffer()
        value = value_buff.get_text(*value_buff.get_bounds())
        value = self.to_legal_string(value)
        value = self.__interpret_value(value)
        if name in self.TGF_file.parser.i18n.get_messages_list():
            self.TGF_file.parser.i18n.set_message_value(    name,
                        value,
                        self.current_lang_country)
            self.load_message_strings(self.current_lang_country)

    def on_strings_st_delete_button_clicked(self, widget, *args):
        def on_yes_action():
            name = self.get_widget("strings_st_name_entry").get_text()
            if name in self.TGF_file.parser.i18n.get_messages_list():
                self.TGF_file.parser.i18n.delete_message(name)
                self.load_message_strings(self.current_lang_country)
        if self.get_widget("strings_st_name_entry").get_text() == "":
            return   
        GdgDialogQuestion('Tux Gadget Maker', 'This action will definitively remove this message ! Continue ?', on_yes_action)

    def on_strings_st_add_button_clicked(self, widget, *args):
        name = self.get_widget("strings_st_name_entry").get_text()
        if name == "":
            return
        value_buff = self.get_widget("strings_st_value_tw").get_buffer()
        value = value_buff.get_text(*value_buff.get_bounds())
        value = self.to_legal_string(value)
        value = self.__interpret_value(value)
        if not name in self.TGF_file.parser.i18n.get_messages_list():
            self.TGF_file.parser.i18n.add_message(name, value)
            self.load_message_strings(self.current_lang_country)

    def on_gui_add_button_clicked(self, widget, *args):
        name = self.get_widget("gui_name_entry").get_text()
        if name == '':
            return
        if self.TGF_file == None:
            return
        if self.TGF_file.parser.GUI.struct.has_key(name):
            return
        # Create new directory
        new_gui_path = self.TGF_file.parser.tgf_path + '/Scripts/Python/GUI/' + name
        os.makedirs(new_gui_path, 511)
        # Copy glade base
        src = OTHERGLADE_BASE
        dest = new_gui_path + "/other.glade"
        shutil.copy(src, dest)
        # Copy pyp base
        src = OTHERPYP_BASE
        dest = new_gui_path + "/other.pyp"
        f = open(src, 'r')
        src_str = f.read()
        f.close()
        src_str = src_str.replace("0123456789", name)
        f = open(dest, 'w')
        f.write(src_str)
        f.close()
        # reload guis
        self.reload_gadget()

    def on_gui_delete_button_clicked(self, widget, *args):
        def on_yes_action():
            name = self.get_widget("gui_name_entry").get_text()
            gui_path = self.TGF_file.parser.tgf_path + '/Scripts/Python/GUI/' + name
            os.system("rm -fR '%s'" % gui_path)
            self.reload_gadget()
            
        name = self.get_widget("gui_name_entry").get_text()
        if name in ['', 'widget', 'conf']:
            return
        if self.TGF_file == None:
            return
        if not self.TGF_file.parser.GUI.struct.has_key(name):
            return     
        GdgDialogQuestion('Tux Gadget Maker', 'This action will definitively remove this GUI ! Continue ?', on_yes_action)
        
    def on_gui_auto_label_clicked(self, widget, *args):
        append_lst = []
        remove_lst = []
        code_str = ""
    
        def updates_messages():
            gtk.gdk.threads_enter()
            for message in append_lst:
                self.insert_new_string(message[0], message[1])
            for name in remove_lst:
                self.delete_string(name)
            gtk.gdk.threads_leave()
        
        gui_name = self.get_widget("gui_name_entry").get_text()
        if gui_name == "":
            return
        if gui_name != '':
            full_path = self.TGF_file.parser.tgf_path + '/Scripts/Python/GUI' + '/' + gui_name + '/other.glade'
            glade_gui = gtk.glade.XML(full_path)
            inter = []
            for wdg in glade_gui.get_widget_prefix(""):
                path = wdg.class_path()
                widget_type = path[path.rfind('.')+1:]
                if widget_type == 'GtkLabel':
                    inter.append([wdg.get_name(), wdg.get_text(), wdg, widget_type])
                if widget_type == 'GtkButton':
                    tmp = wdg.get_label()
                    if tmp != None:
                        inter.append([wdg.get_name(), wdg.get_label(), wdg, widget_type])
                if widget_type in['GtkImageMenuItem', 'GtkMenuItem', 'GtkCheckMenuItem', 'GtkCheckButton', 'GtkRadioButton']:
                    al = wdg.get_child()
                    inter.append([wdg.get_name(), al.get_text(), wdg, widget_type])
            glade_gui.get_widget('window1').destroy()
            # Create list of messages
            add_remove_flag = False
            message_message_str = ""
            trad_lst = []
            msg_lst = []
            for element in inter:
                str_name = "at_gui_%s_%s" % (gui_name, element[0])
                msg_lst.append(str_name)
                str_value = element[1]
                trad_lst.append([str_name, str_value, element[0], element[3]])
            # Find the messages to remove
            remove_lst = []
            prefix = "at_gui_%s" % (gui_name)
            for message_name in self.TGF_file.parser.i18n.get_messages_list():
                if message_name.find(prefix) == 0:
                    if message_name not in msg_lst:
                        remove_lst.append(message_name)
            if len(remove_lst) > 0:
                add_remove_flag = True
                message_message_str += "Messages list to remove:\n"
                for name in remove_lst:
                    message_message_str += "    %s\n" % name
            # Find the new messages
            append_lst = []
            messages_lst = self.TGF_file.parser.i18n.get_messages_list()
            for message in trad_lst:
                if not message[0] in messages_lst:
                    append_lst.append([message[0], message[1]])
            if len(append_lst) > 0:
                add_remove_flag = True
                message_message_str += "Messages list to insert:\n"
                for message in append_lst:
                    message_message_str += "    %s\n" % message[0]
            if add_remove_flag:
                GdgDialogQuestion('Apply these changes ?', message_message_str, updates_messages, True)

    def on_icons_filechooserbutton_selection_changed(self, widget, *args):
        filename = widget.get_filename()
        if self.TGF_file == None:
            return 
        self.TGF_file.parser.icons.insert(filename)
        self.load_guis_icons()

    def on_icons_delete_button_clicked(self, widget, *args):
        def on_yes_action():
            self.TGF_file.parser.icons.remove(self.last_icon)
            self.load_guis_icons()
        if self.TGF_file == None:
            return
        GdgDialogQuestion('Tux Gadget Maker', 'This action will definitively remove this icon ! Continue ?', on_yes_action)

    def on_sounds_filechooserbutton_update_preview(self, widget, *args):
        filename = widget.get_filename()
        if self.TGF_file == None:
            return
        self.TGF_file.parser.sounds.insert(filename)
        self.load_guis_sounds()

    def on_sounds_delete_button_clicked(self, widget, *args):
        def on_yes_action():
            self.TGF_file.parser.sounds.remove(self.last_sound)
            self.load_guis_sounds()
        if self.TGF_file == None:
            return 
        GdgDialogQuestion('Tux Gadget Maker', 'This action will definitively remove this sound ! Continue ?', on_yes_action)

    def on_codes_c_edit_button_clicked(self, widget, *args):
        if self.TGF_file == None:
            return
        my_path = "'%s'" % (self.TGF_file.parser.tgf_path + self.last_codes_common)
        edit = self.get_widget("codes_editor_entry").get_text()
        cmd = edit % my_path
        thread.start_new_thread(os.system,(cmd,))
            
    def on_codes_c_edit_all_button_clicked(self, widget, *args):
        if self.TGF_file == None:
            return
        if len(self.codes_commons_ls) == 0:
            return
        my_path = ""
        for path in self.codes_commons_ls:
            my_path += " '%s%s'" % (self.TGF_file.parser.tgf_path, path[0])
        edit = self.get_widget("codes_editor_entry").get_text()
        cmd = edit % my_path
        thread.start_new_thread(os.system,(cmd,))

    def on_codes_l_filechooserbutton_selection_changed(self, widget, *args):
        if self.TGF_file == None:
            return
        filename = widget.get_filename()
        self.TGF_file.parser.libs.insert(filename)
        self.load_codes_libs()

    def on_codes_l_delete_button_clicked(self, widget, *args):
        def on_yes_action():
            self.TGF_file.parser.libs.remove(self.last_codes_lib)
            self.load_codes_libs()
        if self.TGF_file == None:
            return
        GdgDialogQuestion('Tux Gadget Maker', 'This action will definitively remove this library ! Continue ?', on_yes_action)

    def on_codes_l_edit_button_clicked(self, widget, *args):
        if self.TGF_file == None:
            return
        my_path = "'%s'" % (self.TGF_file.parser.tgf_path + '/Scripts/Python/' + self.last_codes_lib)
        edit = self.get_widget("codes_editor_entry").get_text()
        cmd = edit % my_path
        thread.start_new_thread(os.system,(cmd,))
            
    def on_vr_delete_button_clicked(self, widget, *args):
        def on_yes_action():
            name = self.get_widget("vr_word_entry").get_text()
            if "vr_%s" % name in self.TGF_file.parser.i18n.get_messages_list():
                self.remove_from_dictionary(name)
                self.delete_word_string(name)
                self.load_dictionary()
        if self.TGF_file == None:
            return
        GdgDialogQuestion('Tux Gadget Maker', 'This action will definitively remove this word ! Continue ?', on_yes_action)

    def on_vr_add_button_clicked(self, widget, *args):
        name = self.get_widget("vr_word_entry").get_text()
        if name == "":
            return
        if self.TGF_file == None:
            return
        if not "vr_%s" % name in self.TGF_file.parser.i18n.get_messages_list():
            self.insert_in_dictionary(name)
            self.insert_word_string(name)
            self.load_dictionary()
            
    def on_entry1_changed(self, widget, *args):
        if self.TGF_file != None:
            self.load_message_strings(self.current_lang_country)

    def create_tree_views(self):
        """
        Create the tree viewers
        """
        # Settings - general
        name_column = gtk.TreeViewColumn('Name')
        name_column.set_min_width(200)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        value_column = gtk.TreeViewColumn('Value')
        value_column.set_min_width(200)
        value_cell = gtk.CellRendererText()
        value_column.pack_start(value_cell, True)
        value_column.add_attribute(value_cell, 'text', 1)
        self.settings_general_ls = gtk.ListStore(str, str)
        self.settings_general = gtk.TreeView(self.settings_general_ls)
        self.settings_general.append_column(name_column)
        self.settings_general.append_column(value_column)
        self.settings_general.set_reorderable(True)
        self.get_widget("scrolledwindow1").add(self.settings_general)
        self.get_widget("scrolledwindow1").show_all()
        self.settings_general.get_selection().connect("changed", self.on_settings_general_select)
        # Settings - parameters
        name_column = gtk.TreeViewColumn('Name')
        name_column.set_min_width(200)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        value_column = gtk.TreeViewColumn('Value')
        value_column.set_min_width(200)
        value_cell = gtk.CellRendererText()
        value_column.pack_start(value_cell, True)
        value_column.add_attribute(value_cell, 'text', 1)
        self.settings_params_ls = gtk.ListStore(str, str)
        self.settings_params = gtk.TreeView(self.settings_params_ls)
        self.settings_params.append_column(name_column)
        self.settings_params.append_column(value_column)
        self.settings_params.set_reorderable(True)
        self.get_widget("scrolledwindow2").add(self.settings_params)
        self.get_widget("scrolledwindow2").show_all()
        self.settings_params.get_selection().connect("changed", self.on_settings_params_select)
        # Strings - language
        name_column = gtk.TreeViewColumn('Language')
        name_column.set_min_width(400)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        self.strings_lg_ls = gtk.ListStore(str)
        self.strings_lg = gtk.TreeView(self.strings_lg_ls)
        self.strings_lg.append_column(name_column)
        self.strings_lg.set_reorderable(True)
        self.get_widget("scrolledwindow4").add(self.strings_lg)
        self.get_widget("scrolledwindow4").show_all()
        # Strings - strings
        name_column = gtk.TreeViewColumn('Name')
        name_column.set_min_width(200)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        value_column = gtk.TreeViewColumn('Value')
        value_column.set_min_width(200)
        value_cell = gtk.CellRendererText()
        value_column.pack_start(value_cell, True)
        value_column.add_attribute(value_cell, 'text', 1)
        self.strings_st_ls = gtk.ListStore(str, str)
        self.strings_st = gtk.TreeView(self.strings_st_ls)
        self.strings_st.append_column(name_column)
        self.strings_st.append_column(value_column)
        self.strings_st.set_reorderable(True)
        self.get_widget("scrolledwindow5").add(self.strings_st)
        self.get_widget("scrolledwindow5").show_all()
        self.strings_lg.get_selection().connect("changed", self.on_lang_viewer_select)
        self.strings_st.get_selection().connect("changed", self.on_messages_viewer_select)
        # GUIs - GUI
        name_column = gtk.TreeViewColumn('Name')
        name_column.set_min_width(400)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        self.guis_gui_ls = gtk.ListStore(str)
        self.guis_gui = gtk.TreeView(self.guis_gui_ls)
        self.guis_gui.append_column(name_column)
        self.guis_gui.set_reorderable(True)
        self.get_widget("scrolledwindow6").add(self.guis_gui)
        self.get_widget("scrolledwindow6").show_all()
        self.guis_gui.get_selection().connect("changed", self.on_guis_gui_select)
        self.guis_gui.connect("button_press_event", self.on_guis_gui_button_pressed)
        # GUIs - Icons
        name_column = gtk.TreeViewColumn('Name')
        name_column.set_min_width(400)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        self.guis_icons_ls = gtk.ListStore(str)
        self.guis_icons = gtk.TreeView(self.guis_icons_ls)
        self.guis_icons.append_column(name_column)
        self.guis_icons.set_reorderable(True)
        self.get_widget("scrolledwindow7").add(self.guis_icons)
        self.get_widget("scrolledwindow7").show_all()
        self.guis_icons.get_selection().connect("changed", self.on_guis_icons_select)
        # GUIs - Sounds
        name_column = gtk.TreeViewColumn('Name')
        name_column.set_min_width(400)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        self.guis_sounds_ls = gtk.ListStore(str)
        self.guis_sounds = gtk.TreeView(self.guis_sounds_ls)
        self.guis_sounds.append_column(name_column)
        self.guis_sounds.set_reorderable(True)
        self.get_widget("scrolledwindow8").add(self.guis_sounds)
        self.get_widget("scrolledwindow8").show_all()
        self.guis_sounds.get_selection().connect("changed", self.on_guis_sounds_select)
        # Codes - commons
        name_column = gtk.TreeViewColumn('Name')
        name_column.set_min_width(400)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        self.codes_commons_ls = gtk.ListStore(str)
        self.codes_commons = gtk.TreeView(self.codes_commons_ls)
        self.codes_commons.append_column(name_column)
        self.codes_commons.set_reorderable(True)
        self.get_widget("scrolledwindow9").add(self.codes_commons)
        self.get_widget("scrolledwindow9").show_all()
        self.codes_commons.get_selection().connect("changed", self.on_codes_commons_select)
        self.codes_commons.connect("button_press_event", self.on_codes_commons_pressed)
        # Codes - libs
        name_column = gtk.TreeViewColumn('Name')
        name_column.set_min_width(400)
        name_cell = gtk.CellRendererText()
        name_column.pack_start(name_cell, True)
        name_column.add_attribute(name_cell, 'text', 0)
        self.codes_libs_ls = gtk.ListStore(str)
        self.codes_libs = gtk.TreeView(self.codes_libs_ls)
        self.codes_libs.append_column(name_column)
        self.codes_libs.set_reorderable(True)
        self.get_widget("scrolledwindow10").add(self.codes_libs)
        self.get_widget("scrolledwindow10").show_all()
        self.codes_libs.get_selection().connect("changed", self.on_codes_libs_select)
        self.codes_libs.connect("button_press_event", self.on_codes_libs_pressed)
        # Dictionary
        word_column = gtk.TreeViewColumn('Word')
        word_cell = gtk.CellRendererText()
        word_column.pack_start(word_cell, True)
        word_column.add_attribute(word_cell, 'text', 0)
        self.word_ls = gtk.ListStore(str)
        self.word = gtk.TreeView(self.word_ls)
        self.word.append_column(word_column)
        self.word.set_reorderable(True)
        self.get_widget("scrolledwindow12").add(self.word)
        self.get_widget("scrolledwindow12").show_all()
        self.word.get_selection().connect("changed", self.on_word_select)

    def load_gadget(self, path):
        """
        Load a gadget
        """
        self.__last_button_press_time = 0
        self.close_gadget()
        self.TGF_file = TGFormat()
        self.TGF_file.open(path, 'a', True)
        #self.TGF_file.parser.build_documentation('./doc/TGFParser.html', self.TGF_file.parser,
        #    'parser', self.TGF_file.parser.version)
        # Load about
        name = self.TGF_file.parser.about.get_name()
        self.get_widget("about_name_entry").set_text(name)
        author = self.TGF_file.parser.about.get_author()
        self.get_widget("about_author_entry").set_text(author)
        version = self.TGF_file.parser.about.get_version()
        self.get_widget("about_version_entry").set_text(version)
        description = self.TGF_file.parser.about.get_description()
        buff = self.get_widget("about_description_textview").get_buffer()
        buff.set_text(description)
        # Load settings general
        self.load_general_settings()
        # Load settings parameters
        self.load_params_settings()
        # Load languages
        self.load_languages_strings()
        # Load GUIs gui
        self.load_guis_gui()
        # Load GUIs icons
        self.load_guis_icons()
        # Load GUIs sounds
        self.load_guis_sounds()
        # Load codes commons
        self.load_codes_commons()
        # Load codes libs
        self.load_codes_libs()
        # Load dictionary
        self.load_dictionary()

    def on_lang_viewer_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            lang = self.strings_lg_ls[path][0]
            model = self.get_widget("strings_lang_comboboxentry").get_model()
            for i, lang_f in enumerate(model):
                if lang_f[0] == lang:
                    self.get_widget("strings_lang_comboboxentry").set_active(i)
            idxb = lang.find('<') + 1
            idxe = lang.find('>')
            lang_country = lang[idxb:idxe]
            self.load_message_strings(lang_country)

    def on_messages_viewer_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            message_name = self.strings_st_ls[path][0]
            message_value = self.strings_st_ls[path][1]
            if message_value[0] in ["'", '"']:
                message_value = message_value[1:]
            if message_value[len(message_value)-1] in ["'", '"']:
                message_value = message_value[:-1]
            self.get_widget("strings_st_name_entry").set_text(message_name)
            value_buff = self.get_widget("strings_st_value_tw").get_buffer()
            value_buff.set_text(message_value)

    def on_settings_general_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            name = self.settings_general_ls[path][0]
            value = self.settings_general_ls[path][1]
            self.get_widget("general_name_entry").set_text(name)
            self.get_widget("general_value_entry").set_text(value)

    def on_settings_params_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            name = self.settings_params_ls[path][0]
            value = self.settings_params_ls[path][1]
            self.get_widget("params_name_entry").set_text(name)
            self.get_widget("params_value_entry").set_text(value)

    def on_guis_gui_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            name = self.guis_gui_ls[path][0]
            self.get_widget("gui_name_entry").set_text(name)
            
    def on_guis_gui_button_pressed(self, widget, event):
        if event.button == 1:
            if self.__last_button_press_time == event.time:
                gui_name = self.get_widget("gui_name_entry").get_text()
                if gui_name != '':
                    full_path = self.TGF_file.parser.tgf_path + '/Scripts/Python/GUI' + '/' + gui_name + '/other.glade'
                    thread.start_new_thread(os.system, ("glade-2 '%s'" % full_path,))
        self.__last_button_press_time = event.time

    def on_guis_icons_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            name = self.guis_icons_ls[path][0]
            self.last_icon = name
            if name != "":
                ico_path = self.TGF_file.parser.icons.struct[name]
                img = gtk.gdk.pixbuf_new_from_file(ico_path)
                self.get_widget("ico_image").set_from_pixbuf(img)

    def on_guis_sounds_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            name = self.guis_sounds_ls[path][0]
            self.last_sound = name

    def on_codes_commons_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            name = self.codes_commons_ls[path][0]
            self.last_codes_common = name
            
    def on_codes_commons_pressed(self, widget, event):
        if event.button == 1:
            if self.__last_button_press_time == event.time:
                if self.last_codes_common != '':
                    self.on_codes_c_edit_button_clicked(None)
        self.__last_button_press_time = event.time

    def on_codes_libs_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            name = self.codes_libs_ls[path][0]
            self.last_codes_lib = name
            
    def on_codes_libs_pressed(self, widget, event):
        if event.button == 1:
            if self.__last_button_press_time == event.time:
                if self.last_codes_lib != '':
                    self.on_codes_l_edit_button_clicked(None)
        self.__last_button_press_time = event.time
            
    def on_word_select(self, obj):
        path = obj.get_selected_rows()
        if len(path[1]) > 0:
            path = path[1][0][0]
            name = self.word_ls[path][0]
            self.get_widget("vr_word_entry").set_text(name)
            self.get_widget("vr_word_name_entry").set_text("vr_%s" % name)

    def load_general_settings(self):
        general_lst = self.TGF_file.parser.settings.get_generals_list()
        self.settings_general_ls.clear()
        
        sorted_list = []
        for general in general_lst:
            sorted_list.append(general)
        sorted_list.sort()
        for general in sorted_list:
            name = general
            value = self.TGF_file.parser.settings.get_general_value(general)
            if str(type(value)) == "<type 'str'>":
                value = '"%s"' % value
            self.settings_general_ls.append([name, value])

    def load_params_settings(self):
        parameters_lst = self.TGF_file.parser.settings.get_parameters_list()
        self.settings_params_ls.clear()
        sorted_list = []
        for parameter in parameters_lst:
            sorted_list.append(parameter)
        sorted_list.sort()
        for parameter in sorted_list:
            name = parameter
            value = self.TGF_file.parser.settings.get_parameter_value(parameter)
            if str(type(value)) == "<type 'str'>":
                value = '"%s"' % value
            self.settings_params_ls.append([name, value])

    def load_languages_strings(self):
        lang_lst = self.TGF_file.parser.i18n.get_languages_list()
        self.strings_lg_ls.clear()
        for lang in lang_lst:
            name = language_dict[lang]
            self.strings_lg_ls.append([name,])
        self.get_widget("strings_lang_comboboxentry").set_active(5)
        self.load_message_strings('en_US')

    def load_message_strings(self, lang_country):
        msg_filter = self.get_widget("entry1").get_text()
        msg_lst = self.TGF_file.parser.i18n.get_messages_list()
        self.strings_st_ls.clear()
        self.current_lang_country = lang_country
        sorted_list = []
        for msg in msg_lst:
            sorted_list.append(msg)
        sorted_list.sort()
        for msg in sorted_list:
            name = msg
            if msg_filter != "":
                if name.find(msg_filter) != 0:
                    continue
            value = self.TGF_file.parser.i18n.get_message_value_dict(name)[lang_country]
            if str(type(value)) == "<type 'str'>":
                value = '"%s"' % value
            self.strings_st_ls.append([name, value])

    def load_guis_gui(self):
        gui_path = self.TGF_file.parser.tgf_path + '/Scripts/Python/GUI'
        self.guis_gui_ls.clear()
        if os.path.exists(gui_path):
            gui_lst = os.listdir(gui_path)
            for gui_path in gui_lst:
                self.guis_gui_ls.append([gui_path,])

    def load_guis_icons(self):
        gui_path = self.TGF_file.parser.tgf_path + '/Pictures/Icons'
        self.guis_icons_ls.clear()
        if os.path.exists(gui_path):
            gui_lst = os.listdir(gui_path)
            for gui_path in gui_lst:
                self.guis_icons_ls.append([gui_path,])

    def load_guis_sounds(self):
        sounds_path = self.TGF_file.parser.tgf_path + '/Sounds'
        self.guis_sounds_ls.clear()
        if os.path.exists(sounds_path):
            sounds_lst = os.listdir(sounds_path)
            for sound_path in sounds_lst:
                self.guis_sounds_ls.append([sound_path,])

    def load_codes_commons(self):
        self.codes_commons_ls.clear()
        self.codes_commons_ls.append(['/Scripts/Python/main.pyp'])
        self.codes_commons_ls.append(['/Scripts/Python/notify.pyp'])
        self.codes_commons_ls.append(['/Scripts/Python/init.pyp'])
        for entry in self.guis_gui_ls:
            gui_path = '/Scripts/Python/GUI/%s/other.pyp' % entry[0]
            self.codes_commons_ls.append([gui_path])

    def load_codes_libs(self):
        libs_path = self.TGF_file.parser.tgf_path + '/Scripts/Python'
        self.codes_libs_ls.clear()
        if os.path.exists(libs_path):
            libs_lst = os.listdir(libs_path)
            for lib_path in libs_lst:
                if lib_path.lower().find('.py') != -1:
                    if lib_path.lower().find('.pyp') == -1:
                        self.codes_libs_ls.append([lib_path])
                        
    def insert_word_string(self, word):
        name = "vr_%s" % word
        value = self.to_legal_string(word)
        value = self.__interpret_value(value)
        if not name in self.TGF_file.parser.i18n.get_messages_list():
            self.TGF_file.parser.i18n.add_message(name, value)
            self.load_message_strings(self.current_lang_country)
            
    def insert_new_string(self, name, value):
        if not name in self.TGF_file.parser.i18n.get_messages_list():
            self.TGF_file.parser.i18n.add_message(name, value)
            self.load_message_strings(self.current_lang_country)
            
    def delete_string(self, name):
        if name in self.TGF_file.parser.i18n.get_messages_list():
            self.TGF_file.parser.i18n.delete_message(name)
            self.load_message_strings(self.current_lang_country)
            
    def delete_word_string(self, word):
        name = "vr_%s" % word
        if name in self.TGF_file.parser.i18n.get_messages_list():
            self.TGF_file.parser.i18n.delete_message(name)
            self.load_message_strings(self.current_lang_country)
                        
    def load_dictionary(self):
        dict_path = self.TGF_file.parser.tgf_path + '/Data/rc_dict'
        self.word_ls.clear()
        if os.path.isfile(dict_path):
            f = open(dict_path, 'r')
            st = f.read()
            f.close()
            global words
            words = []
            exec str(st) in globals()
            for word in words:
                self.word_ls.append([word[0]])
                self.insert_word_string(word[0])
                
    def insert_in_dictionary(self, new_word):
        dict_path = self.TGF_file.parser.tgf_path + '/Data/rc_dict'
        global words
        words = []
        if os.path.isfile(dict_path):
            f = open(dict_path, 'r')
            st = f.read()
            f.close()
            exec str(st) in globals()
        b = False
        for word in words:
            if word[0] == new_word:
                b = True
                break
        if not b:
            words.append([new_word, []])
        st = 'words=%s' % str(words)
        f = open(dict_path, 'w')
        f.write(st)
        f.close()
        
    def remove_from_dictionary(self, new_word):
        dict_path = self.TGF_file.parser.tgf_path + '/Data/rc_dict'
        global words
        words = []
        if os.path.isfile(dict_path):
            f = open(dict_path, 'r')
            st = f.read()
            f.close()
            exec str(st) in globals()
        for i, word in enumerate(words):
            if word[0] == new_word:
                words.pop(i)
                break
        st = 'words=%s' % str(words)
        f = open(dict_path, 'w')
        f.write(st)
        f.close()

    def close_gadget(self):
        if self.fw_process != None:
            GdgDialog('Tux Gadget Maker', 'Please stop the execution of the gadget before!')
            return
        if self.TGF_file != None:
            self.TGF_file.mode = 'r'
            self.TGF_file.close()

    def save_gadget(self):
        if self.fw_process != None:
            GdgDialog('Tux Gadget Maker', 'Please stop the execution of the gadget before!')
            return
        if self.TGF_file != None:
            self.on_about_modify_button_clicked(None)
            tgf_path = self.TGF_file.c_path
            self.TGF_file.mode = 'a'
            self.TGF_file.close(True)

    def save_gadget_dir(self):
        if self.fw_process != None:
            GdgDialog('Tux Gadget Maker', 'Please stop the execution of the gadget before!')
            return
        if self.TGF_file != None:
            self.on_about_modify_button_clicked(None)
            tgf_path = self.TGF_file.d_path
            self.TGF_file.mode = 'a'
            self.TGF_file.close(True)
            
    def reload_gadget(self):
        if self.fw_process != None:
            GdgDialog('Tux Gadget Maker', 'Please stop the execution of the gadget before!')
            return
        if self.TGF_file != None:
            tgf_path = self.TGF_file.c_path
            self.save_gadget()
            self.load_gadget(tgf_path)

    def execute_gadget(self):
        if self.fw_process != None:
            return
        def check_fw_active():
            while True:
                try:
                    poll_res = self.fw_process.poll()
                    if poll_res != None:
                        break
                except:
                    break
                time.sleep(0.1)
            self.get_widget('execute1').set_sensitive(True)
            self.get_widget('stop1').set_sensitive(False)
            self.fw_process_mutex.acquire()
            self.fw_process = None
            self.fw_process_mutex.release()

        if self.TGF_file != None:
            self.save_gadget()
            tgf_path = self.TGF_file.c_path
            cmd = ["/opt/tuxdroid/apps/tux_framework/TFW.py", tgf_path]
            self.fw_process = subprocess.Popen(cmd)
            self.fw_loaded = True
            self.get_widget('execute1').set_sensitive(False)
            self.get_widget('stop1').set_sensitive(True)
            thread.start_new_thread(check_fw_active, ())

    def kill_gadget(self):
        self.fw_process_mutex.acquire()
        auth = self.fw_process
        self.fw_process_mutex.release()
        if auth != None:
            try:
                os.kill(self.fw_process.pid, signal.SIGKILL)
                os.waitpid(-1, os.WNOHANG)
                time.sleep(0.5)
                self.get_widget('execute1').set_sensitive(True)
                self.get_widget('stop1').set_sensitive(False)
                self.fw_process = None
            except:
                pass

    def __interpret_value(self, value_str):
        global value
        if value_str == "":
            return None
        value = None
        try:
            exec_str = "global value\nvalue = %s" % value_str
            exec str(exec_str) in globals()
        except:
            return None
        return value

def main():
    gtk.gdk.threads_init()
    window1 = Window1()

    window1.run()

if __name__ == "__main__":
    main()
