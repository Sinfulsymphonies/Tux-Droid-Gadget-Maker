#!/usr/bin/python
# -*- coding: latin-1 -*-
import sys
import os
import math
import time
from array import *
import commands
from copy import copy
import threading
import DTW

# External binaries from SPTK tool kit
SPTK_X2X_PATH = '/opt/tuxdroid/apps/tux_framework/bin/x2x'
SPTK_FRAME_PATH = '/opt/tuxdroid/apps/tux_framework/bin/frame'
SPTK_WINDOW_PATH = '/opt/tuxdroid/apps/tux_framework/bin/window'
SPTK_PITCH_PATH = '/opt/tuxdroid/apps/tux_framework/bin/pitch'
SPTK_MGC2MGC_PATH = '/opt/tuxdroid/apps/tux_framework/bin/mgc2mgc'
SPTK_MGCEP_PATH = '/opt/tuxdroid/apps/tux_framework/bin/mgcep'
#
TEMP_RC_WAV_FILE = '/tmp/rc_tmp.uint8'
#
THRESHOLD_IN = 10
THRESHOLD_OUT = 8
THRESHOLD_LENGTH = 1000
MINIMUM_WORD_ENERGY = 4
MINIMUM_WORD_SIZE = 0.2
MAXIMUM_WORD_SIZE = 1
#
MAXIMUM_MATCH_AVERAGE = 0.1
MAXIMUM_MATCH_THRESHOLD = 0.9

class VoiceRecParametrize(object):

    def __init__(self, tux):
        self.__current_buffer = [] # Instant buffer
        self.__tmp_buffer = [[], []]
        self.__on_word = False
        self.__threshold_in = THRESHOLD_IN
        self.__threshold_out = THRESHOLD_OUT
        self.__t_out_length = THRESHOLD_LENGTH
        self.__energy_min = MINIMUM_WORD_ENERGY
        self.on_parametrized_word = None
        self.__run = False
        self.__alsa_device = "hw:0,0"
        self.__echo_word = False
        self.__do_echo_flag = False
        self.__new_run = False
        self.tux = tux

    def set_device(self, alsa_device):
        self.__alsa_device = alsa_device

    def set_echo_word(self, value):
        self.__echo_word = value

    def set_run(self, value = True, onoff = True):
        if value:
            if onoff:
                self.tux.cmd.sound_off()
        else:
            if onoff:
                self.tux.cmd.sound_on()
        self.__current_buffer = []
        self.__tmp_buffer = [[], []]
        self.__run = value
        if self.__do_echo_flag:
            self.__new_run = value

    def get_run(self):
        return self.__run

    def __check_begin_word(self):
        buffer = []
        for val in self.__tmp_buffer[0]:
            buffer.append(val)

        if self.__on_word:
            return False, []
        for i in range(len(buffer)):
            if abs(buffer[i] -127) > self.__threshold_in:
                self.__on_word = True
                return True, buffer[i:]
        return False, []

    def __check_end_word(self):
        buffer = []
        for val in self.__tmp_buffer[0]:
            buffer.append(val)
        for val in self.__tmp_buffer[1]:
            buffer.append(val)

        if not self.__on_word:
            return False, []
        idx = 0
        c = 0
        for i in range(len(buffer)):
            if abs(buffer[i] -127) < self.__threshold_out:
                if c == 0:
                    idx = i
                c += 1
                if c >= self.__t_out_length:
                    self.__on_word = False
                    return True, buffer[0:idx]
            else:
                c = 0
        return False, []

    def insert_buffer(self, buffer):
        if not self.get_run():
            return
        self.__tmp_buffer.append(buffer)
        self.__tmp_buffer.pop(0)

        ret, buff = self.__check_begin_word()
        if ret:
            self.__current_buffer = []
            for val in buff:
                self.__current_buffer.append(val)
            return

        ret, buff = self.__check_end_word()
        if ret:
            for val in buff:
                self.__current_buffer.append(val)
            if (len(self.__current_buffer) >= (MINIMUM_WORD_SIZE * 8000)) and (len(self.__current_buffer) <= (MAXIMUM_WORD_SIZE * 8000)):
                self.__process_word(self.__current_buffer)
                pass
            return

        if self.__on_word:
            for val in self.__tmp_buffer[0]:
                self.__current_buffer.append(val)

    def __play_buffer(self, buffer, tmp_file):
    	f = open(tmp_file , 'wb')
        for val in buffer:
            f.write(chr(val))
        f.close()
        self.echo(tmp_file)

    def __process_word(self, buffer):
        if self.__get_energy(buffer) < self.__energy_min:
            return
            
        #ref = (buffer[0]-127)
        #lt = []
        #for val in buffer[1:]:
        #    lt.append(abs((val-127)-ref))
        #    ref = (val-127)
        #print lt
        
        f = open(TEMP_RC_WAV_FILE , 'wb')
        for val in buffer:
            f.write(chr(val))
        f.close()
        self.__parametrize(TEMP_RC_WAV_FILE)
        if self.__echo_word:
            self.echo(TEMP_RC_WAV_FILE)

    def __get_energy(self, buffer):
        e = 0
        for i in range(len(buffer)):
            e += abs(buffer[i] - 127)
        return float(e) / len(buffer)

    def __parametrize(self, raw_path):
        cmd = '%s +Cf < %s | %s +f -l 256 -p 100 | %s -l 256 -L 256 -w 1 | %s -l 256 -m 6 -a 0.42 -g 2 | %s -m 6 -a 0.42 -g 2 -M 6 -A 0.42 -G 0' % (
                    SPTK_X2X_PATH,
                    raw_path,
                    SPTK_FRAME_PATH,
                    SPTK_WINDOW_PATH,
                    SPTK_MGCEP_PATH,
                    SPTK_MGC2MGC_PATH)

        res = commands.getoutput(cmd)
        m_size = len(res)
        a = array('f')
        a.fromstring(res)
        b = a.tolist()
        if self.on_parametrized_word != None:
            self.on_parametrized_word(b)

    def echo(self, file_path = TEMP_RC_WAV_FILE):
        self.__do_echo_flag = True
        #self.__new_run = self.get_run()
        self.set_run(False, True)
        if os.path.isfile(file_path):
            t = time.time()
            #self.tux.cmd.sound_on()
            os.system("aplay -D %s %s" % (self.__alsa_device, file_path))
            #self.tux.cmd.sound_off()
            if (time.time() - t) < 0.1:
                self.tux.cmd.audio_channel_tts()
                #self.tux.cmd.sound_on()
                self.tux.wav.play(file_path)
                #self.tux.cmd.sound_off()
                self.tux.cmd.audio_channel_general()
        #self.set_run(self.__new_run, True)
        self.set_run(True, True)
        self.__do_echo_flag = False

class VoiceRecAcquire(object):

    def __init__(self):
        self.__mcep_coeff = []
        self.__mutex = threading.Lock()
        pass

    def insert_params(self, mcep_coeff):
        self.__mutex.acquire()
        self.__mcep_coeff = mcep_coeff
        self.__mutex.release()

    def get_word(self, word_name):
        self.__mutex.acquire()
        self.__mcep_coeff = []
        self.__mutex.release()
        t = []
        print 'Get word : %s' % word_name
        while len(t) == 0:
            time.sleep(0.1)
            self.__mutex.acquire()
            t = copy(self.__mcep_coeff)
            self.__mutex.release()
        return t


class VoiceRecMatching(object):

    def __init__(self):
        self.__rc_seuil = MAXIMUM_MATCH_THRESHOLD
        self.__dictionary = []
        self.__dict_file = 'rc_dict'
        self.on_matched_word = None
        self.__mutex = threading.Lock()

    def insert_word(self, word_name, mcep_coeff):
        self.__mutex.acquire()
        for e in self.__dictionary:
            if e[0].lower() == word_name.lower():
                self.__mutex.release()
                return
        self.__dictionary.append([word_name, mcep_coeff])
        self.__mutex.release()
        
    def replace_word(self, word_name, mcep_coeff):
        self.__mutex.acquire()
        for e in self.__dictionary:
            if e[0].lower() == word_name.lower():
                e[1] = mcep_coeff
        self.__mutex.release()
        
    def remove_word(self, word_name):
        self.__mutex.acquire()
        for i, e in enumerate(self.__dictionary):
            if e[0].lower() == word_name.lower():
                self.__dictionary.pop(i)
                break
        self.__mutex.release()
        
    def get_word_list(self):
        self.__mutex.acquire()
        ret = []
        for val in self.__dictionary:
            ret.append(val[0])
        self.__mutex.release()
        return ret
    
    def word_exits(self, word):
        self.__mutex.acquire()
        ret = False
        for wd in self.__dictionary:
            if wd[0].lower() == word.lower():
                ret = True
                break
        self.__mutex.release()
        return ret
        
    def get_word(self, word):
        self.__mutex.acquire()
        ret = []
        for wd in self.__dictionary:
            if wd[0].lower() == word.lower():
                ret = wd
                break
        self.__mutex.release()
        return ret

    def save_words(self, path):
        try:
            if not os.path.isfile(path):
                return
        except:
            return
        self.__mutex.acquire()
        st = 'words=%s' % str(self.__dictionary)
        f = open(path, 'w')
        f.write(st)
        f.close()
        self.__mutex.release()

    def load_words(self, path):
        self.__mutex.acquire()
        if not os.path.isfile(path):
            self.__dictionary = []
            self.__mutex.release()
            return
        f = open(path, 'r')
        st = f.read()
        f.close()
        global words
        words = []
        exec str(st) in globals()
        self.__dictionary = words
        self.__mutex.release()

    def __DTW(self, a_ref, a_test):
    	val = DTW.DTW(a_ref, a_test)
    	return val
    	
    def __realling_coeff(self, coeff):
        c = len(coeff) / 7
        ret = [[], [], [], [], [], [], []]
        for i in range(c):
            for j in range(7):
                ret[j].append(coeff[(i*7) + j])
        return ret

    def match(self, mcep_coeff):
        if self.__mutex.locked():
            return
        self.__mutex.acquire()
        if len(self.__dictionary) == 0:
            self.__mutex.release()
            return
        p_list = []
        #t = time.time()
        for l in self.__dictionary:
            if len(l[1]) == 0:
                continue
            v_l1 = self.__realling_coeff(l[1])
            v_l2 = self.__realling_coeff(mcep_coeff)
            res = 0
            for i in range(7):
                res += self.__DTW(v_l1[i], v_l2[i])
            len_diff = float(len(v_l2[0])) / len(v_l1[0])
            p_list.append([l[0], res, len_diff])
        if len(p_list) == 0:
            self.__mutex.release()
            return
            
        lst = []
        for c in p_list:
            #print c[0], ' ', c[1], ' ', c[2]
            lst.append(c[1])
        
        min_val = min(lst)
        min_idx = lst.index(min_val)
        lst.remove(min_val)
        min_val2 = min(lst)
        ecart = min_val2 - min_val
        ecart_min = min_val * MAXIMUM_MATCH_AVERAGE
        #print min_val, ' ecart : ', min_val2 - min_val, ' Ecart min : ', ecart_min
        if (min_val < self.__rc_seuil) and (ecart >= ecart_min):
            if self.on_matched_word != None:
                self.on_matched_word(p_list[min_idx][0])
        self.__mutex.release()
