#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - Debug
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import os
import sys
import threading
import time
import syslog

# Flag which allow the debug messages on a log file
ALLOW_LOG_FLAG = True

class GdgDebugger(object):
    """
    Class which manages the debug messages.

        Global constants:
        "ALLOW_LOG_FLAG" as boolean : allow or disallow to insert the messages
                                      in a log file.

        Functions list for the users:
        gadget_debug.insert_debug
        gadget_debug.insert_error
        gadget_debug.get_all_debug_messages
        gadget_debug.get_all_error_messages
    """

    def __init__(self):
        self.PATH_APP = os.path.realpath(os.path.dirname(sys.argv[0]))
        self.__debug_messages_stack = []
        self.__error_messages_stack = []
        self.__stack_mutex = threading.Lock()
        self.on_new_debug_message = None
        self.on_new_error_message = None
        self.running = True
        if ALLOW_LOG_FLAG:
            self.debug_msg_log_file = open(self.PATH_APP + '/debug.log', 'w')
            self.debug_msg_log_file.close()
            self.error_msg_log_file = open(self.PATH_APP + '/error.log', 'w')
            self.error_msg_log_file.close()

    def destroy(self):
        self.__stack_mutex.acquire()
        self.running = False
        self.__stack_mutex.release()

    def insert_debug(self, message):
        """
        Insert a new message in the debug section.

            Parameters:
            "message" as string : message to insert
        """
        self.__stack_mutex.acquire()
        if not self.running:
            self.__stack_mutex.release()
            return
        now = time.localtime()
        my_message = "%.2d:%.2d:%.2d : %s\n" % (now[3], now[4], now[5], message)
        self.__debug_messages_stack.append(my_message)
        if ALLOW_LOG_FLAG:
            self.debug_msg_log_file = open(self.PATH_APP + '/debug.log', 'a')
            self.debug_msg_log_file.write(my_message)
            self.debug_msg_log_file.close()
            syslog.syslog(syslog.LOG_DEBUG, message)
        else:
            if len(self.__debug_messages_stack) > 100:
                self.__debug_messages_stack.pop(0)
        if self.on_new_debug_message != None:
            self.on_new_debug_message(my_message)
        self.__stack_mutex.release()

    def get_all_debug_messages(self):
        """
        Function to retrieve the 'debug' messages stack.

            Returns:
            A list of messages.
        """
        self.__stack_mutex.acquire()
        if not self.running:
            self.__stack_mutex.release()
            return []
        stack = self.__debug_messages_stack
        self.__stack_mutex.release()
        return stack

    def insert_error(self, message):
        """
        Insert a new message in the error section.

            Parameters:
            "message" as string : message to insert
        """
        self.__stack_mutex.acquire()
        if not self.running:
            self.__stack_mutex.release()
            return
        now = time.localtime()
        my_message = "%.2d:%.2d:%.2d : %s\n" % (now[3], now[4], now[5], message)
        self.__error_messages_stack.append(my_message)
        if ALLOW_LOG_FLAG:
            self.error_msg_log_file = open(self.PATH_APP + '/error.log', 'a')
            self.error_msg_log_file.write(my_message)
            self.error_msg_log_file.close()
            syslog.syslog(syslog.LOG_ERR, message)
        else:
            if len(self.__error_messages_stack) > 100:
                self.__error_messages_stack.pop(0)
        if self.on_new_error_message != None:
            self.on_new_error_message(my_message)
        self.__stack_mutex.release()

    def get_all_error_messages(self):
        """
        Function to retrieve the 'error' messages stack.

            Returns:
            A list of messages.
        """
        self.__stack_mutex.acquire()
        if not self.running:
            self.__stack_mutex.release()
            return []
        stack = self.__error_messages_stack
        self.__stack_mutex.release()
        return stack
