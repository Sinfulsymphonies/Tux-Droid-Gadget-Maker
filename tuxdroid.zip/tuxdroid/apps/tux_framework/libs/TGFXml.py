#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget Format - Xml
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
# -*- coding: latin1 -*-
import xml.dom.minidom
import xml.dom
from xml.dom.minidom import Node

# General file paths
settings_xml_rel_path = '/settings.xml'
about_xml_rel_path = '/about.xml'
parts_xml_rel_path = '/parts.xml'
strings_xml_rel_path = '/strings.xml'
main_pyp_rel_path = '/Scripts/Python/main.pyp'
init_pyp_rel_path = '/Scripts/Python/init.pyp'
notify_pyp_rel_path = '/Scripts/Python/notify.pyp'
config_glade_rel_path = '/Scripts/Python/GUI/Configuration/configuration.glade'
config_pyp_rel_path = '/Scripts/Python/GUI/Configuration/configuration.pyp'
widget_glade_rel_path = '/Scripts/Python/GUI/Widget/widget.glade'
widget_pyp_rel_path = '/Scripts/Python/GUI/Widget/widget.pyp'
gadget_png_rel_path = '/Pictures/Icons/gadget.png'
icons_rel_path = '/Pictures/Icons'
sounds_rel_path = '/Sounds'
python_rel_path = '/Scripts/Python'
gui_rel_path = '/Scripts/Python/GUI'

# Accepted languages
f_language_dict = { 'ar_ALL' : 1025,
                    'nl_BE' : 2067,
                    'en_GB' : 2057,
                    'da_ALL' : 1030,
                    'fr_ALL' : 1036,
                    'de_ALL' : 1031,
                    'it_ALL' : 1040,
                    'nl_NL' : 1043,
                    'no_ALL' : 1044,
                    'pt_ALL' : 2070,
                    'es_ALL' : 1034,
                    'sv_ALL' : 1037,
                    'en_US' : 1033 }
lang_ab_to_lang_country = {
    'D' : 'de_ALL',
    'GB' : 'en_GB',
    'US' : 'en_US',
    'AR' : 'ar_ALL',
    'DK' : 'da_ALL',
    'E' : 'es_ALL',
    'F' : 'fr_ALL',
    'I' : 'it_ALL',
    'B' : 'nl_BE',
    'NL' : 'nl_NL',
    'N' : 'no_ALL',
    'P' : 'pt_ALL',
    'S' : 'sv_ALL',
}

lang_country_list = ['de_ALL', 'en_GB', 'en_US', 'ar_ALL', 'da_ALL', 'es_ALL',
            'fr_ALL', 'it_ALL', 'nl_BE', 'nl_NL', 'no_ALL', 'pt_ALL',
            'sv_ALL']

def insert_leaf(parent_node, text_id, text_value):
    """
    Insert a leaf in a xml structure
    """
    xml_obj = xml.dom.minidom.Document()
    leaf_node = xml_obj.createElement(text_id)
    type_str = str(type(text_value)).replace("<type '", '')
    type_str = type_str.replace("'>", '')
    if type_str == 'str':
        if text_value == "":
            text_value = " "
    leaf_node.setAttribute('type', type_str)
    text = xml_obj.createTextNode(str(text_value))
    leaf_node.appendChild(text)
    parent_node.appendChild(leaf_node)

def insert_node(parent_node, node_id):
    """
    Insert a node in a xml structure
    """
    xml_obj = xml.dom.minidom.Document()
    new_node = xml_obj.createElement(node_id)
    parent_node.appendChild(new_node)
    return new_node

def struct_to_xml(struct, xml_path):
    """
    Write a xml file from a dict structure
    """
    xml_obj = xml.dom.minidom.Document()

    def node_struct_to_nxml(parent_node, node_struct):
        keys = node_struct.keys()
        keys.sort()
        for key in keys:
            if str(type(node_struct[key])) <> "<type 'dict'>":
                insert_leaf(parent_node,  key, node_struct[key])
            else:
                new_node = insert_node(parent_node, key)
                node_struct_to_nxml(new_node, node_struct[key])

    node_struct_to_nxml(xml_obj, struct)
    try:
        f_xml = open(xml_path, 'w')
    except IOError:
        return False
    xml.dom.ext.PrettyPrint(xml_obj, f_xml)
    f_xml.close()
    return True

def xml_to_struct(struct, xml_path):
    """
    Get a dict structure from a xml file
    """
    struct = {}
    def node_xml_to_struct(parent_node, node_struct):
        for childNode in parent_node.childNodes:
            global lv_tmp123
            if childNode.nodeValue == None:
                it = parent_node.getElementsByTagName(childNode.localName)
                if len(it[0].childNodes) > 0:
                    value = it[0].childNodes[0].nodeValue
                else:
                    value = ''
                type_val = it[0].getAttribute('type')
                name = childNode.localName
                if it[0].getAttribute('type') != '':
                    leaf_name = name.encode('utf-8','replace')
                    if type_val == 'str':
                        lv_tmp123 = value.encode('utf-8','replace')
                        if lv_tmp123.find('\n    ') == 0:
                            lv_tmp123 = ''
                    else:
                        lv_tmp123 = ''
                        r_type_str = 'global lv_tmp123\nlv_tmp123 = %s' % value
                        exec str(r_type_str) in globals()
                    node_struct[leaf_name] = lv_tmp123
                else:
                    name = name.encode('utf-8','replace')
                    n_dict = {}
                    node_struct[name] = n_dict
                    node_xml_to_struct(it[0], node_struct[name])

    try:
        f_xml = open(xml_path, 'rb')
    except IOError:
        return False
    xml_str = f_xml.read()
    f_xml.close()
    xml_obj = xml.dom.minidom.parseString(xml_str)
    node_xml_to_struct(xml_obj, struct)
    return True, struct

def get_value_from_struct(struct, way):
    """
    Get a value from a dict structure
    """
    way_e = way.split('.')
    value = struct
    for key in way_e:
        value = value[key]
    return value

def modify_value_from_struct(struct, way, new_value):
    """
    Modify a value in a dict structure
    """
    way_e = way.split('.')
    node = struct
    for key in way_e:
        last_node = node
        node = node[key]
    last_node[key] = new_value

def insert_leaf_in_struct(struct, way, leaf_name, leaf_value):
    """
    Insert a leaf into a structure
    """
    way_e = way.split('.')
    node = struct
    for key in way_e:
        last_node = node
        node = node[key]
    node[leaf_name] = leaf_value
