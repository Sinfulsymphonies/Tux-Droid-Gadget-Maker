#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - Gui update
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------

import threading
import time
import gtk

class GdgGuiUpdate(object):

    def __init__(self):
        self.__stack_mutex = threading.Lock()
        self.__stack_update = []
        self.__thread = None
        self.start_loop()

    def destroy(self):
        self.stop_loop()

    def insert(self, gui_op, *args):
        self.__stack_mutex.acquire()
        self.__stack_update.append([gui_op, args])
        self.__stack_mutex.release()

    def start_loop(self):
        self.__thread = threading.Thread(target = self.__loop)
        self.__thread.setName('Gui update')
        self.__thread.start()

    def stop_loop(self):
        if self.__thread != None:
            if self.__thread.isAlive():
                self.__thread._Thread__stop()
                self.__thread.join()

    def __loop(self):
        while True:
            gui_update = []
            self.__stack_mutex.acquire()
            if len(self.__stack_update) > 0:
                gui_update = self.__stack_update.pop(0)
            self.__stack_mutex.release()
            if len(gui_update) > 0:
                gtk.gdk.threads_enter()
                try:
                    gui_update[0](*gui_update[1][0])
                except:
                    pass
                gtk.gdk.threads_leave()
            time.sleep(0.01)
