#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - Object
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import sys
import time
import traceback
import os
import string
import threading
import thread
import gtk
import random
from SimpleGladeApp import SimpleGladeApp
from SimpleGladeApp import bindtextdomain
import zipfile
from copy import copy

from TGFormat import *
from TGFXml import *
from TGFCanvas import scene_struct
from GoogleTranslate import google_translate, GOOGLE_LANGPAIRS
from BabelfishTranslate import babelfish_translate, BABELFISH_LANGPAIRS
from Languages import *
from TextFilters import *
from GdgDebug import GdgDebugger
from GdgThreads import gadget_thread
from GdgGuiUpdate import GdgGuiUpdate
from GdgDownload import GdgDownload
from tdrss import *
from GdgVoiceRec import VoiceRecParametrize, VoiceRecAcquire, VoiceRecMatching
from TimeLineReader import TimelineReader

sys.path.append('/opt/tuxdroid/api/python')
from tuxapi_const import *
from tuxapi_class import TuxSwitch
from tux import * # This library create a tux object
PATH_APP = os.path.realpath(os.path.dirname(sys.argv[0]))

# Container of gadgets
gadgets = {}
# Container of shared functions
shared_functions = {}
# Mutex for synchronizing the notifications
notify_mutex = threading.Lock()
# Mutex for synchronizing the gadgets
gadget_mutex = threading.Lock()
# Mutex for synchronizing the TTS speak
tts_mutex = threading.Lock()
# Flag which allow the debug messages on the terminal
debug_on_terminal = False
# Head switch
_tux_head_switch = TuxSwitch(tux, STATUS_HEAD_PUSH_SWITCH)
# Left wing switch
_tux_lwing_switch = TuxSwitch(tux, STATUS_LEFT_WING_PUSH)
# Right wing switch
_tux_rwing_switch = TuxSwitch(tux, STATUS_RIGHT_WING_PUSH)


class GdgDialog(object):

    def __init__(self, title, message, block = False, center_justify = False):
        self.message = message
        self.title = title
        self.__center_justify = center_justify
        if block:
            self.__show()
        else:
            gadget_thread.start_new_thread(self.__show_async, ())
        
    def __show_async(self):
        gtk.gdk.threads_enter()
        self.__show()
        gtk.gdk.threads_leave()

    def __show(self):
        dialogue = gtk.Dialog(self.title, None, gtk.DIALOG_MODAL, ())
        dialogue.set_property("width-request", 350)
        if gadgets.has_key('Manager'):
            dialogue.set_icon_from_file(gadgets['Manager'].icons['gadget.png'])
        bt_alone = dialogue.add_button("Ok/Cancel", gtk.RESPONSE_APPLY)

        def on_click_okcancel(obj):
            dialogue.destroy()

        bt_alone.connect("clicked", on_click_okcancel)
        box = gtk.HBox(spacing = 5)
        box.set_border_width(5)
        box.show()
        dialogue.vbox.pack_start(box)
        
        lab = gtk.Label(self.message)
        lab.set_property("width-request", 300)
        lab.set_line_wrap(True)
        if self.__center_justify:
            lab.set_justify(gtk.JUSTIFY_CENTER)
        else:
            lab.set_justify(gtk.JUSTIFY_LEFT)

        box.pack_start(lab, False, False, 0)
        
        dialogue.show_all()
        dialogue.run()
        
class GdgDialogScrolled(object):

    def __init__(self, title, message, gadget, block = False, center_justify = False):
        self.message = message
        self.title = title
        self.__center_justify = center_justify
        self.gadget = gadget
        if block:
            self.__show()
        else:
            gadget_thread.start_new_thread(self.__show_async, ())
        
    def __show_async(self):
        gtk.gdk.threads_enter()
        self.__show()
        gtk.gdk.threads_leave()

    def __show(self):
        dialog = gtk.Dialog(self.title, None, gtk.DIALOG_MODAL, ())
        dialog.set_property("width-request", 350)
        if gadgets.has_key('Manager'):
            dialog.set_icon_from_file(self.gadget.get_icon('gadget.png'))
        bt_alone = dialog.add_button("Ok/Cancel", gtk.RESPONSE_APPLY)

        def on_click_okcancel(obj):
            dialog.destroy()

        bt_alone.connect("clicked", on_click_okcancel)
        
        hbox1 = gtk.HBox(spacing = 5)
        hbox1.set_border_width(5)
        hbox1.show()
        dialog.vbox.pack_start(hbox1)
        fd = gtk.ScrolledWindow()
        fd.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
        fd.set_property("height-request", 300)
        hbox1.pack_start(fd)
        box = gtk.VBox(spacing=0)
        fd.add_with_viewport(box)

        lab = gtk.Label(self.message)
        lab.set_property("width-request", 300)
        lab.set_line_wrap(True)
        if self.__center_justify:
            lab.set_justify(gtk.JUSTIFY_CENTER)
        else:
            lab.set_justify(gtk.JUSTIFY_LEFT)
        box.pack_start(lab, False, False, 0)

        dialog.show_all()
        dialog.run()

class GdgDialogQuestion(object):

    def __init__(self, title, message, on_yes_event, block = False):
        self.message = message
        self.title = title
        self.on_yes_event = on_yes_event
        if block:
            self.__show()
        else:
            gadget_thread.start_new_thread(self.__show_async, ())
        
    def __show_async(self):
        gtk.gdk.threads_enter()
        self.__show()
        gtk.gdk.threads_leave()

    def __show(self):
        dialogue = gtk.Dialog(self.title, None, gtk.DIALOG_MODAL, ())
        dialogue.set_property("width-request", 350)
        if gadgets.has_key('Manager'):
            dialogue.set_icon_from_file(gadgets['Manager'].icons['gadget.png'])
        bt_yes = dialogue.add_button(gtk.STOCK_YES, gtk.RESPONSE_YES)
        bt_no = dialogue.add_button(gtk.STOCK_NO, gtk.RESPONSE_NO)

        def on_click_yes(obj):
            def async():
                if self.on_yes_event != None:
                    self.on_yes_event()
            gadget_thread.start_new_thread(async, ())
            dialogue.destroy()

        def on_click_no(obj):
            dialogue.destroy()

        bt_yes.connect("clicked", on_click_yes)
        bt_no.connect("clicked", on_click_no)
        box = gtk.HBox(spacing = 5)
        box.set_border_width(5)
        box.show()
        dialogue.vbox.pack_start(box)
        
        lab = gtk.Label(self.message)
        lab.set_property("width-request", 300)
        lab.set_line_wrap(True)
        lab.set_justify(gtk.JUSTIFY_LEFT)
        box.pack_start(lab, False, False, 0)
        
        dialogue.show_all()
        dialogue.run()

class GdgScene(object):
    """
    Class which load and manage a Tuxdroid scene.

        Global variables:
        "scene.name" as string
        "scene.author" as string
        "scene.version" as string
        "scene.description" as string
        "scene.keywords" as list of string
        "scene.length" as float
        "scene.category" as string
        "scene.sub_category" as string
        "scene.from_gadget" as GdgObject

        Functions list for the users:
        scene.__init__
        scene.play
    """

    def __init__(self, tsc_filename, gadget = None):
        """
        Constructor of class.

            Parameters:
            "tsc_filename" as string    : path of the *.tsc filename
            "gadget" as GdgObject       : gadget parent of the scene
        """
        self.__gene_wav_mutex = threading.Lock()
        self.tsc_filename = tsc_filename
        self.tsc_filename = self.tsc_filename.replace('%20', ' ')
        self.tmp_path = ""
        self.name = "Noname"
        self.author = "Noname"
        self.version = "0.0.0"
        self.description = "Nodescription"
        self.keywords = ['Nokeywords',]
        self.length = 0.0
        self.category = "common"
        self.sub_category = "common"
        self.from_gadget = gadget
        self.sc_struct = scene_struct
        self.__is_timeline = False
        self.tl_reader = None
        self.__script = []
        self.__wav_files = {}
        self.__uncompress()
        self.__parse_header()
        self.__get_wav_files()
        self.__remove_tmp_path()

    def insert_python_script(self, path):
        self.__parse_script(path)
        
    def insert_wav(self, path):
        filename = os.path.basename(path)
        if filename.lower().find('.wav') == -1:
            return False
        f = open(path, 'rb')
        wav_buff = f.read()
        f.close()
        self.__wav_files[filename] = wav_buff
        return True
        
    def remove_wav(self, filename):
        if self.__wav_files.has_key(filename):
            self.__wav_files.pop(filename)
        
    def to_file(self, path):
        TMP_PATH = self.tmp_path + '@'
        bn = os.path.basename(path)
        TMP_PATH2 = os.path.join(TMP_PATH, bn)[:-4]
        self.__make_scene_directory(TMP_PATH2)
        self.__compress(TMP_PATH, path)
        
    def __make_scene_directory(self, path):
        # Create path
        TMP_PATH = path
        if os.path.exists(TMP_PATH):
            os.system('rm -fR "%s"' % TMP_PATH)
        os.makedirs(TMP_PATH, 511)
        if not os.path.isdir(TMP_PATH):
            return
        # Create scene.xml
        self.sc_struct['scene']['wavs'] = {}
        self.sc_struct['scene']['wavs']['count'] = len(self.__wav_files)
        for i, wav_fn in enumerate(self.__wav_files.keys()):
            self.sc_struct['scene']['wavs']['wav%d' % i] = wav_fn
        self.sc_struct['scene']['header']['name'] = self.name
        self.sc_struct['scene']['header']['author'] = self.author
        self.sc_struct['scene']['header']['version'] = self.version
        self.sc_struct['scene']['header']['description'] = self.description
        self.sc_struct['scene']['header']['keywords'] = self.keywords
        self.sc_struct['scene']['header']['length'] = self.length
        self.sc_struct['scene']['header']['category'] = self.category
        self.sc_struct['scene']['header']['sub_category'] = self.sub_category
        struct_to_xml(self.sc_struct, TMP_PATH + '/scene.xml')
        # Create python script
        if self.sc_struct['scene']['body']['script']['language'] == 'python':
            self.__store_script(TMP_PATH + self.sc_struct['scene']['body']['script']['path'])
        elif self.sc_struct['scene']['body']['script']['language'] == 'timeline':
            self.__is_timeline = True
        # Create wav path
        WAVS_PATH = TMP_PATH + '/wavs'
        os.makedirs(WAVS_PATH, 511)
        # Store wavs
        for wav_fn in self.__wav_files.keys():
            wav_file = os.path.join(WAVS_PATH, wav_fn)
            f = open(wav_file, 'wb')
            f.write(self.__wav_files[wav_fn])
            f.close()
            
    def set_timeline_struct(self, struct):
        self.sc_struct['scene']['body']['script']['language'] = 'timeline'
        self.sc_struct['scene']['body']['script']['timeline'] = struct
        
    def get_timeline_struct(self):
        if self.sc_struct['scene']['body']['script']['language'] == 'timeline':
            struct = copy(self.sc_struct['scene']['body']['script']['timeline'])
        else:
            struct = {}
        return struct
        
    def play_wav(self, wav_name, idx_begin = 0.0, idx_end = 0.0):
        if not self.__wav_files.has_key(wav_name):
            return
        i = 0
        while (os.path.isfile('/tmp/tmp%.3d.wav' % i)):
            i += 1
        wav_file = '/tmp/tmp%.3d.wav' % i
        self.__gene_wav_mutex.acquire()
        f = open(wav_file, 'wb')
        f.write(self.__wav_files[wav_name])
        f.close()
        self.__gene_wav_mutex.release()
        tux.wav.play(wav_file, idx_begin, idx_end)
        os.system('rm -f "%s"' % wav_file)
        
    def get_wav(self, wav_name):
        if not self.__wav_files.has_key(wav_name):
            return None
        wav_file = '/tmp/tmp007.wav'
        f = open(wav_file, 'wb')
        f.write(self.__wav_files[wav_name])
        f.close()
        return wav_file
            
    def __compress(self, in_path, out_path):
        TMP_PATH = in_path
        # Goto the root directory
        last_cwd = os.getcwd()
        os.chdir(os.path.abspath(TMP_PATH))
        # Create a zip file
        zf = ZipFile(out_path, 'w')
        # Loop on tgf directories struct
        for root, dirs, files in os.walk(TMP_PATH):
            for ffile in files:
                full_path = root + '/' + ffile
                rel_path = full_path.replace(TMP_PATH + '/', '')
                zf.write(rel_path)
        zf.close()
        # Set the old cwd
        os.chdir(os.path.abspath(last_cwd))
        # Remove in_path
        if os.path.exists(in_path):
            os.system('rm -fR "%s"' % in_path)
        
    def __uncompress(self):
        if not os.path.isfile(self.tsc_filename):
            return
        if self.tsc_filename.lower().find('.tsc') == -1:
            return
        (f_path, f_name) = os.path.split(self.tsc_filename)
        f_dir = f_name.lower().replace('.tsc', '')
        d_path = '/tmp'
        self.tmp_path = d_path + '/' + f_dir
        if os.path.exists(self.tmp_path):
            os.system('rm -fR "%s"' % self.tmp_path)
        zf = zipfile.ZipFile(self.tsc_filename, 'r')
        for name in zf.namelist():
            file_path = os.path.join(d_path, name)
            if not os.path.exists(os.path.dirname(file_path)):
                os.makedirs(os.path.dirname(file_path), 511)
            f = open(file_path, 'wb')
            f.write(zf.read(name))
            f.close()
        zf.close()

    def __remove_tmp_path(self):
        if os.path.exists(self.tmp_path):
            os.system('rm -fR "%s"' % self.tmp_path)

    def __parse_header(self):
        xml_path = self.tmp_path + '/scene.xml'
        if os.path.isfile(xml_path):
            self.sc_struct = {}
            try:
                self.sc_struct = xml_to_struct(self.sc_struct, xml_path)
                self.sc_struct = self.sc_struct[1]
                self.name = self.sc_struct['scene']['header']['name']
                self.author = self.sc_struct['scene']['header']['author']
                self.version = self.sc_struct['scene']['header']['version']
                self.description = self.sc_struct['scene']['header']['description']
                self.keywords = self.sc_struct['scene']['header']['keywords']
                for i in range(len(self.keywords)):
                    self.keywords[i] = self.keywords[i].lower()
                self.length = self.sc_struct['scene']['header']['length']
                self.category = self.sc_struct['scene']['header']['category']
                self.sub_category = self.sc_struct['scene']['header']['sub_category']
                if self.sc_struct['scene']['body']['script']['language'] == 'python':
                    path = self.tmp_path + self.sc_struct['scene']['body']['script']['path']
                    if os.path.isfile(path):
                        self.__parse_script(path)
                elif self.sc_struct['scene']['body']['script']['language'] == 'timeline':
                    self.__is_timeline = True
            except:
                pass
        else:
            return

    def __parse_script(self, path):
        self.__script = []
        try:
            f = open(path, 'r')
            for line in f:
                self.__script.append(line[:-1])
            f.close()
        except:
            return
            
    def get_script(self):
        ret = ""
        for line in self.__script:
            ret += "%s\n" % line
        return ret[:-1]
        
    def set_script(self, script_string):
        self.__script = script_string.split('\n')
            
    def __store_script(self, path):
        try:
            f = open(path, 'w')
            for line in self.__script:
                f.write("%s\n" % line)
            f.close()
        except:
            return
            
    def get_wav_path(self, wav_name):
        TMP_WAV_PATH  = '/tmp/tsc_wavs'
        wav_file = os.path.join(TMP_WAV_PATH, wav_name)
        if os.path.isfile(wav_file):
            return wav_file
        else:
            return ""
            
    def get_wav_list(self):
        return self.__wav_files.keys()

    def __get_wav_files(self):
        if not os.path.isdir(self.tmp_path + '/wavs'):
            return
        paths = os.listdir(self.tmp_path + '/wavs')
        for m_file in paths:
            if m_file.lower().find('.wav') != -1:
                filepath = os.path.join(self.tmp_path + '/wavs', m_file)
                f = open(filepath, 'rb')
                wav_buff = f.read()
                f.close()
                (wav_path, wav_name) = os.path.split(filepath)
                self.__wav_files[wav_name] = wav_buff

    def stop(self):
        if self.__is_timeline:
            if self.tl_reader != None:
                self.tl_reader.stop_read()
        
    def play(self):
        """
        Play the scene.
        """
        TMP_WAV_PATH  = '/tmp/tsc_wavs'
        if os.path.exists(TMP_WAV_PATH):
            os.system('rm -fR "%s"' % TMP_WAV_PATH)
        os.makedirs(TMP_WAV_PATH, 511)
        for wav_fn in self.__wav_files.keys():
            wav_file = os.path.join(TMP_WAV_PATH, wav_fn)
            f = open(wav_file, 'wb')
            f.write(self.__wav_files[wav_fn])
            f.close()

        def abs_wav_path(wav_re):
            abs_path = os.path.join(TMP_WAV_PATH, wav_re.group(1))
            return "tux.wav.play('%s'" % abs_path

        def abs_wav_path2(wav_re):
            abs_path = os.path.join(TMP_WAV_PATH, wav_re.group(1))
            return "tux.wav.play('%s'" % abs_path

        if not self.__is_timeline:
            global scene
            scene = self
            script = ""
            wav_re = re.compile(r'tux.wav.play\("(.*?)"', re.M)
            wav_re2 = re.compile(r'tux.wav.play_free\("(.*?)"', re.M)
            for line in self.__script:
                line = wav_re.sub(abs_wav_path, line)
                line = wav_re2.sub(abs_wav_path2, line)
                script = script + line + '\n'
            try:
                exec str(script) in globals()
            except:
                error_msg = 'SCENE ERROR [%s]' % self.name
                gadget_debug.insert_error(error_msg)
            if os.path.exists(TMP_WAV_PATH):
                os.system('rm -fR "%s"' % TMP_WAV_PATH)
        else:
            self.tl_reader = TimelineReader(tux, None, self)
            try:
                self.tl_reader.from_xml_struct()
                self.tl_reader.read_loop(0.0, self.length)
                self.tl_reader.stop_read()
            except:
                error_msg = 'SCENE ERROR [%s] : \n%s' % (self.name, str(sys.exc_info()))
                gadget_debug.insert_error(error_msg)

class GdgSceneContainer(object):
    """
    Class which create an control a scene container.

        Functions list for the users:
        scene_container.insert
        scene_container.get_cat_list
        scene_container.get_list
        scene_container.get_list_from_category
        scene_container.get_list_from_keywords_and
        scene_container.get_list_from_keywords_or
        scene_container.get_scene
        scene_container.get_scene_from_category
        scene_container.play
        scene_container.play_from_category
        scene_container.remove
        scene_container.scene_exists
    """

    def __init__(self):
        self.__list = {}
        self.__categories = {}
        self.__play_mutex = threading.Lock()
        self.__current_scene = None

    def destroy(self):
        self.__play_mutex.acquire()
        self.__list = {}
        self.__play_mutex.release()

    def insert(self, scene):
        """
        Insert a scene in the container.

            Parameters:
            "scene" as GdgScene : scene to insert
        """
        while self.__list.has_key(scene.name):
            scene.name = scene.name + '_'
        self.__list[scene.name] = scene
        if not self.__categories.has_key(scene.category):
            self.__categories[scene.category] = []
        self.__categories[scene.category].append(scene.name)

    def remove(self, name):
        """
        Remove a scene from the container.

            "name" as string  : name of the scene to remove
        """
        if self.__list.has_key(name):
            self.__list.pop(name)
            for cat_scene_lst in self.get_cat_list():
                if name in self.__categories[cat_scene_lst]:
                    self.__categories[cat_scene_lst].remove(name)

    def get_list(self):
        """
        Get the scene list.

            Returns:
            A list of strings.
        """
        return self.__list.keys()

    def get_cat_list(self):
        """
        Get the category list.

            Returns:
            A list of strings.
        """
        lst = self.__categories.keys()
        lst.sort()
        return lst

    def get_list_from_category(self, category):
        """
        Get the scene list of a category.

            Parameters:
            "category" as string : name of the category

            Returns:
            A list of strings.
        """
        if self.__categories.has_key(category):
            lst = self.__categories[category]
            lst.sort()
            return lst
        else:
            return []

    def get_list_from_keywords_or(self, keywords = ['comon',]):
        """
        Get a list of scenes containing one of the following keywords.

            Parameters:
            "keywords" as list of strings   : keywords list

            Returns:
            A list of strings.
        """
        for i in range(len(keywords)):
            keywords[i] = keywords[i].lower()
        lst = self.get_list()
        result = []
        for scene_name in lst:
            scene = self.__list[scene_name]
            for kw in scene.keywords:
                if kw in keywords:
                    result.append(scene_name)
                    break
        return result

    def get_list_from_keywords_and(self, keywords = ['comon',]):
        """
        Get a list of scenes containing all of the following keywords.

            Parameters:
            "keywords" as list of strings   : keywords list

            Returns:
            A list of strings.
        """
        lst = self.get_list()
        result = []
        for scene_name in lst:
            scene = self.__list[scene_name]
            match_all = True
            for kw in keywords:
                if not kw.lower() in scene.keywords:
                    match_all = False
                    break
            if match_all:
                result.append(scene_name)
        return result

    def get_scene_from_category(self, category, sub_category = None):
        """
        Get a scene randomly selected from a category.

            Parameters:
            "category" as string        : name of the category
            "sub_category" as string    : name of the sub category
                                        (Optional)

            Returns:
            The scene as GdgScene or None.
        """
        lst = self.get_list_from_category(category)
        if sub_category != None:
            nlst = []
            for scene_name in lst:
                scene = self.__list[scene_name]
                if scene.sub_category == sub_category:
                    nlst.append(scene_name)
            lst = nlst
        if len(lst) > 0:
            scene_name = random.choice(lst)
            return self.get_scene(scene_name)
        else:
            return None

    def scene_exists(self, name):
        """
        Check if a scene name exists.

            Parameters:
            "name" as string  : name of the scene

            Returns:
            A boolean.
        """
        return self.__list.has_key(name)

    def get_scene(self, name):
        """
        Get a scene by her name.

            Parameters:
            "name" as string : name of the scene

            Returns:
            A scene as GdgScene or None
        """
        if self.__list.has_key(name):
            return self.__list[name]
        else:
            return None

    def play(self, name):
        """
        Play a scene.

            Parameters:
            "name" as string : name of the scene

            Returns:
            A boolean
        """
        if self.__play_mutex.locked():
            return False
        if self.__list.has_key(name):
            self.__current_scene = self.__list[name]
            self.__play_mutex.acquire()
            self.__list[name].play()
            self.__play_mutex.release()
            return True
        else:
            return False
            
    def stop(self):
        """
        Stop a scene
        """
        if self.__play_mutex.locked():
            if self.__current_scene != None:
                self.__current_scene.stop()

    def play_from_category(self, category, sub_category = None):
        """
        Play a scene randomly selected from a category.

            Parameters:
            "category" as string        : name of the category
            "sub_category" as string    : name of the sub category
                                        (Optional)

            Returns:
            A boolean.
        """
        if self.__play_mutex.locked():
            return False
        scene = self.get_scene_from_category(category)
        self.__current_scene = scene
        if scene != None:
            self.__play_mutex.acquire()
            scene.play()
            self.__play_mutex.release()
            return True
        else:
            return False

class GdgScenario(object):
    """
    Class which create an control a scenario.

        Global variables:
        "scenario.name" as string
        "scenario.author" as string
        "scenario.version" as string
        "scenario.description" as string
        "scenario.keywords" as list of string
        "scenario.category" as string
        "scenario.sub_category" as string
        "scenario.scenes" as GdgSceneContainer

        Functions list for the users:
        scenario.__init__
        scenario.play
    """

    def __init__(self, path):
        """
        Constructor of class.

            Parameters:
            "path" as string    : path of ".tdscenario" file
        """
        self.path = path.replace('%20', ' ')
        self.tmp_path = ''
        self.__script = []
        self.name = "Noname"
        self.author = "Noname"
        self.version = "0.0.0"
        self.description = "Nodescription"
        self.keywords = ('Nokeywords',)
        self.category = "common"
        self.sub_category = "common"
        self.scenes = GdgSceneContainer()
        self.__uncompress()
        self.__get_header()
        self.__parse_script()
        self.__get_scenes()
        self.__remove_tmp_path()

    def __uncompress(self):
        if not os.path.isfile(self.path):
            return
        if self.path.lower().find('.tdscenario') == -1:
            return
        (f_path, f_name) = os.path.split(self.path)
        f_dir = f_name.lower().replace('.tdscenario', '')
        d_path = '/tmp/scenario'
        self.tmp_path = d_path + '/' + f_dir
        if os.path.exists(self.tmp_path):
            os.system('rm -fR "%s"' % self.tmp_path)
        zf = zipfile.ZipFile(self.path, 'r')
        for name in zf.namelist():
            file_path = os.path.join(d_path, name)
            if not os.path.exists(os.path.dirname(file_path)):
                os.makedirs(os.path.dirname(file_path), 511)
            f = open(file_path, 'wb')
            f.write(zf.read(name))
            f.close()
        zf.close()

    def __get_header(self):
        global scenario_name
        global scenario_author
        global scenario_version
        global scenario_description
        global scenario_keywords
        global scenario_category
        global scenario_sub_catrgory
        scenario_name = "Noname"
        scenario_author = "Noname"
        scenario_version = "0.0.0"
        scenario_description = "Nodescription"
        scenario_keywords = ['Nokeywords',]
        scenario_category = "common"
        scenario_sub_category = "common"
        header_code = ""
        try:
            f = open(self.tmp_path + '/header', 'r')
            header_code = f.read()
            f.close()
        except:
            return
        try:
            exec str(header_code) in globals()
        except:
            pass
        self.name = scenario_name
        self.author = scenario_author
        self.version = scenario_version
        self.description = scenario_description
        self.keywords = scenario_keywords
        for i in range(len(self.keywords)):
            self.keywords[i] = self.keywords[i].lower()
        self.category = scenario_category
        self.sub_category = scenario_sub_category

    def __parse_script(self):
        self.__script = []
        try:
            f = open(self.tmp_path + '/body', 'r')
            for line in f:
                self.__script.append(line[:-1])
            f.close()
        except:
            return

    def __remove_tmp_path(self):
        if os.path.exists(self.tmp_path):
            os.system('rm -fR "%s"' % self.tmp_path)

    def __get_scenes(self):
        if not os.path.isdir(self.tmp_path + '/scenes'):
            return
        paths = os.listdir(self.tmp_path + '/scenes')
        for m_file in paths:
            if m_file.lower().find('.tsc') != -1:
                filepath = os.path.join(self.tmp_path + '/scenes', m_file)
                new_scene = GdgScene(filepath)
                self.scenes.insert(new_scene)

    def play(self):
        """
        Play the scenario.
        """
        global scenario
        scenario = self
        script = ""
        for line in self.__script:
            script += "%s\n" % line
        try:
            exec str(script) in globals()
        except:
            error_msg = 'SCENARIO ERROR [%s]' % self.name
            gadget_debug.insert_error(error_msg)

gadget_debug = GdgDebugger()
gui_up = GdgGuiUpdate()
scene_container = GdgSceneContainer()

class GdgVRManager(object):
    """
    Class which manages the voice recognition

        Functions list for the users:
        _me.voice_recognition.set_dict
        _me.voice_recognition.set_rules
        _me.voice_recognition.get_run
        _me.voice_recognition.push_dict
        _me.voice_recognition.pop_dict
        _me.voice_recognition.clear_dict
    """

    def __init__(self):
        self.__word_fifo = ['None', 'None', 'None']
        self._voice_rec_parametrize = VoiceRecParametrize(tux)
        self.__activity = False
        tux.micro.on_buffer.connect(self._voice_rec_parametrize.insert_buffer)
        _tux_head_switch.on_press.connect(self.__on_head_press)
        _tux_head_switch.on_release.connect(self.__on_head_release)
        self._voice_rec_parametrize.set_device(tux.hw.alsa_device)
        self._voice_rec_parametrize.set_run(False)
        self._voice_rec_parametrize.set_echo_word(False)
        self._voice_rec_matching = VoiceRecMatching()
        self._voice_rec_parametrize.on_parametrized_word = self._voice_rec_matching.match
        self._voice_rec_matching.on_matched_word = self.__on_word
        self.__dict_fifo = []
        self.__dict_fifo_mutex = threading.Lock()
        self.__current_dict = None
        self.__current_rules = []
        self.__event_thread_list = []
        self.__common_dict_entries = []
        self.__commom_rules = []
        
    def on(self):
        if os.path.basename(PATH_APP) == 'tux_framework':
            self.__activity = True
      
    def off(self):
        #tux.micro.off()
        self.__activity = False
        
    def set_echo_word(self, value):
        self._voice_rec_parametrize.set_echo_word(value)
        
    def insert_common_dict_entry(self, word, coeff):
        self.__dict_fifo_mutex.acquire()
        self.__common_dict_entries.append([word, coeff])
        self.__dict_fifo_mutex.release()
        
    def insert_common_rule(self, rule):
        self.__dict_fifo_mutex.acquire()
        self.__commom_rules.append(rule)
        self.__dict_fifo_mutex.release()

    def destroy(self):
        self.off()
        for t in self.__event_thread_list:
            if t.isAlive():
                print 'Join thread [%s]' % t.getName()
                t._Thread__stop()
                t.join()

    def __on_head_press(self):
        if not self.__activity:
            return
        tux.micro.on()
        tux.cmd.mouth_open()
        self._voice_rec_parametrize.set_run(True)

    def __on_head_release(self):
        if not self.__activity:
            return
        time.sleep(0.3)
        self._voice_rec_parametrize.set_run(False)
        time.sleep(0.2)
        tux.cmd.mouth_close()

    def push_dict(self):
        """
        Push the current word dictionary, and the current rules.
        """
        self.__dict_fifo_mutex.acquire()
        if self.__current_dict != None:
            t = copy(self.__current_dict)
            r = copy(self.__current_rules)
            self.__dict_fifo.append([t, r])
        self.__dict_fifo_mutex.release()

    def clear_dict(self):
        """
        Clear the current word dictionary, and the current rules.
        """
        self.__dict_fifo_mutex.acquire()
        self.__current_dict = None
        self.__current_rules = []
        self._voice_rec_matching.load_words('None')
        self.__dict_fifo_mutex.release()
        
    def set_default_dict_rules(self):
        self.__dict_fifo_mutex.acquire()
        for word_d in self.__common_dict_entries:
            self._voice_rec_matching.insert_word(word_d[0], word_d[1])
        for rule in self.__commom_rules:
            self.__current_rules.append(rule)
        self.__dict_fifo_mutex.release()

    def set_dict(self, dict_path, commons = True):
        """
        Set a word dictionary.

            Parameters:
            "dict_path" as string   : path of the dictionary
        """
        self.__dict_fifo_mutex.acquire()
        self.__current_dict = dict_path
        self._voice_rec_matching.load_words(self.__current_dict)
        if commons:
            for word_d in self.__common_dict_entries:
                self._voice_rec_matching.insert_word(word_d[0], word_d[1])
        self.__dict_fifo_mutex.release()

    def set_rules(self, rules):
        """
        Set a rules.

            Parameters:
            "rules" as list of list : rules
        """
        self.__dict_fifo_mutex.acquire()
        self.__current_rules = rules
        for rule in self.__commom_rules:
            self.__current_rules.append(rule)
        self.__dict_fifo_mutex.release()
        
    def assign_on_parametrized_word(self, funct = None):
        if funct == None:
            funct = self._voice_rec_matching.match
        self._voice_rec_parametrize.on_parametrized_word = funct

    def pop_dict(self):
        """
        Pop the last saved word dictionary, and the last saved rules.
        """
        self.__dict_fifo_mutex.acquire()
        if len(self.__dict_fifo) > 0:
            a = self.__dict_fifo.pop()
            self.__current_dict = a[0]
            self.__dict_fifo_mutex.release()
            self.set_dict(a[0])
            self.__dict_fifo_mutex.acquire()
            self.__current_rules = a[1]
        self.__dict_fifo_mutex.release()

    def __on_word(self, word):
        print 'Recognized word : %s' % word
        tux.cmd.leds_blink(6, 20)
        self.__word_fifo.append(word)
        self.__word_fifo.pop(0)
        for rule in self.__current_rules:
            if rule[0][0].lower() in ['none', self.__word_fifo[0].lower()] and\
                rule[0][1].lower() in ['none', self.__word_fifo[1].lower()] and\
                rule[0][2].lower() in ['none', self.__word_fifo[2].lower()]:
                if rule[1] != None:
                    t = threading.Thread(target = rule[1], args = rule[2])
                    t.start()
                    self.__event_thread_list.append(t)
                break

    def get_run(self):
        """
        Get the run state of the voice recognition.

            Returns:
            A boolean.
        """
        return self._voice_rec_parametrize.get_run()
        
    def set_run(self, value):
        self._voice_rec_parametrize.set_run(value)
        
    def echo(self):
        self._voice_rec_parametrize.echo()
        
    def get_word_in_current_dict(self, word):
        return self._voice_rec_matching.get_word(word)
        
    def save_words_of_current_dict(self):
        if not self._voice_rec_matching.word_exits('manager'):
            for word in self.__common_dict_entries:
                self._voice_rec_matching.remove_word(word[0])
        self._voice_rec_matching.save_words(self.__current_dict)
        
    def insert_word_in_current_dict(self, word, coeff):
        self._voice_rec_matching.insert_word(word, coeff)
        
    def replace_word_in_current_dict(self, word, coeff):
        self._voice_rec_matching.replace_word(word, coeff)
        
    def get_gadgets_word_dict(self):
        ret = {}
        for gdg in gadgets.keys():
            dict_path = gadgets[gdg].get_path('data') + '/rc_dict'
            if os.path.isfile(dict_path):
                ret[gdg] = dict_path
        return ret
        
    def get_word_list_of_current_dict(self):
        return self._voice_rec_matching.get_word_list()
        
    def set_dict_from_gadget(self, gadget_name):
        dict_path = gadgets[gadget_name].get_path('data') + '/rc_dict'
        if os.path.isfile(dict_path):
            self.set_dict(dict_path, False)

voice_rec_system = GdgVRManager()

class GdgNotificator(object):

    def __init__(self):
        self.__notify_fifo = []
        self.__fifo_mutex = threading.Lock()
        self.__current_actuate_pl = 0
        self.__current_framework_pl = 0
        self.__thread_actuate = None
        self.__fifo_thread = None
        self.run()

    def run(self):
        self.__fifo_thread = threading.Thread(target = self.__fifo_loop)
        self.__fifo_thread.start()

    def destroy(self):
        if self.__fifo_thread != None:
            self.__fifo_thread._Thread__stop()
            if self.__fifo_thread.isAlive():
                self.__fifo_thread.join()
        self.kill_actuate()

    def __fifo_loop(self):
        while True:
            if not voice_rec_system.get_run():
                self.pop()
            time.sleep(1.0)

    def push(self, actuate_funct, priority_level):
        self.__fifo_mutex.acquire()
        if self.__fifo_thread == None:
            self.__fifo_mutex.release()
            return
        self.__fifo_mutex.release()
        gadget_debug.insert_debug('NOTIFICATOR : Notification pushed with priority level (%s)' % priority_level)
        if priority_level > self.__current_actuate_pl:
            self.__fifo_mutex.acquire()
            self.__notify_fifo.insert(0, [actuate_funct, priority_level])
            self.__fifo_mutex.release()
            self.kill_actuate()
        else:
            index = -1
            self.__fifo_mutex.acquire()
            for i, act in enumerate(self.__notify_fifo):
                if actuate_funct == act[0]:
                    self.__fifo_mutex.release()
                    return
                if priority_level > act[1]:
                    index = i
                    break
            if index == -1:
                self.__notify_fifo.append([actuate_funct, priority_level])
            else:
                self.__notify_fifo.insert(index, [actuate_funct, priority_level])
            self.__fifo_mutex.release()

    def set_framework_priority(self, value):
        self.__current_framework_pl = value
        gadget_debug.insert_debug('NOTIFICATOR : Framework priority level (%s)' % value)

    def pop(self):
        self.__fifo_mutex.acquire()
        if self.__fifo_thread == None:
            self.__fifo_mutex.release()
            return
        if len(self.__notify_fifo) > 0:
            curr_actuate = self.__notify_fifo.pop(0)
        else:
            curr_actuate = None
        self.__fifo_mutex.release()
        if curr_actuate == None:
            return
        if curr_actuate[1] >= self.__current_framework_pl:
            self.__current_actuate_pl = curr_actuate[1]
            self.start_actuate(curr_actuate[0])
            self.__current_actuate_pl = 0
        else:
            if curr_actuate[1] > 0:
                if self.__thread_actuate != None:
                    time.sleep(2.0)
                self.push(curr_actuate[0], curr_actuate[1])

    def __actuate(self, funct):
        try:
            funct()
        except:
            error_msg = 'NOTIFICATION ERROR'
            gadget_debug.insert_error(error_msg)

    def start_actuate(self, funct):
        notify_mutex.acquire()
        tux.event.store()
        tux.event.clear()
        _tux_head_switch.store_events()
        _tux_head_switch.clear_events()
        _tux_lwing_switch.store_events()
        _tux_lwing_switch.clear_events()
        _tux_rwing_switch.store_events()
        _tux_rwing_switch.clear_events()
        _tux_head_switch.on_press.connect(self.kill_actuate)
        gadget_debug.insert_debug('NOTIFICATOR : Start notification')
        self.__thread_actuate = threading.Thread(target = self.__actuate, args = (funct,))
        self.__thread_actuate.start()
        if self.__thread_actuate.isAlive():
            self.__thread_actuate.join()
        self.__thread_actuate = None
        gadget_debug.insert_debug('NOTIFICATOR : Stop notification')
        _tux_head_switch.restore_events()
        _tux_lwing_switch.restore_events()
        _tux_rwing_switch.restore_events()
        tux.event.restore()
        notify_mutex.release()

    def kill_actuate(self):
        if self.__thread_actuate != None:
            tux.tts.stop()
            tux.wav.stop()
            self.__thread_actuate._Thread__stop()
            if self.__thread_actuate.isAlive():
                self.__thread_actuate.join()
            self.__thread_actuate = None

notificator = GdgNotificator()

def finalize():
    notificator.destroy()
    voice_rec_system.destroy()
    gui_up.destroy()
    gadget_debug.destroy()
    scene_container.destroy()
    tux.destroy()


class GdgObject(object):
    """
    Class which create and control a gadget.

        Objects in this class:
        "download" as instance of class(GdgDownload):
            Object which manages the download of files.
        "notify" as instance of class(GdgNotify):
            Object which create a notification controler.
        "example_gui" as instance of class(GdgGUI):
            Object which create and control a GUI.
            Possibles values for 'gui name':
                'widget'
                'conf'
        "voice_recognition" as instance of class(GdgVRManager):
            Object which manages the voice recognition.

        Additional functions and ressources:
            Create a GTK dialog box window:
                dialog = GdgDialog(title, message)
            Create a GTK dialog box window with a feed back:
                dialog = GdgDialogQuestion(title, message, funct_pt)
            Close a gadget
                _me.framework.close_gadget(gadget_name)
            Exclude a gadget from the framework
                _me.framework.exclude_gadget(gadget_name)
            Start a gadget
                _me.framework.start_gadget(gadget_path)
            Restart a gadget
                _me.framework.restart_gadget(gadget_name)
            Framework pointer
                _me.framework as pointer of FWObject
            Manager pointer
                _me.manager as pointer of GdgObject

        Functions list for the users:
            _me.__init__
            _me.destroy
            _me._print_debug
            _me.update_informations
            _me.main
            _me.run_main_loop
            _me.exit_main_loop
            _me.set_language
            _me.refresh_GUI
            _me.restore_GUI
            _me.string
            _me.get_name
            _me.get_author
            _me.get_version
            _me.get_description
            _me.get_path
            _me.get_icon
            _me.get_sound
            _me.get_lib
            _me.gui
            _me.insert_funct
            _me.get_funct
            _me.insert_sfunct
            _me.get_sfunct
            _me.get_var
            _me.set_var
            _me.get_param
            _me.set_param
            _me.speak
            _me.speak_free
            _me.speak_notification
            _me.wait_permission
            _me.insert_menu
            _me.remove_menu
    """

    def __init__(self, path, framework = None):
        """
        Constructor of class.

            Parameters:
            "path" as string    : Path of the TGF file
        """
        # Mutex
        self.__var_mutex = threading.Lock()
        self.__params_mutex = threading.Lock()
        self.__funct_mutex = threading.Lock()
        gadget_mutex.acquire()
        # Create a download object
        self.download = GdgDownload()
        # Create a TGF file controler and load it a file
        self._print_debug2('Init : create tgf object')
        self.tgfile = TGFormat()
        self._print_debug2('Init : open tgf file begin')
        gtk.gdk.threads_enter()
        if not self.tgfile.open(path, 'a'):
            gtk.gdk.threads_leave()
            return
        gtk.gdk.threads_leave()
        self._print_debug2('Init : open tgf file end')
        # Constants and paths dict. declaration and assignation
        self.cst = {}
        self.paths = {}
        self.__load_cst_paths()
        # Load behaviors
        self.__load_behaviors()
        # Variables declaration and assigation
        self.var = {}
        self.__load_vars()
        # Parameters declaration and assignation
        self.params = {}
        self.__load_params()
        # Strings declaration and assignation
        self.strings = {}
        self.__load_strings()
        # Functions container declaration
        self.funct = {}
        # Icons
        self.icons = {}
        # Sounds
        self.sounds = {}
        # Libs
        self.libs = {}
        self.__load_files_isl()
        # Framework reference
        self.framework = framework
        # Text filters
        self.text_filter = TextFilterContainer()
        self.text_filter.load_directory(self.get_path('filters'))
        # Threads container declaration
        self.my_threads = []
        # Main code declaration and assignation
        self.main_code = ''
        self.__make_main_code()
        # Alive flag declaration
        self.__alive = True
        # Exit signal declaration
        self.__exit_signal = False
        # Notification object
        self._print_debug2('Init : create notify object')
        self.notify = GdgNotify(self)
        # GUI declarations
        self._print_debug2('Init : load GUIs code')
        self.GUI = {}
        self.__load_GUIs()
        # *** Insert the gadget in the gadget container
        gadgets[self.cst['name']] = self
        self.manager = None
        # 'update_informations' methode overloading
        self.__make_update_informations()
        # 'init_gadget' methode overloading
        self.__make_init_gadget()
        # 'notify_checker' and 'notify_actuator' methodes overloading
        self.notify._overload_methodes()
        # Bind voice recognition
        self.voice_recognition = voice_rec_system
        # Create GUIs
        self._print_debug('Init : Create GUIs begin')
        for GUI in self.GUI.keys():
            self.GUI[GUI].create_GUI()
        self._print_debug('Init : Create GUIs end')
        self.example_gui = self.GUI['widget']
        # Init the gadget
        try:
            self.init_gadget()
        except:
            self._print_error('Init')
        # Start notifications
        #self.notify.start()
        gadget_mutex.release()

    def destroy(self):
        """
        This function destroy all objects and close the TGF file.
        """
        self._print_debug('Destroy : gadget_mutex.acquire')
        gadget_mutex.acquire()
        self.notify.destroy()
        self.__alive = False
        self._save_gui_context()
        if self.get_funct('destroy') != None:
            self.get_funct('destroy')()
        if self.get_funct('finalization') != None:
            self.get_funct('finalization')()
        remove_lst = []
        for name in scene_container.get_list():
            scene = scene_container.get_scene(name)
            if scene.tsc_filename.find(self.get_path('root')) != -1:
                remove_lst.append(name)
        for name in remove_lst:
            scene_container.remove(name)

        gadget_mutex.release()
        for gui_name in self.GUI.keys():
            self.GUI[gui_name].destroy()
        gadget_mutex.acquire()
        self._save_params()
        self._save_vars()
        self._print_debug('Threads join : Start')
        for t in self.my_threads:
            self._print_debug('Threads join : (%s)' % t.getName())
            try:
                if t.isAlive():
                    t._Thread__stop()
                    t.join()
            except:
                self._print_error('my_threads join')
        self._print_debug('Threads join : Finish')
        self.my_threads = []
        self._print_debug('TGF file close begin')
        gtk.gdk.threads_enter()
        self.tgfile.close()
        gtk.gdk.threads_leave()
        self._print_debug('TGF file close end')
        self._print_debug('Destroy : gadget_mutex.release')
        gadget_mutex.release()

    # ------------------------------------------------------------------------
    # Private methodes of this class
    # ------------------------------------------------------------------------

    def __load_cst_paths(self):
        """
        Load the constants and the paths
        """
        self.cst['name'] = self.tgfile.parser.about.get_name()
        self.cst['author'] = self.tgfile.parser.about.get_author()
        self.cst['version'] = self.tgfile.parser.about.get_version()
        self.cst['description'] = self.tgfile.parser.about.get_description()
        self.paths['tgf'] = self.tgfile.c_path
        self.paths['root'] = self.tgfile.d_path
        self.paths['data'] = self.tgfile.d_path + '/Data'
        self.paths['sounds'] = self.tgfile.d_path + '/Sounds'
        self.paths['pictures'] = self.tgfile.d_path + '/Pictures'
        self.paths['GUI'] = self.tgfile.d_path + '/Scripts/Python/GUI'
        self.paths['libs'] = self.tgfile.d_path + '/Scripts/Python'
        self.paths['behaviors'] = self.tgfile.d_path + '/Data/Behaviors'
        self.paths['filters'] = self.tgfile.d_path + '/Data/Filters'
        if not os.path.exists(self.paths['data']): os.makedirs(self.paths['data'], 511)
        if not os.path.exists(self.paths['behaviors']): os.makedirs(self.paths['behaviors'], 511)
        if not os.path.exists(self.paths['filters']): os.makedirs(self.paths['filters'], 511)

    def __load_behaviors(self):
        """
        Load the behaviors
        """
        m_list = os.listdir(self.paths['behaviors'])
        for m_file in m_list:
            m_file = os.path.join(self.paths['behaviors'], m_file)
            if os.path.isfile(m_file):
                if m_file.lower().find('.tsc') != -1:
                    scene = GdgScene(m_file, self)
                    scene_container.insert(scene)

    def __load_vars(self):
        """
        Load the variables
        """
        self.var['language'] = self.tgfile.parser.settings.get_general_value('language')
        self.var['pitch'] = self.tgfile.parser.settings.get_general_value('pitch')
        self.var['notified'] = self.tgfile.parser.settings.get_general_value('notified')
        self.var['notify_delay'] = self.tgfile.parser.settings.get_general_value('notify_delay')
        self.var['menu_active'] = self.tgfile.parser.settings.get_general_value('menu_active')
        lng = self.var['language']
        self.var['name_to_read'] = self.tgfile.parser.i18n.get_message_value_dict('name_to_read')[lng]
        self.var['speaker'] = self.tgfile.parser.settings.get_general_value('speaker')
        self.var['gui_state'] = self.tgfile.parser.settings.get_general_value('gui_state')
        if self.var['gui_state'] == None:
            self.var['gui_state'] = {}
        self.var['main_priority'] = self.tgfile.parser.settings.get_general_value('main_priority')
        if self.var['main_priority'] == None:
            self.var['main_priority'] = 4
            self.tgfile.parser.settings.set_general_value('main_priority', 4)
        self.var['notify_priority'] = self.tgfile.parser.settings.get_general_value('notify_priority')
        if self.var['notify_priority'] == None:
            self.var['notify_priority'] = 4
            self.tgfile.parser.settings.set_general_value('notify_priority', 4)
        self.var['have_main_part'] = self.tgfile.parser.settings.get_general_value('have_main_part')
        if self.var['have_main_part'] == None:
            self.var['have_main_part'] = True
            self.tgfile.parser.settings.set_general_value('have_main_part', True)
        self.var['have_settings_part'] = self.tgfile.parser.settings.get_general_value('have_settings_part')
        if self.var['have_settings_part'] == None:
            self.var['have_settings_part'] = True
            self.tgfile.parser.settings.set_general_value('have_settings_part', True)
        self.var['have_widget_part'] = self.tgfile.parser.settings.get_general_value('have_widget_part')
        if self.var['have_widget_part'] == None:
            self.var['have_widget_part'] = True
            self.tgfile.parser.settings.set_general_value('have_widget_part', True)

    def _save_vars(self):
        """
        Save the variables
        """
        self.tgfile.parser.settings.set_general_value('language',
            self.var['language'])
        self.tgfile.parser.settings.set_general_value('pitch',
            self.var['pitch'])
        self.tgfile.parser.settings.set_general_value('notified',
            self.var['notified'])
        self.tgfile.parser.settings.set_general_value('notify_delay',
            self.var['notify_delay'])
        self.tgfile.parser.settings.set_general_value('menu_active',
            self.var['menu_active'])
        self.tgfile.parser.settings.set_general_value('speaker',
            self.var['speaker'])
        self.tgfile.parser.settings.set_general_value('gui_state',
            self.var['gui_state'])
        self.tgfile.parser.settings.set_general_value('main_priority',
            self.var['main_priority'])
        self.tgfile.parser.settings.set_general_value('notify_priority',
            self.var['notify_priority'])

    def __load_params(self):
        """
        Load the parameters
        """
        for p_name in self.tgfile.parser.settings.get_parameters_list():
            self.params[p_name] = self.tgfile.parser.settings.get_parameter_value(p_name)

    def _save_params(self):
        """
        Save the parameters
        """
        for p_name in self.tgfile.parser.settings.get_parameters_list():
            self.tgfile.parser.settings.set_parameter_value(p_name, self.params[p_name])

    def __load_strings(self):
        """
        Load the strings
        """
        lng = self.var['language']
        self.strings = self.tgfile.parser.i18n.languages_struct[lng]['strings']

    def __load_files_isl(self):
        """
        Load the icons, sounds and libs
        """
        self.icons = self.tgfile.parser.icons.struct
        self.sounds = self.tgfile.parser.sounds.struct
        self.libs = self.tgfile.parser.libs.struct

    def __load_GUIs(self):
        """
        Load the GUIs
        """
        for gui_name in self.tgfile.parser.GUI.struct.keys():
            pyp_code = self.tgfile.parser.GUI.struct[gui_name]
            self.GUI[gui_name] = GdgGUI(self, gui_name, True, pyp_code)

    def __make_main_code(self):
        """
        Make the main code of the gadget
        """
        self.main_code = self.tgfile.parser.scripts.struct['main']
        # replace '_me.' by "gadgets['%s']." % self.cst['name']
        me_str = "gadgets['%s']." % self.cst['name']
        self.main_code = self.main_code.replace('_me.', me_str)

    def __make_init_gadget(self):
        """
        Overload the 'init_gadget' function with the taked code
        from 'init.pyp' file
        """
        init_gadget_code = self.tgfile.parser.scripts.struct['init']
        if init_gadget_code == '': return
        # replace '_me.' by "gadgets['%s']." % self.cst['name']
        me_str = "gadgets['%s']." % self.cst['name']
        init_gadget_code = init_gadget_code.replace('_me.', me_str)
        up_splited = init_gadget_code.split('\n')
        init_gadget_code = 'def init_gadget():\n'
        for line in up_splited:
            init_gadget_code = init_gadget_code + '    ' + line + '\n'
        init_gadget_code = init_gadget_code +\
        "gadgets['%s'].init_gadget = init_gadget" % self.cst['name']
        if init_gadget_code[0] == 'd':
            exec str(init_gadget_code) in globals()

    def __make_update_informations(self):
        """
        Create the function to update the informations
        """
        update_info_code = self.tgfile.parser.scripts.struct['main']
        self._overload_internal_function(update_info_code,
                'update_informations', 'update_informations')

    def _save_gui_context(self):
        """
        Save the GUI context of the gadget
        """
        for gui_name in self.GUI.keys():
            gui_state = {}
            gui_state['visible'] = self.GUI[gui_name].showed()
            self.var['gui_state'][gui_name] = gui_state

    # ------------------------------------------------------------------------
    # System functions. Shared with others class of this module
    # ------------------------------------------------------------------------

    def _overload_internal_function(self, src_code, function_name, methode_dest):
        """
        Overload an internal function with a script take from a TGF file
        """
        # replace '_me.' by "gadgets['%s']." % self.cst['name']
        me_str = "gadgets['%s']." % self.cst['name']
        src_code = src_code.replace('_me.', me_str)
        up_splited = src_code.split('\n')
        src_code = ''
        matched = False
        for line in up_splited:
            if line.find('def %s' % function_name) == 0:
                matched = True
                src_code = src_code + line + '\n'
                continue
            if matched:
                if len(line) > 0:
                    if line[0] not in [' ', '\t', '#']:
                        matched = False
                        break
                src_code = src_code + line + '\n'
        src_code = src_code +\
        "gadgets['%s'].%s = %s" % (self.cst['name'], methode_dest, function_name)
        if src_code[0] == 'd':
            try:
                exec str(src_code) in globals()
            except:
                self._print_error("(_overload_internal_function) %s" % methode_dest)

    def _print_error(self, message):
        """
        To print a formatted error message
        """
        error_msg = 'GADGET ERROR [%s] : %s' % (self.cst['name'], message)
        error_msg = "%s\n\t%s" % (error_msg, str(sys.exc_info()))
        gadget_debug.insert_error(error_msg)
        if debug_on_terminal:
            print error_msg

    def _print_debug(self, message):
        """
        To print a formatted debug message.

            Parameters:
            "messsage" as string    : Message to print
        """
        debug_msg = 'GADGET DEBUG [%s] : %s' % (self.cst['name'], message)
        gadget_debug.insert_debug(debug_msg)
        if debug_on_terminal:
            print debug_msg

    def _print_debug2(self, message):
        """
        To print a formatted debug message.

            Parameters:
            "messsage" as string    : Message to print
        """
        debug_msg = 'GADGET DEBUG [] : %s' % message
        gadget_debug.insert_debug(debug_msg)
        if debug_on_terminal:
            print debug_msg

    # -----------------------------------------------------------------------
    # Overloaded functions
    # -----------------------------------------------------------------------

    def init_gadget(self):
        """
        Function to init the gadget.
        """
        pass

    def update_informations(self):
        """
        Function to update the informations picked by the gadget.
        This function is overloaded when the gadget is
        initialized. If a function named 'update_informations'
        was found in the 'main.pyp' of the loaded TGF file, his
        code is inserted in this function.
        The parameters and the returned values depends of the
        overloaded function.
        """
        pass

    def main(self):
        """
        Main function of the gadget.
        This function is overloaded with the code found in the
        'main.pyp' file of the TFG file.
        """
        if gadget_mutex.locked():
            return
        if notify_mutex.locked():
            return
        self._print_debug('Main : gadget_mutex.acquire')
        gadget_mutex.acquire()
        save_K_MENU = tux.event.on_remote_bt[K_MENU]
        tux.event.store()
        tux.event.clear()
        self.voice_recognition.push_dict()
        self.voice_recognition.clear_dict()
        if os.path.isfile(self.get_path('data') + '/rc_dict'):
            self.voice_recognition.set_dict(self.get_path('data') + '/rc_dict')
        else:
            self.voice_recognition.set_default_dict_rules()
        tux.event.on_remote_bt[K_MENU] = save_K_MENU
        try:
            exec str(self.main_code) in globals()
        except:
            self._print_error('Main')
        self.voice_recognition.pop_dict()
        tux.event.restore()
        self._print_debug('Main : gadget_mutex.release')
        gadget_mutex.release()

    # -----------------------------------------------------------------------
    # Public functions
    # -----------------------------------------------------------------------

    # Functions to control the loop in the main of gadget
    def run_main_loop(self):
        """
        Function to run a blocking loop. The loop is stopped when
        the function 'exit_main_loop' is excecuted from an other
        thread.
        """
        self.__exit_signal = False
        while True:
            time.sleep(0.1)
            if not self.__alive:
                break
            if self.__exit_signal:
                break

    def exit_main_loop(self):
        """
        Function to stop the blocking loop run by the function
        'run_main_loop'.
        """
        self.__exit_signal = True

    # Function to change the language of the gadget
    def set_language(self, lang_country):
        """
        Set the language of the gadget.

            Parameters:
            "lang_country" as string    : Language of the gadget in
                                          "lang_country" format.
                                          See TGFParser.
        """
        self.var['language'] = lang_country
        if not f_language_dict.has_key(lang_country):
            self.var['language'] = 'en_US'
        if not lang_country in self.tgfile.parser.i18n.get_languages_list():
            self.var['language'] = 'en_US'
        lng = self.var['language']
        self.var['name_to_read'] = self.tgfile.parser.i18n.get_message_value_dict('name_to_read')[lng]
        spk_name = self.tgfile.parser.i18n.get_message_value_dict('speaker_name')[lng]
        self.var['speaker'] = SPK_US_MALE
        for i, name in enumerate(SPK_NAMES_LIST):
            if name == spk_name:
                self.var['speaker'] = i + 1
                break
        self.__load_strings()

    # Functions to control the GUI
    def refresh_GUI(self):
        """
        Refresh the graphical user interfaces of the gadget.
        """
        for GUI in self.GUI.keys():
            self.GUI[GUI].refresh()

    def restore_GUI(self, threads_protected = True):
        """
        Restore the context of the graphical user interfaces.

            Parameters:
            "threads_protected" as boolean  : Indicate if a GTK threads
                                              protection is needed.

            Comments:
            If this function is loaded from a thread, you must set
            the 'threads_protected' value to 'True'.
        """
        return
        # Restore the state of the GUI
        if self.var['gui_state'] == None : return
        for gui_name in self.var['gui_state'].keys():
            if self.GUI.has_key(gui_name):
                gui_state = self.var['gui_state'][gui_name]
                if self.GUI[gui_name].showed() != gui_state['visible']:
                    if not self.GUI[gui_name].showed():
                        self._print_debug('GUI : Show (%s) tp' % gui_name)
                        self.GUI[gui_name].show(threads_protected)
                        timeout_idx = 0
                        while not self.GUI[gui_name].showed():
                            time.sleep(0.1)
                            timeout_idx = timeout_idx + 1
                            if timeout_idx >= 30:
                                self._print_error('GUI (%s).show()' % gui_name)
                                break
                    else:
                        self.GUI[gui_name].hide()

    # Function to get a translated string message
    def string(self, msg_name):
        """
        Get a string from the strings dictionary.

            Parameters:
            "msg_name" as string        : Name of the message

            Returns:
            A string.

            Comments:
            If the entry in the dictionary is a list of strings,
            the returned value is a random value from this list.
        """
        if self.strings.has_key(msg_name):
            if str(type(self.strings[msg_name])) == "<type 'list'>":
                return random.choice(self.strings[msg_name])
            elif str(type(self.strings[msg_name])) == "<type 'str'>":
                return self.strings[msg_name]
            else:
                return ''
        else:
            return ''

    # -----------------------------------------------------------------------
    # Variables manages
    # -----------------------------------------------------------------------

    def get_name(self):
        """
        Get the name of the gadget.

            Returns:
            A string
        """
        return self.cst['name']

    def get_author(self):
        """
        Get the author of the gadget.

            Returns:
            A string
        """
        return self.cst['author']

    def get_version(self):
        """
        Get the version of the gadget.

            Returns:
            A string
        """
        return self.cst['version']

    def get_description(self):
        """
        Get the description of the gadget.

            Returns:
            A string
        """
        return self.cst['description']

    def get_path(self, path_name):
        """
        Get a path from the 'paths' dictionary.

            Parameters:
            "path_name" as string   : Name of the path

            Returns:
            A string.

            Comments:
            Possible values of "path_name" are:
                'tgf'          : Path of the TGF source file
                'root'         : Root path of the decompressed TGF
                'data'         : Path of 'data'
                'sounds'       : Path of 'sounds'
                'pictures'     : Path of 'pictures'
                'GUI'          : Path of the graphical user interfaces
                'libs'         : Path of the python libraries
                'behaviors'    : Path of 'behaviors'
        """
        if str(type(path_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid path name' % path_name)
            return self.paths['root']
        if not self.paths.has_key(path_name):
            self._print_error('(%s) is not a valid path name' % path_name)
            return self.paths['root']
        return self.paths[path_name]

    def get_icon(self, icon_name):
        """
        Get the path of an icon.

            Parameters:
            "icon_name" as string   : Name of the icon

            Returns:
            The file path of the icon as string.
        """
        if str(type(icon_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid icon name' % icon_name)
            return ''
        if not self.icons.has_key(icon_name):
            self._print_error('(%s) is not a valid icon name' % icon_name)
            return ''
        return self.icons[icon_name]

    def get_sound(self, sound_name):
        """
        Get the path of a sound.

            Parameters:
            "sound_name" as string   : Name of the sound

            Returns:
            The file path of the sound as string.
        """
        if str(type(sound_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid sound name' % sound_name)
            return ''
        if not self.sounds.has_key(sound_name):
            self._print_error('(%s) is not a valid sound name' % sound_name)
            return ''
        return self.sounds[sound_name]

    def get_lib(self, lib_name):
        """
        Get the path of a library.

            Parameters:
            "lib_name" as string   : Name of the library

            Returns:
            The path of the library as string.
        """
        if str(type(lib_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid library name' % lib_name)
            return ''
        if not self.libs.has_key(lib_name):
            self._print_error('(%s) is not a valid library name' % lib_name)
            return ''
        return self.libs[lib_name]

    def gui(self, gui_name):
        """
        Get a graphical user interface of the gadget.

            Parameters:
            "window_name" as string   : Name of the GUI

            Returns:
            The GUI object as GdgGUI
        """
        if str(type(gui_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid GUI name' % gui_name)
            return None
        if not self.GUI.has_key(gui_name):
            self._print_error('(%s) is not a valid GUI name' % gui_name)
            return None
        return self.GUI[gui_name]

    def get_funct(self, funct_name):
        """
        Get the pointer of a function.

            Parameters:
            "funct_name" as string  : Name of the function

            Returns:
            Pointer as function.
        """
        try:    
            self.__funct_mutex.acquire()
        except:
            self._print_error('get_funct("%s") access error' % funct_name)
        if str(type(funct_name)) != "<type 'str'>":
            self._print_debug('(%s) is not a valid function name' % funct_name)
            self.__funct_mutex.release()
            return None
        if not self.funct.has_key(funct_name):
            self._print_debug('(%s) is not a valid function name' % funct_name)
            self.__funct_mutex.release()
            return None
        value = self.funct[funct_name]
        self.__funct_mutex.release()
        return value
        
    def insert_sfunct(self, funct_name, value):
        """
        Insert a shared function.

            Parameters:
            "funct_name" as string         : Name of the function
            "value" as pointer of function : Target function
            
            Returns:
            A boolean.
        """
        if str(type(value)) != "<type 'function'>":
            self._print_error('(%s) is not a valid function' % str(value))
            return False
        if str(type(funct_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid function name' % funct_name)
            return False
        if value.__doc__ == None:
            return False
        doc_str = value.__doc__
        funct = [value, self, doc_str]
        if not shared_functions.has_key(funct_name):
            shared_functions[funct_name] = funct
            return True
        return False
        
    def get_sfunct(self, funct_name):
        """
        Get the pointer of a shared function.

            Parameters:
            "funct_name" as string  : Name of the function

            Returns:
            Pointer as function.
        """
        try:    
            self.__funct_mutex.acquire()
        except:
            self._print_error('get_sfunct("%s") access error' % funct_name)
        if str(type(funct_name)) != "<type 'str'>":
            self._print_debug('(%s) is not a valid function name' % funct_name)
            self.__funct_mutex.release()
            return None
        if not shared_functions.has_key(funct_name):
            self._print_debug('(%s) is not a valid function name' % funct_name)
            self.__funct_mutex.release()
            return None
        value = shared_functions[funct_name][0]
        self.__funct_mutex.release()
        return value

    def insert_funct(self, funct_name, value):
        """
        Insert a function.

            Parameters:
            "funct_name" as string         : Name of the function
            "value" as pointer of function : Target function
        """
        try:    
            self.__funct_mutex.acquire()
        except:
            self._print_error('insert_funct("%s") access error' % funct_name)
        if str(type(funct_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid function name' % funct_name)
            self.__funct_mutex.release()
            return
        self.funct[funct_name] = value
        self.__funct_mutex.release()
        return

    def get_var(self, var_name):
        """
        Get the value of a variable.

            Parameters:
            "var_name" as string   : Name of the variable

            Returns:
            The value of the variable.

            Possible values of "var_name" are:
                'language'       : Current language of the gadget
                                   in "lang_country" format. See TGFParser
                'pitch'          : Current TTS pitch
                'notified'       : Current state of notifications
                'notify_delay'   : Delay between 2 notifications
                'menu_active'    : Current state of the menu insertion
                'name_to_read'   : Current translation of the gadget name
                'speaker'        : Current TTS speaker
        """
        self.__var_mutex.acquire()
        if str(type(var_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid variable name' % var_name)
            self.__var_mutex.release()
            return None
        if not self.var.has_key(var_name):
            self._print_error('(%s) is not a valid variable name' % var_name)
            self.__var_mutex.release()
            return None
        value = self.var[var_name]
        self.__var_mutex.release()
        return value

    def set_var(self, var_name, value):
        """
        Set the value of a variable.

            Parameters:
            "var_name" as string   : Name of the variable
            "value" as untyped     : Value of the variable

            Possible values of "var_name" are:
                'language'       : Current language of the gadget
                                   in "lang_country" format. See TGFParser
                'pitch'          : Current TTS pitch
                'notified'       : Current state of notifications
                'notify_delay'   : Delay between 2 notifications
                'menu_active'    : Current state of the menu insertion
                'name_to_read'   : Current translation of the gadget name
                'speaker'        : Current TTS speaker
        """
        self.__var_mutex.acquire()
        if str(type(var_name)) != "<type 'str'>":
            self._print_error('(%s) is not a valid variable name' % var_name)
            self.__var_mutex.release()
            return
        #if not self.var.has_key(var_name):
        #    self.var[var_name] = value
        #    self.__var_mutex.release()
        #    return
        #if str(type(value)) != str(type(self.var[var_name])):
        #    self._print_error('Invalid variable value for (%s)' % var_name)
        #    self.__var_mutex.release()
        #    return
        self.var[var_name] = value
        self.__var_mutex.release()
        return

    def get_param(self, param_name):
        """
        Get the value of a parameter.

            Parameters:
            "param_name" as string   : Name of the parameter

            Returns:
            The value of the parameter.
        """
        self.__params_mutex.acquire()
        if str(type(param_name)) != "<type 'str'>":
            self._print_debug('(%s) is not a valid parameter name' % param_name)
            self.__params_mutex.release()
            return None
        if not self.params.has_key(param_name):
            self._print_debug('(%s) is not a valid parameter name' % param_name)
            self.__params_mutex.release()
            return None
        value = self.params[param_name]
        self.__params_mutex.release()
        return value

    def set_param(self, param_name, value):
        """
        Set the value of a parameter.

            Parameters:
            "param_name" as string   : Name of the parameter
            "value" as untyped       : Value of the parameter
        """
        self.__params_mutex.acquire()
        if str(type(param_name)) != "<type 'str'>":
            self._print_debug('(%s) is not a valid parameter name' % param_name)
            self.__params_mutex.release()
            return
        #if not self.params.has_key(param_name):
        #    self.params[param_name] = value
        #    self.__params_mutex.release()
        #    return
        #if str(type(value)) != str(type(self.params[param_name])):
        #    self._print_error('Invalid parameter value for (%s)' % param_name)
        #    self.__params_mutex.release()
        #    return
        self.params[param_name] = value
        self.__params_mutex.release()
        return

    def insert_manager_tray_menu(self, name, funct, menu_type, active_state, stock_id, to_menu_name = 'options'):
        """
        Deprecated
        """
        if not gadgets.has_key('Manager'):
            return False
        gadgets['Manager'].get_param('tray_menu').insert_menu_item(name,
                funct, menu_type, active_state, stock_id, self, to_menu_name)
        return True
        
    def insert_menu(self, name, funct, menu_type, active_state, stock_id, to_menu_name = 'options'):
        """
        Insert an item in the 'Options' menu of the manager.

            Parameters:
            "name" as string                : Name of the item
            "funct" as pointer of function  : Function to launch on item event
            "menu_type" as string           : Menu item type
                                              <'image', 'check', 'separator'>
            "active_state" as boolean       : State of checkbox for 'check' type
            "stock_id" as GTK Stock ID type : GTK Stock id for 'image' type
        """
        return self.insert_manager_tray_menu(name, funct, menu_type, active_state, stock_id, to_menu_name)

    def remove_manager_tray_menu(self):
        """
        Deprecated
        """
        if not gadgets.has_key('Manager'):
            return False
        gadgets['Manager'].get_param('tray_menu').remove_menu_item_by_gadget(self)
        return True
        
    def remove_menu(self):
        """
        Remove manager menu items created by this gadget.
        """
        return self.remove_manager_tray_menu()

    def speak_notification(self, text):
        """
        Speak a text from the notification part.

            Parameters:
            "text" as string                : Text to speak

            Comment:
            Only use it in the 'notify_actuate' function of 'notify.pyp'.
        """
        tux.tts.stop()
        self._print_debug('speak_notification : tts_mutex.acquire')
        tts_mutex.acquire()
        tux.tts.select_voice(self.var['speaker'], self.var['pitch'])
        tux.tts.speak(text)
        self._print_debug('speak_notification : tts_mutex.release')
        tts_mutex.release()

    def speak(self, text):
        """
        Speak a text.

            Parameters:
            "text" as string                : Text to speak

            Comments:
            Do not use it in the 'notify_actuate' function of 'notify.pyp'.
        """
        self._print_debug('Speak : notify_mutex.acquire')
        notify_mutex.acquire()
        self._print_debug('Speak : notify_mutex.release')
        notify_mutex.release()
        self._print_debug('Speak : tts_mutex.acquire')
        tts_mutex.acquire()
        self._print_debug('Speak : tts_mutex.release')
        tux.tts.select_voice(self.var['speaker'], self.var['pitch'])
        tts_mutex.release()
        tux.tts.speak(text)

    def speak_free(self, text):
        """
        Speak a text in asynchronous mode.

            Parameters:
            "text" as string                : Text to speak

            Comments:
            Do not use it in the 'notify_actuate' function of 'notify.pyp'.
        """
        self._print_debug('Speak_free : notify_mutex.acquire')
        notify_mutex.acquire()
        self._print_debug('Speak_free : notify_mutex.release')
        notify_mutex.release()
        self._print_debug('Speak_free : tts_mutex.acquire')
        tts_mutex.acquire()
        self._print_debug('Speak_free : tts_mutex.release')
        tux.tts.select_voice(self.var['speaker'], self.var['pitch'])
        tts_mutex.release()
        tux.tts.speak_free(text)

    def wait_permission(self):
        """
        Wait a permission to continue.
        """
        self._print_debug('Wait_permission : notify_mutex.acquire')
        notify_mutex.acquire()
        self._print_debug('Wait_permission : notify_mutex.release')
        notify_mutex.release()

    def async(self, function, argss):
        t = threading.Thread(target = function, args = argss)
        t.setName('Async')
        t.start()
        self.my_threads.append(t)


class GdgNotify(object):
    """
    Class which create a notification controler.

        Functions list for the users:
            _me.notify.start
            _me.notify.stop
            _me.notify.set_active
            _me.notify.set_delay
            _me.notify.check_now
    """

    def __init__(self, parent):
        """
        Constructor
        """
        self.parent = parent
        self.notify_checker_code = ''
        self.notify_actuator_code = ''
        self.notify_started = False
        self.running = False
        self.check_result = False
        self.check_mutex = threading.Lock()
        self.__my_threads = []
        self.parent._print_debug('Notification object initialized')

    def destroy(self):
        """
        Destructor
        """
        self.stop()
        self.__threads_join()
        self.parent._print_debug('Notification object destroyed')

    def __threads_join(self):
        self.parent._print_debug('Notify threads join : Start')
        for i, t in enumerate(self.__my_threads):
            if t.isAlive():
                t._Thread__stop()
                self.parent._print_debug('Notify threads join : (%s)' % t.getName())
                t.join()
            self.__my_threads.pop(i)
        self.parent._print_debug('Notify threads join : Finish')

    def _overload_methodes(self):
        """
        Overload the methodes of this class
        """
        self.__make_notify_checker_code()
        self.__make_notify_actuator_code()

    def __make_notify_checker_code(self):
        """
        Make the 'notify_checker' code
        """
        npyp = self.parent.tgfile.parser.scripts.struct['notify']
        self.parent._overload_internal_function(npyp, 'notify_checker',
            'notify._checker')

    def __make_notify_actuator_code(self):
        """
        Make the 'notify_actuator' code
        """
        npyp = self.parent.tgfile.parser.scripts.struct['notify']
        self.parent._overload_internal_function(npyp, 'notify_actuator',
            'notify._actuator')

    def _checker(self):
        """
        Check the condition
        """
        exec str(self.notify_checker_code) in globals()
        return self.check_result

    def _actuator(self):
        """
        Actuate
        """
        exec str(self.notify_actuator_code) in globals()

    def start(self):
        """
        Start the loop of (ckeck - actuate) notification.

            Comments:
            The loop is started on the initialization of the
            class.
        """
        if self.notify_started: return
        t = threading.Thread(target = self.__loop)
        t.setName('Gadget notification loop "%s"' % self.parent.cst['name'])
        t.start()
        self.__my_threads.append(t)

    def stop(self):
        """
        Stop the loop of (ckeck - actuate) notification.
        """
        self.notify_started = False

    def __loop(self):
        """
        Loop of checking, actuate, waiting
        """
        self.running = True
        self.notify_started = True
        # Wait 2 seconds before loading the loop
        #time.sleep(5)
        # Start the loop
        while self.notify_started:
            # If notification activate
            if self.parent.var['notified']:
                # Check the notification
                if not self.check_now(): break
            # Get the delay
            try:
                delay = self.parent.var['notify_delay']
            except:
                delay = 1
            delay = delay * 10
            # Wait
            for i in range(delay):
                if not self.notify_started:
                    break
                time.sleep(0.1)
        self.notify_started = False
        self.running = False

    def set_active(self, value = True):
        """
        Set the state of the notification loop.

            Parameters:
            "value" as boolean      : State
        """
        self.parent.var['notified'] = value
        if value:
            if not self.notify_started:
                self.start()
        else:
            if self.notify_started:
                self.stop()

    def set_delay(self, value):
        """
        Set the delay between two cycles of the loop.

            Parameters:
            "value" as integer  : Delay in seconds
        """
        self.parent.var['notify_delay'] = value

    def check_now(self):
        """
        Run a cycle of (ckeck - actuate) now.
        """
        if self.check_mutex.locked():
            return
        self.check_mutex.acquire()
        # Check the notification
        self.check_result = False
        try:
            ret = self._checker()
        except:
            ret = False
            self.parent._print_error("notify_checker")
            self.stop()
        if ret:
            if not self.notify_started:
                self.check_mutex.release()
                return False
            # Execution of the notify actuator
            self.parent._print_debug("Notification request")
            notificator.push(self._actuator, self.parent.var['notify_priority'])
        self.check_mutex.release()
        return True

class GdgGUI(object):
    """
    Class which create and control a GUI.

        Functions list for the users:
            _me.gui('widget').showed
            _me.gui('widget').show
            _me.gui('widget').show_from_main
            _me.gui('widget').hide
            _me.gui('widget').hide_from_main
            _me.gui('widget').refresh
    """

    def __init__(self, parent, prefix, present, pyp_code):
        """
        Constructor
        """
        self.parent = parent
        self.present = present
        self.window = None
        self.prefix = prefix
        self.window_class_name = '%s%sWindow' % (self.parent.cst['name'].replace(' ', '_'),
                                           prefix)
        self.pyp_code = pyp_code

    def destroy(self):
        """
        Destructor
        """
        #self.hide()
        self.__hide(True, False)

    def create_GUI(self):
        """
        Create the GUI class if allowed
        """
        if self.present:
            self.__make_gui_class()

    def __make_gui_class(self):
        """
        Create the GUI class and load it
        """
        # Get the code of gui.pyp
        cpyp = self.pyp_code
        # Replace '_me.' by 'gadgets['<my name>'].'
        repl_str = "gadgets['%s']." % self.parent.cst['name']
        cpyp = cpyp.replace('_me.', repl_str)
        # Rename the class of the GUI
        repl_str = 'class %s(SimpleGladeApp):' % self.window_class_name
        cpyp = cpyp.replace('class Window(SimpleGladeApp):', repl_str)
        # Load the class
        try:
            exec str(cpyp) in globals()
        except:
            self.parent._print_error("GUI class (%s) declaration" % self.window_class_name)
            self.present = False

    def showed(self):
        """
        Indicate if the GUI is showed or not.

            Returns:
            A boolean
        """
        if self.window == None:
            return False
        else:
            if self.window.get_widget("window1") == None:
                return False
            else:
                return True

    def show(self, threads_protected = True):
        """
        Create an instance of the window and show it.
        """
        gui_up.insert(self.__show, (False, False))

    def show_from_main(self):
        """
        Create an instance of the window and show it, from 'main.pyp'.
        """
        #thread.start_new_thread(self.__show, (True, True))
        t = threading.Thread(target = self.__show, args = (True, True))
        t.setName('Show from main "%s"' % self.parent.cst['name'])
        t.start()
        self.parent.my_threads.append(t)

    def __show(self, threads_protected = True, no_mutex = False):
        """
        Create a window and show it
        """
        def on_delete(widget, *args):
            # if the window is 'conf' then save the gadget
            if self.prefix == 'conf':
                self.parent._save_gui_context()
                self.parent._save_params()
                self.parent._save_vars()
                self.parent.tgfile.save()
                
        def internationalize():
            prefix = "at_gui_%s" % (self.prefix)
            for wdg in self.window.get_widgets():
                wdg_prefix = "%s_%s" % (prefix, wdg.get_name())
                path = wdg.class_path()
                widget_type = path[path.rfind('.')+1:]
                if widget_type == 'GtkLabel':
                    if self.parent.strings.has_key(wdg_prefix):
                        gtk.gdk.threads_enter()
                        wdg.set_text(self.parent.string(wdg_prefix))
                        gtk.gdk.threads_leave()
                if widget_type == 'GtkButton':
                    tmp = wdg.get_label()
                    if tmp != None:
                        if self.parent.strings.has_key(wdg_prefix):
                            gtk.gdk.threads_enter()
                            wdg.set_label(self.parent.string(wdg_prefix))
                            gtk.gdk.threads_leave()
                if widget_type in['GtkImageMenuItem', 'GtkMenuItem', 'GtkCheckMenuItem', 'GtkCheckButton', 'GtkRadioButton']:
                    al = wdg.get_child()
                    if self.parent.strings.has_key(wdg_prefix):
                        gtk.gdk.threads_enter()
                        al.set_text(self.parent.string(wdg_prefix))
                        gtk.gdk.threads_leave()
        
        # If not conf GUI then exit
        if not self.present:
            return False
        # If gadget running then exit
        # If GUI is already running then exit
        if self.showed():
            return False
        # Create a window
        if not no_mutex:
            self.parent._print_debug('GUI show : gadget_mutex.acquire')
            gadget_mutex.acquire()
        global my_window
        my_conf_GUI = None
        class_name = self.parent.cst['name'].replace(' ', '_')
        show_wd_code = 'global my_window\nmy_window = %s()' % self.window_class_name
        if threads_protected:
            self.parent._print_debug('GTK Threads_enter : GUI show')
            gtk.gdk.threads_enter()
        try:
            exec str(show_wd_code) in globals()
        except:
            self.parent._print_error('GUI object(%s)' % self.window_class_name)
            self.window = None
            if threads_protected:
                gtk.gdk.threads_leave()
                self.parent._print_debug('GTK Threads_leave : GUI show')
            if not no_mutex:
                self.parent._print_debug('GUI show : gadget_mutex.release')
                gadget_mutex.release()
            return False
        self.window = my_window
        self.window.get_widget("window1").connect('destroy', on_delete)
        # Assign icon.png if exists
        if self.parent.icons.has_key('gadget.png'):
            self.window.get_widget("window1").set_icon_from_file(self.parent.icons['gadget.png'])
        if self.parent.var['gui_state'].has_key(self.prefix):
            if self.parent.var['gui_state'][self.prefix].has_key('x'):
                x = self.parent.var['gui_state'][self.prefix]['x']
                y = self.parent.var['gui_state'][self.prefix]['y']
                self.window.get_widget('window1').move(x, y)
        if threads_protected:
            gtk.gdk.threads_leave()
            self.parent._print_debug('GTK Threads_leave : GUI show')
        if not no_mutex:
            self.parent._print_debug('GUI show : gadget_mutex.release')
            gadget_mutex.release()
        gadget_thread.start_new_thread(internationalize, ())
        return True

    def hide(self, threads_protected = True):
        """
        Destroy the instance of the window.
        """
        gui_up.insert(self.__hide, (False, False))
        while self.showed():
            time.sleep(0.1)

    def hide_from_main(self):
        """
        Destroy the instance of the window, from 'main.py'.
        """
        t = threading.Thread(target = self.__hide, args = (True, True))
        t.setName('Hide from main "%s"' % self.parent.cst['name'])
        t.start()
        self.parent.my_threads.append(t)
        while self.showed():
            time.sleep(0.1)

    def __hide(self, threads_protected = True, no_mutex = False):
        # If not conf GUI then exit
        if not self.present: return False
        # If GUI object exist
        if self.showed():
            if not no_mutex:
                gadget_mutex.acquire()
            if threads_protected:
                self.parent._print_debug('GTK Threads_enter : GUI hide')
                gtk.gdk.threads_enter()
            x, y = self.window.get_widget('window1').get_position()
            if not self.parent.var['gui_state'].has_key(self.prefix):
                self.parent.var['gui_state'][self.prefix] = {}
            self.parent.var['gui_state'][self.prefix]['x'] = x
            self.parent.var['gui_state'][self.prefix]['y'] = y
            self.window.get_widget("window1").destroy()
            if threads_protected:
                gtk.gdk.threads_leave()
                self.parent._print_debug('GTK Threads_leave : GUI hide')
            self.window = None
            if not no_mutex:
                gadget_mutex.release()
        return True

    def refresh(self):
        """
        Refresh the window.
        """
        lst =  self.showed()
        self.hide()
        if lst:
            self.show()
            while not self.showed():
                time.sleep(0.1)

def write_doc(base_path):
    from C2MEDoc import C2MEDoc
    doc = C2MEDoc()
    gdg = GdgObject('/opt/tuxdroid/apps/tux_manager/gadgets/Weather.tgf')
    doc.write(base_path + '/GdgObject_doc.html', gdg, '_me', '0.1.1',
        [['example_gui', "gui('gui name')"],])

    doc.write(base_path + '/GdgDebug_doc.html', gadget_debug, 'gadget_debug', '0.1.1')

    tux.misc.build_documentation(base_path + '/PythonApi.html')

    scene = GdgScene('')
    doc.write(base_path + '/GdgScene_doc.html', scene, 'scene', '0.1.1')

    doc.write(base_path + '/GdgSceneContainer_doc.html', scene_container, 'scene_container', '0.1.1')

    scenario = GdgScenario('test')

    doc.write(base_path + '/GdgScenario_doc.html', scenario, 'scenario', '0.1.1')

#write_doc('/home/remi/Desktop/TuxDroidPythonDoc')
