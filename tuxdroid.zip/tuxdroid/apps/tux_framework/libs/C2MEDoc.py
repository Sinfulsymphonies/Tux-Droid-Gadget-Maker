#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - C2MEDoc Tux user documentation
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import string

class C2MEDoc(object):

    header_doc = ''
    h_titre_b = '<b><u><font size="3">'
    h_titre_e = '</font></u></b>'
    h_class_b = '<b><u><font size="2">'
    h_class_e = '</font></u></b>'
    h_funct_b = '<b><u><i><font size="2">'
    h_funct_e = '</font></i></u></b>'

    def __init__(self):
        pass

    def __parse_class(self, class_num, class_obj, class_name,
        class_str, indent):
        """
        Parse a class
        """
        test=class_str.split("\n")
        # print class
        c_header=''
        my_doc=''
        for i in range(80-len(indent)): c_header=c_header+'-'
        my_doc="%s%s) Object [%s] as class(%s)<br>"%(my_doc,class_num, \
                class_name,str(type(class_obj))[8:-2])
        self.header_doc=self.header_doc+indent+'<a href="#%s">'%(class_num) \
                +my_doc+'</a>'
        my_doc=indent+'<a name=%s></a>'%(class_num)+self.h_class_b+ \
                my_doc+self.h_class_e
        for line in test:
            if line.find('Functions list')!=-1:
                break
            my_doc=my_doc+indent+line[4:]+'<br>'
        # affine class str
        class_str=string.replace(class_str,' ','')
        test=class_str.split("\n")

        i=0
        # functions
        funct_ok=False
        for line in test:
            if line=='':
                funct_ok=False
            if funct_ok:
                line=line[line.rfind('.')+1:]
                i=i+1
                my_doc=my_doc+self.__parse_function("%s.%d"%(class_num,i), \
                        class_name+'.'+line, getattr(class_obj,line).__doc__, \
                        indent+'   ')
            if line.find('Functionslist')!=-1:
                funct_ok=True
        # sub class
        for line in test:
            if line.find('asinstanceofclass')!=-1:
                line=line[1:line[1:].find('"')+1]
                i=i+1
                my_doc=my_doc+self.__parse_class("%s.%d"%(class_num,i), \
                        getattr(class_obj,line),class_name+'.'+line, \
                        getattr(class_obj,line).__doc__,indent+'   ')
        return my_doc

    #--------------------------------------------------------------------------
    # Not a user function
    #--------------------------------------------------------------------------
    def __parse_function(self, funct_num, funct_name, funct_str, indent):
        """
        Parse a function
        """
        print funct_name
        if funct_str == None:
            return ''
        test=funct_str.split("\n")
        c_header=''
        my_doc=''
        for i in range(80-len(indent)): c_header=c_header+'-'
        my_doc='%s%s) Function : %s<br>'%(my_doc,funct_num,funct_name)
        self.header_doc=self.header_doc+indent+'<a href="#%s">'%(funct_num) \
                +my_doc+'</a>'
        my_doc=indent+'<a name=%s></a>'%(funct_num)+self.h_funct_b+ \
                my_doc+self.h_funct_e
        for line in test:
            my_doc=my_doc+indent+line[4:]+'<br>'
        return my_doc

    def write(self, doc_path, self_class, self_name, version, replace_str_list = []):
        """
        Build the documentation of a class

            Parameters:
            "doc_path" as string        : Path of the output html file
            "self_class" as an object   : Target object
            "self_name" as string       : Name of target object
            "version" as string         : Version of the documentation
        """
        main_class = self_class.__doc__
        c_header = ''
        for i in range(80): c_header = c_header + '-'
        documentation = '<html><HEAD>\
        <STYLE type="text/css">\
            A:LINK    {text-decoration : none;color : black;}\
            A:VISITED {text-decoration : none;color : black;}\
            A:HOVER   {text-decoration : none;color : red;}\
        </STYLE>\
        </HEAD>'
        documentation = documentation + '<body><pre>'
        documentation = documentation + self.h_titre_b + \
                'USER DOCUMENTATION OF ' + \
                str(type(self_class))[8:-2] + \
                ' V%s' % version + \
                self.h_titre_e + '<br>'
        documentation = documentation + '\n'
        self.header_doc = '<br>' + self.h_class_b + 'Table of content :' + \
                self.h_class_e + '<br><br>'
        body_doc = self.__parse_class('1', self_class, self_name, main_class, '')
        self.header_doc = self.header_doc + '<br><br>'
        documentation = documentation + self.header_doc + body_doc + \
                '</pre></body></html>'
        for replace_str in replace_str_list:
            documentation = documentation.replace(replace_str[0], replace_str[1])
        f = open(doc_path, 'w')
        f.write(documentation)
        f.close()
