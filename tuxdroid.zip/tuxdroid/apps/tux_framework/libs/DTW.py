#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Voice recognition - DTW
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
from ctypes import *

DTW_SO = '/opt/tuxdroid/apps/tux_framework/libs/_DTW.so'
lib = CDLL(DTW_SO)
_DTW = lib.DTW
_DTW.restype = c_float

class m_patern(Structure):
    _fields_ = [("matrix", POINTER(c_float)),
                ("matrix_len", c_uint)]
                
def list_to_m_patern(float_list):
    t_float = tuple(float_list)
    p1 = m_patern()
    p1.matrix = (c_float * len(t_float))(*t_float)
    p1.matrix_len = len(t_float)
    return p1

def DTW(mcep_coeff1, mcep_coeff2):
    v1 = list_to_m_patern(mcep_coeff1)
    v2 = list_to_m_patern(mcep_coeff2)
    return _DTW(v1, v2)       
