#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - T9
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------

import marshal

class tuxdroid_t9(object):

    def __init__(self):
        self.words_database = {}
        self.get_word_list_not_recursively = False
        self.init_my_word()

    def save_database_to_file(self,path):
        marshal.dump(self.words_database, open(path, 'wb'))

    def load_database_from_file(self,path):
        self.words_database = marshal.load(open(path, "rb"))

    def clear_database(self):
        self.words_database = {}

    def format_string(self,text):
        text = text.lower()
        text = text.replace('!','')
        text = text.replace('?','')
        text = text.replace('.','')
        text = text.replace(',','')
        text = text.replace(':','')
        text = text.replace(';','')
        return text

    def word_to_way(self,word):
        result = []
        for char in word:
            if char in ('.',',','?','!',':',';'):
                result.append(1)
            if char in ('a','b','c',chr(224),chr(231)):
                result.append(2)
            if char in ('d','e','f',chr(232),chr(233),chr(234)):
                result.append(3)
            if char in ('g','h','i',chr(238),chr(239)):
                result.append(4)
            if char in ('j','k','l'):
                result.append(5)
            if char in ('m','n','o',chr(244),chr(246)):
                result.append(6)
            if char in ('p','q','r','s'):
                result.append(7)
            if char in ('t','u','v',chr(249),chr(251),chr(252)):
                result.append(8)
            if char in ('w','x','y','z'):
                result.append(9)
        return result

    def insert_word_in_database(self,word):
        if word == '': return
        u = unicode(word,"utf-8")
        word2 = u.encode('latin1','replace')
        way = self.word_to_way(word2)
        node = self.words_database
        for i,num in enumerate(way):
            if not node.has_key(num):
                node[num] = {}
            node = node[num]
        if not node.has_key(word):
            node[word] = 'fr'

    def insert_text_in_database(self,text):
        f_text = self.format_string(text)
        s_text = f_text.split(' ')
        for word in s_text:
            self.insert_word_in_database(word)

    def insert_words_tuple_in_database(self,words_tuple):
        for word in words_tuple:
            self.insert_word_in_database(word)

    def goto_node(self,node,num):
        if not node.has_key(num):
            return node
        else:
            return node[num]

    def list_words_from_node(self,node,matched_words_list):
        for p_node in node:
            if str(type(p_node)) != "<type 'str'>":
                if not self.get_word_list_not_recursively:
                    self.list_words_from_node(node[p_node],matched_words_list)
            else:
                matched_words_list.insert(0,p_node)

    def goto_next_char(self,num):
        tmp_node = self.curr_node
        self.curr_node = self.goto_node(self.curr_node,num)
        if tmp_node == self.curr_node: return
        self.nodes_history.append(tmp_node)
        self.matched_words_list = []
        self.matched_words_list_index = 0
        self.list_words_from_node(self.curr_node,self.matched_words_list)
        if len(self.matched_words_list) == 0:
            save = self.get_word_list_not_recursively
            self.get_word_list_not_recursively = False
            self.list_words_from_node(self.curr_node,self.matched_words_list)
            self.get_word_list_not_recursively = save
        self.matched_words_list = sorted(self.matched_words_list)

    def goto_previous_char(self):
        if len(self.nodes_history) == 0: return
        self.curr_node = self.nodes_history.pop()
        self.matched_words_list = []
        self.matched_words_list_index = 0
        self.list_words_from_node(self.curr_node,self.matched_words_list)
        self.matched_words_list = sorted(self.matched_words_list)

    def init_my_word(self):
        self.matched_words_list = []
        self.matched_words_list_index = 0
        self.curr_node = self.words_database
        self.nodes_history = []
        self.nodes_history.append(self.curr_node)

    def get_current_word_from_list(self):
        if len(self.matched_words_list) > 0:
            return self.matched_words_list[self.matched_words_list_index]
        else:
            return 'NULL'

    def print_current_word_from_list(self):
        print self.get_current_word_from_list()

    def inc_matched_words_list_index(self):
        if (self.matched_words_list_index + 1) >= len(self.matched_words_list):
            self.matched_words_list_index = 0
        else:
            self.matched_words_list_index = self.matched_words_list_index + 1

    def dec_matched_words_list_index(self):
        if (self.matched_words_list_index - 1) < 0:
            self.matched_words_list_index = len(self.matched_words_list) - 1
        else:
            self.matched_words_list_index = self.matched_words_list_index - 1

    def current_matched_word(self):
        return self.get_current_word_from_list()
