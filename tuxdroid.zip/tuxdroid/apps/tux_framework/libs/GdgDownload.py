#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget - Download Lib
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------

import subprocess
import datetime
import time
import signal
import os
import socket
import urllib2
import threading

def check_server_available(url, timeout):
    """
    Check if a server is available.

        Parameters:
        "url" as string         : url of the server
        "timeout" as integer    : timeout in seconds

        Returns:
        A boolean.
    """
    idx = url.find('//') + 2
    url = url[idx:]
    idx = url.find('/')
    url = url[:idx]
    start = datetime.datetime.now()
    cmd = ["ping", "-q", "-c1", url]
    process = subprocess.Popen(cmd, stdout = subprocess.PIPE,\
                        stderr = subprocess.PIPE)
    #print process.stdout.read(800)
    result = None
    while True:
        pp = process.poll()
        if not pp is None:
            result = pp
            break
        time.sleep(0.1)
        now = datetime.datetime.now()
        if (now - start).seconds > timeout:
            os.kill(process.pid, signal.SIGKILL)
            return False
    if result >= 0:
        return True
    else:
        return False

def download_file(url, timeout):
    """
    Download an url.

        Parameters:
        "url" as string         : url of the file
        "timeout" as integer    : timeout in seconds

        Returns:
        A tuple(<boolean>, <string>)
    """
    socket.setdefaulttimeout(timeout)
    if not check_server_available(url, timeout):
        return False, ''
    req = urllib2.Request(url)
    try:
        f = urllib2.urlopen(url)
    except urllib2.HTTPError, exc:
        return False, ''
    except urllib2.URLError, exc:
        return False, ''
    except:
        return False, ''

    try:
        rss_str = f.read()
    except:
        return False, ''
    return True, rss_str

class GdgDownload(object):
    """
    Class which manages the download of files.

        Functions list for the users:
        _me.download.check_server_available
        _me.download.download_url
    """

    def __init__(self):
        pass

    def check_server_available(self, url, timeout):
        """
        Check if a server is available.

            Parameters:
            "url" as string         : url of the server
            "timeout" as integer    : timeout in seconds

            Returns:
            A boolean.
        """
        return check_server_available(url, timeout)

    def download_url(self, url, timeout):
        """
        Download an url and return the content in a string.

            Parameters:
            "url" as string         : url of the file
            "timeout" as integer    : timeout in seconds

            Returns:
            A tuple(boolean, string)
        """
        return download_file(url, timeout)
