#!/usr/bin/python
import sys
import os
import time
import threading
import math
from copy import *

REFRESH_DELAY = 0.1

CHANNEL_LEDS = 0
CHANNEL_EYESMOUTH = 1
CHANNEL_WINGS = 2
CHANNEL_SPIN = 3
CHANNEL_SOUND = 4
CHANNEL_TTS = 5

LEDS_BLINK_CANVAS = {'cmd' : 'leds_blink', 'count' : 1.0, 'speed' : 1}
LEDS_ON_CANVAS = {'cmd' : 'leds_on', 'duration' : 0.0}
LEDL_ON_CANVAS = {'cmd' : 'ledl_on', 'duration' : 0.0}
LEDR_ON_CANVAS = {'cmd' : 'ledr_on', 'duration' : 0.0}
LEDS_OFF_CANVAS = {'cmd' : 'leds_off', 'duration' : 0.0}
LEDL_OFF_CANVAS = {'cmd' : 'ledl_off', 'duration' : 0.0}
LEDR_OFF_CANVAS = {'cmd' : 'ledr_off', 'duration' : 0.0}

LEDS_CMD_TYPES = {
    'Led on/off': 
        [
            'leds_on', 
            'ledl_on', 
            'ledr_on',
            'leds_off', 
            'ledl_off', 
            'ledr_off'
        ],
    'Leds blink':
        ['leds_blink'],
}

MOUTH_ON_CANVAS = {'cmd' : 'mouth_on', 'duration': 0.0, 'count' : 2}
MOUTH_OPEN_CANVAS = {'cmd' : 'mouth_open', 'duration': 0.0}
MOUTH_CLOSE_CANVAS = {'cmd' : 'mouth_close', 'duration': 0.0}
EYES_ON_CANVAS = {'cmd' : 'eyes_on', 'duration': 0.0, 'count' : 2}
EYES_OPEN_CANVAS = {'cmd' : 'eyes_open', 'duration': 0.0}
EYES_CLOSE_CANVAS = {'cmd' : 'eyes_close', 'duration': 0.0}

MOUTH_EYES_CMD_TYPES = {
    'Mouth':
        [
            'mouth_on',
            'mouth_open',
            'mouth_close'
        ],
    'Eyes':
        [
            'eyes_on',
            'eyes_open',
            'eyes_close'
        ]
}

PLAY_FLASH_CANVAS = {'cmd' : 'sound_play', 'index' : 0, 'duration' : 0.0}
PLAY_WAVE_CANVAS = {'cmd' : 'wav_play', 'wav_name' : 'none', 'duration' : 0.0}

SOUND_CMD_TYPES = {
    'Sound':
        [
            'sound_play',
            'wav_play',
        ],
}

SPINNING_LEFT_CANVAS = {'cmd' : 'spinl_on', 'duration': 0.0, 'count' : 2, 'speed': 5}
SPINNING_RIGHT_CANVAS = {'cmd' : 'spinr_on', 'duration': 0.0, 'count' : 2, 'speed': 5}

SPINNING_CMD_TYPES = {
    'Spinning':
        [
            'spinl_on',
            'spinr_on',
        ],
}

PLAY_TTS_CANVAS = {'cmd' : 'tts_play', 'text' : "Hello world", 'speaker' : 3, 'pitch': 100, 'duration' : 0.0}

TTS_CMD_TYPES = {
    'TTS':
        [
            'tts_play',
        ],
}

WINGS_ON_CANVAS = {'cmd' : 'wings_on', 'duration': 0.0, 'count' : 2}
WINGS_UP_CANVAS = {'cmd' : 'wings_up', 'duration': 0.0}
WINGS_DOWN_CANVAS = {'cmd' : 'wings_down', 'duration': 0.0}

WINGS_CMD_TYPES = {
    'Wings':
        [
            'wings_on',
            'wings_up',
            'wings_down',
        ],
}

class TLBlock(object):

    def __init__(self, block_type):
        self._block_type = block_type
        self._time_begin = 0.0
        self._length = 1.0
        self._function = {}
        self._alive = True
        self._cell_view = {
            'top' : 0,
            'left' : 0,
            'width' : 0,
            'height' : 0
        }
        self._wcoeff = 0.0
        self._view_position = 0.0
        self._view_width = 0.0
        self._wavefile = ""
        self._energy_table = []
        
    def set_position(self, value):
        if (value >= 0.0) and (value <= 600.0 - self._length):
            self._time_begin = value
        
    def get_position(self):
        return self._time_begin
        
    def set_length(self, value):
        if value < 0.3:
            value = 0.3
        self._length = value
        self._function['duration'] = value
        
    def get_length(self):
        return self._length
        
    def set_function_params(self, fp = {}):
        if fp.has_key('duration'):
            if fp['duration'] > 0.0:
                self.set_length(fp['duration'])
            else:
                self.set_length(0.3)
        else:
            fp['duration'] = 0.0
            self.set_length(0.3)
        self._function = fp
        
    def get_function_params(self):
        return self._function
        
    def is_assigned(self):
        if self._function == {}:
            return False
        else:
            return True
            
    def have_duration(self):
        if self._function.has_key('duration'):
            if self._function['duration'] > 0.0:
                return True
            else:
                return False
        else:
            return False
            
    def get_wav_path(self):
        return self._wavefile
        
    def close_wavefile(self):
        self._energy_table = []
        self.set_length(0.3)
        
    def load_wavefile(self, path):
    
        def log_val(val):
            if val < 0:
                val = abs(val)
                if val < 1:
                    val = 1.0
                return -int((float(math.log(val) / math.log(127))) * 127)
            else:
                if val < 1:
                    val = 1.0
                return int((float(math.log(val) / math.log(127))) * 127)
            
        if not os.path.isfile(path):
            return False
        f = open(path, 'r')
        f.seek(44, 0)
        st = f.read()
        f.close
        self._wavefile = path
        self._energy_table = []
        waveform = []
        for val in st:
            waveform.append(ord(val) - 127)
        e_c = len(waveform) / 10
        for i in range(e_c):
            val = 0
            for j in range(10):
                val += waveform[i*10 + j]
            val /= int(10)
            self._energy_table.append(log_val(val))   
            
        self.set_length(float(len(self._energy_table)) / 800)
        self._function['duration'] = float(len(self._energy_table)) / 800

class TimelineReader(object):

    def __init__(self, tux, timeline, scene):
        self.__block_list = []
        self.__instant_list = []
        self.__time_begin = 0.0
        self.__current_time = 0.0
        self.tux = tux
        self.timeline = timeline
        self.scene = scene
        self.__stop_flag_mutex = threading.Lock()
        self.__stop_flag = True
        
    def set_list(self, lst):
        if not self.__get_stop_flag():
            return
        self.__block_list = lst
    
    def set_scene(self, scene):
        self.scene = scene
         
    def _to_instant_list(self):
        if not self.__get_stop_flag():
            return
        self.__instant_list = []
        for st in self.__block_list:
            tb = float(int(st[0] * 100)) / 100
            delay = 0.0
            if st[1]['cmd'] == 'tts_play':
                delay = 0.5
            elif st[1]['cmd'] == 'wav_play':
                delay = 0.15
            self.__instant_list.append([tb, st[1], st[2], delay])
            
    def to_xml_struct(self):
        self._to_instant_list()
        blk_struct = {}
        counter = 0
        while True:
            blk = self.get_next()
            if blk == None:
                break
            params = copy(blk[1])
            params['start_time'] = blk[0]
            blk_name = "block_%.3d" % counter
            counter += 1
            blk_struct[blk_name] = params
        if self.scene != None:
            self.scene.set_timeline_struct(blk_struct)
            
    def from_xml_struct(self):
    
        def get_row(cmd):
            for cmd_type in LEDS_CMD_TYPES:
                if cmd in LEDS_CMD_TYPES[cmd_type]:
                    return CHANNEL_LEDS
            for cmd_type in MOUTH_EYES_CMD_TYPES:
                if cmd in MOUTH_EYES_CMD_TYPES[cmd_type]:
                    return CHANNEL_EYESMOUTH
            for cmd_type in WINGS_CMD_TYPES:
                if cmd in WINGS_CMD_TYPES[cmd_type]:
                    return CHANNEL_WINGS
            for cmd_type in SPINNING_CMD_TYPES:
                if cmd in SPINNING_CMD_TYPES[cmd_type]:
                    return CHANNEL_SPIN
            for cmd_type in SOUND_CMD_TYPES:
                if cmd in SOUND_CMD_TYPES[cmd_type]:
                    return CHANNEL_SOUND
            for cmd_type in TTS_CMD_TYPES:
                if cmd in TTS_CMD_TYPES[cmd_type]:
                    return CHANNEL_TTS
                    
        self.__instant_list = []
        struct = self.scene.get_timeline_struct()
        keys = struct.keys()
        keys.sort()
        for key in keys:
            params = copy(struct[key])
            row = get_row(params['cmd'])
            time_pos = params['start_time']
            params.pop('start_time')
            block = TLBlock(row)
            block.set_position(time_pos)
            block.set_function_params(params)
            duration = 0.0
            #if params.has_key('duration'):
            #    duration = params['duration']
            block.set_length(duration)
            if params['cmd'] == 'wav_play':
                wav_path = self.scene.get_wav(params['wav_name'])
                if wav_path != None:
                    block.load_wavefile(wav_path)
                    
            tb = float(int(block.get_position() * 100)) / 100
            delay = 0.0
            if params['cmd'] == 'tts_play':
                delay = 0.5
            elif params['cmd'] == 'wav_play':
                delay = 0.15
            self.__instant_list.append([tb, params, block, delay])
    
    def get_next(self):
        result = None
        lower_time = 1000000000.0
        idx = -1
        for i, st in enumerate(self.__instant_list):
            if (st[0] - st[3]) < lower_time:
                lower_time = st[0]
                idx = i
        if idx != -1:
            result = copy(self.__instant_list[idx])
            self.__instant_list.pop(idx)
        return result
        
    def get_first(self, position_begin):
        r_block = None
        while True:
            m_block = self.get_next()
            if m_block == None:
                break
            if m_block[0] >= position_begin:
                r_block = m_block
                break
        return r_block
        
    def play_cmd(self, block):
        if not self.__get_stop_flag():
            return
        self.__set_stop_flag(False)
        params = block.get_function_params()
        delay = 0.0
        if params['cmd'] == 'tts_play':
            delay = 0.5
        if params['cmd'] == 'wav_play':
            delay = 0.15
        self.__eval_cmd(params, block, delay)
        self.__set_stop_flag(True)
        
    def __eval_cmd(self, params, block, delay):
        def update_length(t):
            duration = (time.time() - t) - delay
            params['duration'] = duration
            block.set_length(duration)
            if self.timeline != None:
                self.timeline._recalc_full_time()
                self.timeline.refresh()
    
        cmd = params['cmd']
        if cmd == 'leds_on':
            self.tux.cmd.leds_on()
        elif cmd == 'leds_off':
            self.tux.cmd.leds_off()
        elif cmd == 'ledl_on':
            self.tux.cmd.ledl_on()
        elif cmd == 'ledl_off':
            self.tux.cmd.ledl_off()
        elif cmd == 'ledr_on':
            self.tux.cmd.ledr_on()
        elif cmd == 'ledr_off':
            self.tux.cmd.ledr_off()
        elif cmd == 'leds_blink':
            self.tux.cmd.leds_blink(int(params['count']), int(params['speed']))
        elif cmd == 'mouth_on':
            t = time.time()
            self.tux.cmd.mouth_on(params['count'])
            update_length(t)
        elif cmd == 'mouth_open':
            t = time.time()
            self.tux.cmd.mouth_open()
            update_length(t)
        elif cmd == 'mouth_close':
            t = time.time()
            self.tux.cmd.mouth_close()
            update_length(t)
        elif cmd == 'eyes_on':
            t = time.time()
            self.tux.cmd.eyes_on(params['count'])
            update_length(t)
        elif cmd == 'eyes_open':
            t = time.time()
            self.tux.cmd.eyes_open()
            update_length(t)
        elif cmd == 'eyes_close':
            t = time.time()
            self.tux.cmd.eyes_close()
            update_length(t)
        elif cmd == 'wings_on':
            t = time.time()
            self.tux.cmd.wings_on(int(params['count']))
            update_length(t)
        elif cmd == 'wings_up':
            t = time.time()
            self.tux.cmd.wings_up()
            update_length(t)
        elif cmd == 'wings_down':
            t = time.time()
            self.tux.cmd.wings_down()
            update_length(t)
        elif cmd == 'spinl_on':
            t = time.time()
            self.tux.cmd.spinl_on(int(params['count']), int(params['speed']))
            update_length(t)
        elif cmd == 'spinr_on':
            t = time.time()
            self.tux.cmd.spinr_on(int(params['count']), int(params['speed']))
            update_length(t)
        elif cmd == 'tts_play':
            if params['speaker'] <= 0:
                speaker = 3
            else:
                speaker = int(params['speaker'])
            self.tux.tts.select_voice(speaker, int(params['pitch']))
            t = time.time()
            #self.tux.tts.stop()
            self.tux.tts.speak(params['text'])
            update_length(t)
        elif cmd == 'sound_play':
            self.tux.cmd.sound_play(params['index'])
        elif cmd == 'wav_play':
            path = params['wav_name']
            if self.scene != None:
                #self.tux.wav.stop()
                self.scene.play_wav(path)
            
    def __set_stop_flag(self, value):
        self.__stop_flag_mutex.acquire()
        self.__stop_flag = value
        self.__stop_flag_mutex.release()
        
    def __get_stop_flag(self):
        self.__stop_flag_mutex.acquire()
        value = self.__stop_flag
        self.__stop_flag_mutex.release()
        return value
        
    def stop_read(self):
        self.__set_stop_flag(True)
        self.tux.wav.stop()
        self.tux.tts.stop()
        
    def read_loop(self, time_position, time_end):
        if not self.__get_stop_flag():
            return
        if time_position < 1.0:
            time_position = 0.0

        m_block = self.get_first(time_position)
        if m_block == None:
            return
        
        last_block = m_block
        lb_end = last_block[1]['duration'] + last_block[0] + last_block[3]
        time_end = lb_end
        self.__set_stop_flag(False)
        if time_position == 0.0:
            self.tux.cmd.leds_off()
            self.tux.cmd.eyes_open()
            self.tux.cmd.mouth_close()
            self.tux.cmd.wings_down()
        time_begin = time.time() - time_position
        # First block
        if time_position > (m_block[0] - m_block[3]):
            delay = (time_position - (m_block[0] - m_block[3]))
            t = threading.Thread(target = self.__eval_cmd, args = (m_block[1], m_block[2], m_block[3]))
            t.start()
            time.sleep(delay)
            time_begin += delay
        else:
            while (time.time() - time_begin) < (m_block[0] - m_block[3]):
                if self.__get_stop_flag():
                    if self.timeline != None:
                        self.timeline.set_current_position(time_position)
                    self.__set_stop_flag(True)
                    return
                if (time.time() - time_begin) >= time_end:
                    if self.timeline != None:
                        self.timeline.set_current_position(time_position)
                    self.tux.wav.stop()
                    self.__set_stop_flag(True)
                    return
                time.sleep(REFRESH_DELAY)
                if self.timeline != None:
                    self.timeline.set_current_position(time.time() - time_begin)
            t = threading.Thread(target = self.__eval_cmd, args = (m_block[1], m_block[2], m_block[3]))
            t.start()
        # Other bocks
        while True:
            m_block = self.get_next()
            if m_block == None:
                break
            else:
                last_block = m_block
                lb_end = last_block[1]['duration'] + last_block[0] + last_block[3]
                if lb_end > time_end:
                    time_end = lb_end
            while (time.time() - time_begin) < (m_block[0] - m_block[3]):
                if self.__get_stop_flag():
                    if self.timeline != None:
                        self.timeline.set_current_position(time_position)
                    self.__set_stop_flag(True)
                    return
                if (time.time() - time_begin) >= time_end:
                    if self.timeline != None:
                        self.timeline.set_current_position(time_position)
                    self.tux.wav.stop()
                    self.__set_stop_flag(True)
                    return
                time.sleep(REFRESH_DELAY)
                if self.timeline != None:
                    self.timeline.set_current_position(time.time() - time_begin)
            t = threading.Thread(target = self.__eval_cmd, args = (m_block[1], m_block[2], m_block[3]))
            t.start()
        # Wait end
        while (time.time() - time_begin) < time_end:
            if self.__get_stop_flag():
                if self.timeline != None:
                    self.timeline.set_current_position(time_position)
                self.__set_stop_flag(True)
                return
            time.sleep(REFRESH_DELAY)
            if self.timeline != None:
                self.timeline.set_current_position(time.time() - time_begin)
        if self.timeline != None:
            self.timeline.set_current_position(time_position)
        self.__set_stop_flag(True)
