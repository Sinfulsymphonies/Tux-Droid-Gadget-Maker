#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Languages
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
from thomas import Bayes
import os
import sys
sys.path.append('/opt/tuxdroid/api/python')
from tuxapi_const import *

PATH_APP = os.path.realpath(os.path.dirname(sys.argv[0]))
lang_guesser = Bayes()
lang_guesser.load("/opt/tuxdroid/apps/tux_framework/libs/language_guesser.bay")

DEFAULT_SPK_BY_LANG = {
    'ar_ALL' : SPK_AR_FEMALE,
    'nl_BE' : SPK_B_FEMALE,
    'en_GB' : SPK_GB_FEMALE,
    'da_ALL' : SPK_DK_FEMALE,
    'fr_ALL' : SPK_FR_FEMALE,
    'de_ALL' : SPK_D_FEMALE,
    'it_ALL' : SPK_I_FEMALE,
    'nl_NL' : SPK_NL_FEMALE,
    'no_ALL' : SPK_N_FEMALE,
    'pt_ALL' : SPK_P_FEMALE,
    'es_ALL' : SPK_E_FEMALE,
    'sv_ALL' : SPK_S_FEMALE,
    'en_US' : SPK_US_FEMALE
}

def get_language(text, default = 'en_US'):
    def normalize_text(text):
        text = text.lower()
        text = text.replace("'", " ")
        text = text.replace(".", " ")
        text = text.replace(",", " ")
        text = text.replace("!", " ")
        text = text.replace("?", " ")
        text = text.replace("\n", " ")
        text = text.replace('"', " ")
        text = text.replace("(", " ")
        text = text.replace(")", " ")
        text = text.replace("’", " ")
        text = text.replace("  ", " ")
        return text
    res = lang_guesser.guess(normalize_text(text))
    if len(res) > 0:
        return res[0][0]
    else:
        return default

def get_language_voice(text, default = 'en_US'):
    lc = get_language(text, default)
    return DEFAULT_SPK_BY_LANG[lc]
