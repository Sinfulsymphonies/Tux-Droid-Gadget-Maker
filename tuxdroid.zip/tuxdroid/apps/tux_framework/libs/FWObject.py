#!/usr/bin/env python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - Tux Gadget Framework
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import sys
import os
import time
import thread
import signal
import atexit
import subprocess
import threading
import commands
import errno

from GdgObject import *
from GdgThreads import gadget_thread
import TGFormat
sys.path.append('/opt/tuxdroid/apps/tux_framework')
from version import fw_version

def regularize_path(path):
    path = path.replace('%20', '')
    return path
    
class PIDFile(object):
    """
    Class to deal with the pidfile.
        Their original version come from the sysklogd package, under GPL
        Copyright (c) 1995  Martin Schulze <Martin.Schulze@Linux.DE>
    """
    def __init__(self, name, path = "/var/run"):
        self.__PIDFILE = "%s/%s.pid" % (path, name)
        
    def read(self):
        pid = 0
        try:
            f = open(self.__PIDFILE, "r")
            try:
                pid = int(f.readline())
            finally:
                f.close()
        except:
            pass
        return pid
            
    def write(self):
        pid = os.getpid()
        result = False
        try:
            f = open(self.__PIDFILE, "w")
            try:
                f.write("%d\n" % pid)
            finally:
                f.close()
                result = True
        except:
            print 'can not write file' 
        return result
            
    def check(self):
        pid = os.getpid()
        old_pid = self.read()
        if (old_pid == pid) or (old_pid == 0): # pid is different
            return False 
        try:
            os.kill(old_pid, 0)
        except OSError, why:
            if why[0] == errno.ESRCH:
                return False
        return True
        
    def remove(self):
        try:
            os.remove(self.__PIDFILE)
        except:
            pass

class GdgFramework(object):

    def __init__(self, gadget_filename):
        self.version = fw_version
        self.gdg_filename = regularize_path(gadget_filename)
        if not os.path.exists(self.gdg_filename):
            return
        self.gdg_name = TGFormat.get_name_of_tgf_file(self.gdg_filename)
        self.__exit_flag = False
        self.__standby_mutex = threading.Lock()
        self.__unauthorized_gadgets = []
        self.__gtk_main_thread = None
        self.__pidfile = PIDFile('TuxGadgetFramework', '/tmp')
        
    def kill(self):
        try:
            self.__close_gadgets()
            print 'Framework exit done'
            os.kill(os.getpid(), 9)
        except:
            pass
            
    def kill_daemons(self):
        if True:
            tux.daemon.kill()
            tux.sys.wait(1)
            ret = commands.getoutput("ps -ef | grep '/bin/tuxd'")
            ret = ret.split()
            if ret[7] == '/opt/tuxdroid/bin/tuxd':
                pid = int(ret[1])
                try:
                    os.system("kill -9 %d" % pid)
                except:
                    pass
            tux.tts.kill_daemon()

    def run(self):
        if not os.path.exists(self.gdg_filename):
            finalize()
            return

        self.__check_system_ready()
        gtk.gdk.threads_init()
        self.__gtk_main_thread = threading.Thread(target = gtk.main)
        self.__gtk_main_thread.start()
        if not self.__load_gadgets():
            return

        tux.event.on_remote_bt[K_STANDBY] = self.__on_standby
        self.__signal_binding()
        self._main_stopped = False
        self.__main()
        gadget_thread.join()
        self.kill()
        print 'Framework exit done.'

    def exclude_gadget(self, gadget_name):
        """
        Exclude a gadget from this framework session.

            Parameters:
            "gadget_name" as string : Name of the gadget to exclude
        """
        self.__unauthorized_gadgets.append(gadget_name)
        if gadgets.has_key(gadget_name):
            gadget_thread.start_new_thread(self.__close_gadget, (gadget_name,))

    def close_gadget(self, gadget_name):
        """
        Close a gadget.

            Parameters:
            "gadget_name" as string : Name of the gadget to close
        """
        if gadgets.has_key(gadget_name):
            gadget_thread.start_new_thread(self.__close_gadget, (gadget_name,))

    def restart_gadget(self, gadget_name):
        """
        Restart a gadget.

            Parameters:
            "gadget_name" as string : Name of the gadget to restart
        """
        if gadgets.has_key(gadget_name):
            gadget_path = gadgets[gadget_name].tgfile.c_path
            def async(gadget_name, gadget_path):
                self.close_gadget(gadget_name)
                self.start_gadget(gadget_path)
            gadget_thread.start_new_thread(async, (gadget_name, gadget_path))

    def start_gadget(self, gadget_path):
        """
        Start a gadget in the framework.

            Parameters:
            "gadget_path" as string : Path of the gadget to start
        """
        if not os.path.isfile(gadget_path):
            return None
        if gadget_path.lower().find('.tgf') == -1:
            return None
        gadget_name = get_name_of_tgf_file(gadget_path)
        if gadget_name != 'Manager':
            try:
                gadget = GdgObject(gadget_path, self)
                gadget.notify.start()
            except:
                return None
            gadget.restore_GUI(True)
            if gadget.get_funct('initialization') != None:
                gadget.get_funct('initialization')()
            return gadget
        else:
            def async_create(gadget_path):
                try:
                    gadget = GdgObject(gadget_path, self)
                    gadget.notify.start()
                except:
                    return
                if gadget.get_funct('initialization') != None:
                    gadget.get_funct('initialization')()
                gadget.get_funct('show_splash_screen')()
                gadget.insert_funct('close_application', self.__on_standby_async)
                gadget.insert_funct('start_daemons', self.__check_tux_resources)
                if not gadget.gui('widget').showed():
                    gadget.gui('widget').show()
                    while gadget.gui('widget').window == None:
                        tux.sys.wait(0.1)
                gadget.get_funct('binds_clean_rules')()
                gadget.get_funct('make_main_menu')()
            gadget_thread.start_new_thread(async_create, (gadget_path,))
            return None

    def __check_tux_resources(self):
        """
        Check the presence of the Tux droid on the system
        """
        # Get the number of tux connected on the pc
        tux_count = tux.hw.alsa_devices_count()
        # If tux is present then check that the daemons
        # are connected
        if tux_count != 0:
            #if not tux.daemon.connected:
            #    tux.sys.shell_free("/opt/tuxdroid/bin/tuxd&")
            #    tux.sys.wait(1)
            #    counter = 0
            #if not tux.tts.connected:
            #    tux.sys.shell_free("/opt/tuxdroid/bin/tuxosld&")
            #    tux.sys.wait(1)
            #    counter = 0
            return True
        else:
            return False

    def __check_system_ready(self):
        """
        Check that the system is ready to start this app
        """
        self.__check_tux_resources()
        result = True
        if not self.__pidfile.check():
            if not self.__pidfile.write():
                result = False
        else:
            result = False
        if not result:
            pid = self.__pidfile.read()
            try:
                os.kill(pid, signal.SIGKILL)
            except:
                sys.exit(0)
            if not self.__pidfile.write():
                sys.exit(0)
        if tux.daemon.connected:
            tux.daemon.set_my_client_name('tdgagdet')

    def __main(self):
        """
        Main loop of the application
        """
        while not self.__exit_flag:
            tux.sys.wait(0.1)
        self._main_stopped = True

    def __close_gadget(self, gadget_name):
        try:
            gadgets[gadget_name].destroy()
            gadgets.pop(gadget_name)
        except:
            pass

    def __close_gadgets(self):
        """
        Close all gadgets
        """
        for gdg in gadgets.keys():
            self.__close_gadget(gdg)
            
    def exit(self):
        self.__on_standby_async()

    def __on_standby(self):
        """
        Event when the framework will exit
        """
        global notify_mutex
        global gadget_mutex
        
        print 'Framework exiting ...'

        if self.__standby_mutex.locked(): return
        self.__standby_mutex.acquire()

        if self.__exit_flag:
            self.__standby_mutex.release()
            return

        tux.event.on_remote_bt[K_STANDBY] = None

        #gadget_mutex.acquire()
        #gadget_mutex.release()

        #notify_mutex.acquire()
        #notify_mutex.release()

        self.__close_gadgets()

        while tux.tts.sound_on:
            tux.sys.wait(0.1)

        tux.sys.wait(1)

        finalize()

        gtk.main_quit()
                    
        self.__exit_flag = True
        self.__standby_mutex.release()

    def __on_standby_async(self):
        t = threading.Thread(target = self.__on_standby)
        t.start()

    def __exit(self, signum, frame):
        """
        """
        sys.exit(signum)

    def __signal_binding(self):
        """
        Bind ctrl-c and ctrl-d
        """
        signal.signal(signal.SIGTERM, self.__exit)
        signal.signal(signal.SIGINT, self.__exit)
        atexit.register(self.__on_standby)

    def __load_gadgets(self):
        """
        Load the gadgets
        """
        if self.gdg_name == 'Manager':
            my_gadgets = []
            # List the files in the gadgets path
            PATH_GADGETS = os.path.dirname(self.gdg_filename)
            try:
                gadgets_list = os.listdir(PATH_GADGETS)
            except OSError:
                return False

            # For all entry in the gagdets path
            for gadget_file in gadgets_list:
                # Check that the file is a tgf file
                if gadget_file.lower().find('.tgf') != -1:
                    if gadget_file != 'Manager.tgf':
                        gadget_name = get_name_of_tgf_file(os.path.join(PATH_GADGETS, gadget_file))
                        if not gadget_name in self.__unauthorized_gadgets:
                            gadget = GdgObject(os.path.join(PATH_GADGETS, gadget_file), self)
                            gadget.restore_GUI(True)

            manager_gdg = GdgObject(os.path.join(PATH_GADGETS, 'Manager.tgf'), self)
            manager_gdg.get_funct('show_splash_screen')()
            for gdg in gadgets.keys():
                gadgets[gdg].manager = manager_gdg
                gadgets[gdg].notify.start()
            manager_gdg.insert_funct('start_daemons', self.__check_tux_resources)
            manager_gdg.get_funct('binds_clean_rules')()
            for gdg in gadgets.keys():
                if gdg != 'Manager':
                    if gadgets[gdg].get_funct('initialization') != None:
                        gadgets[gdg].get_funct('initialization')()
            manager_gdg.get_funct('initialization')()
            return True
        else:
            gadget = GdgObject(self.gdg_filename, self)
            gadget.notify.start()
            gadget.gui('widget').show()
            while not gadget.gui('widget').showed():
                time.sleep(0.1)
            gadget.gui('conf').show()
            if gadget.get_funct('initialization') != None:
                gadget.get_funct('initialization')()

            def enter_main():
                gadget.speak(gadget.string('name_to_read'))
                tux.cmd.sound_play(13)
                gadget.main()

            tux.event.on_remote_bt[K_OK] = enter_main
            tux.event.on_remote_bt[K_MENU] = gadget.gui('conf').show
            tux.event.on_remote_bt[K_MOUSE] = gadget.gui('widget').show
            return True    
