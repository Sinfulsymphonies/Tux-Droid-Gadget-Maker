#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - OSL - Service object
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import sys
import time
from tux_osl_event_cmd_server import TuxOSLCmdServer, TuxOSLEventServer
from tux_osl_obj import TuxOSLObjDirect

class TuxOSLServiceServer(object):

    def __init__(self, event_port = 5510, cmd_port = 5511):
        self.__osl_obj = TuxOSLObjDirect()
        self.__event_server = TuxOSLEventServer(event_port)
        self.__osl_obj.on_event.connect(self.__on_event, threaded = False)
        self.__osl_obj.on_kill.connect(self.__on_kill, threaded = True)
        self.__cmd_server = TuxOSLCmdServer(self.__osl_obj, cmd_port)
        self.__started = False
        
    def destroy(self):
        self.stop()
        self.__cmd_server.destroy()
        self.__event_server.destroy()
        self.__osl_obj.destroy()
        
    def get_started(self):
        return self.__started

    def __on_event(self, *args):
        self.__event_server.update_events(args)
        if args[0] == 'general':
            if args[1] == 'dongle_disconnected':
                self.stop()
                
    def __on_kill(self, *args):
        self.stop()
        
    def start(self):
        if self.__started:
            return False
        if not self.__osl_obj.connect():
            return False
        if not self.__event_server.start():
            return False
        if not self.__cmd_server.start():
            return False
        self.__started = True
        return True

    def stop(self):
        if not self.__started:
            return True
        self.__event_server.stop()
        self.__cmd_server.stop()
        self.__started = False
        return True
        
    def wait_stop(self):
        while self.get_started():
            time.sleep(0.1)
