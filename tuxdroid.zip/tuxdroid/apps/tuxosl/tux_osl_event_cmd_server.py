#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - OSL - XMLRPC server of osl object
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import time
import threading
import copy
import socket
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
from tux_osl_event_controler import EventsHandler

EVENT_SERVER_DEFAULT_PORT                           = 5510
CMD_SERVER_DEFAULT_PORT                             = 5511


class TuxOSLEventServer(object):

    def __init__(self, port = EVENT_SERVER_DEFAULT_PORT):
        self.__clients = []
        self.__client_mutex = threading.Lock()
        self.__port = port
        self.__server_can_start = True
        try:
            self.__server = SimpleXMLRPCServer(("localhost", self.__port), LogHandler)
            self.__server.register_function(self.register_client, 'register_me')
            self.__server.register_function(self.unregister_client, 'unregister_me')
            self.__server.register_function(self.get_events, 'get_events')
            self.__server.register_introspection_functions()
            self.__server.register_multicall_functions()
        except socket.error:
            print '[TUXOSL] : Event server : Binding error'
            self.__server_can_start = False
        self.__connected = False
        self.__connected_mutex = threading.Lock()
        self.__server_thread = None
        self.__stop_flag = False
        
    def destroy(self):
        self.stop()
        
    def set_connected(self, value):
        self.__connected_mutex.acquire()
        self.__connected = value
        self.__connected_mutex.release()
        
    def get_connected(self):
        self.__connected_mutex.acquire()
        result = self.__connected
        self.__connected_mutex.release()
        return result
        
    def __serve_forever(self):
        print '[TUXOSL] : Event server started'
        while not self.__stop_flag:
            try:
                self.__server.handle_request()
            except:
                pass
        
    def __start(self):
        self.set_connected(True)
        try:
            self.__server.socket.settimeout(0.5)
            self.__serve_forever()
        except:
            print "[TUXOSL] : Error on start the event server"
        self.set_connected(False)
            
    def start(self):
        if not self.__server_can_start:
            return False
        self.__server_thread = threading.Thread(target = self.__start)
        self.__server_thread.start()
        return True
        
    def stop(self):
        self.__client_mutex.acquire()
        self.__clients = []
        self.__client_mutex.release()
        self.__stop_flag = True
        if self.__server_thread != None:
            if self.__server_thread.isAlive():
                self.__server_thread.join()
                print '[TUXOSL] : Event server stopped'
        self.__stop_flag = False
        self.__server.socket.close()
        self.__server.server_close()
        
    def get_events(self, client_id):
        self.__client_mutex.acquire()
        if client_id >= len(self.__clients):
            self.__client_mutex.release()
            return []
        my_client = self.__clients[client_id]
        self.__client_mutex.release()
        if my_client != None:
            result = my_client.get_event_stack().pop(0.5)
        else:
            result = []
        return result
        
    def update_events(self, event):
        self.__client_mutex.acquire()
        for client in self.__clients:
            if client != None:
                client.get_event_stack().push([event,])
        self.__client_mutex.release()
        
    def register_client(self, client_name):
        self.__client_mutex.acquire()
        cli_id = len(self.__clients)
        new_client = TuxOSLClientEventObj(client_name, cli_id)
        self.__clients.append(new_client)
        self.__client_mutex.release()
        print '[TUXOSL] : Client (%s:%d) has been added' % (client_name, cli_id)
        return cli_id
        
    def unregister_client(self, client_id):
        self.__client_mutex.acquire()
        if client_id >= len(self.__clients):
            self.__client_mutex.release()
            return False
        client_name = self.__clients[client_id].get_name()
        self.__clients[client_id] = None
        self.__client_mutex.release()
        print '[TUXOSL] : Client (%s:%d) has been removed' % (client_name, client_id)
        return True

class TuxOSLClientEventObj(object):

    def __init__(self, name, id):
        self.__name = name
        self.__id = id
        self.__event_stack = TuxOSLClientEventStack()
        
    def get_event_stack(self):
        return self.__event_stack
    
    def get_id(self):
        return self.__id
        
    def get_name(self):
        return self.__name
        
class TuxOSLClientEventStack(object):

    def __init__(self):
        self.__stack = []
        self.__stack_mutex = threading.Lock()
        
    def push(self, events = []):
        if len(events) == 0:
            return
        self.__stack_mutex.acquire()
        for event in events:
            self.__stack.append(event)
        self.__stack_mutex.release()
        
    def pop(self, timeout = 1.0):
        tb = time.time()
        result = []
        while True:
            if (time.time() - tb) > timeout:
                break
            self.__stack_mutex.acquire()
            if len(self.__stack) != 0:
                result = copy.copy(self.__stack)
                self.__stack = []
                self.__stack_mutex.release()  
                break
            self.__stack_mutex.release()    
            time.sleep(0.005)
        return result

class LogHandler(SimpleXMLRPCRequestHandler):
    def send_response(self, code, message=None):
        try:
            SimpleXMLRPCRequestHandler.send_response(self, code, message=None)
        except:
            pass
            
    def send_header(self, keyword, value):
        try:
            SimpleXMLRPCRequestHandler.send_header(self, keyword, value)
        except:
            pass
            
    def end_headers(self):
        try:
            SimpleXMLRPCRequestHandler.end_headers(self)
        except:
            pass

    def log_request(self, code='-', size='-'):
        pass
        
    def handle_one_request(self):
        try:
            SimpleXMLRPCRequestHandler.handle_one_request(self)
        except:
            pass
            
    def handle(self):
        try:
            SimpleXMLRPCRequestHandler.handle(self)
        except:
            pass
            
class TuxOSLCmdServer(object):

    def __init__(self, osl_obj, port = CMD_SERVER_DEFAULT_PORT):
        self.__port = port
        self.__osl_obj = osl_obj
        self.__server_can_start = True
        try:
            self.__server = SimpleXMLRPCServer(("localhost", self.__port), LogHandler)
            self.__server.register_function(self.__osl_obj._tts_speak, '_tts_speak')
            self.__server.register_function(self.__osl_obj._tts_set_pause, '_tts_set_pause')
            self.__server.register_function(self.__osl_obj._tts_set_stop, '_tts_set_stop')
            self.__server.register_function(self.__osl_obj._tts_get_authorized_voices_list, '_tts_get_authorized_voices_list')
            self.__server.register_function(self.__osl_obj._tts_get_sound_state, '_tts_get_sound_state')
            self.__server.register_function(self.__osl_obj._tts_get_pause_state, '_tts_get_pause_state')
            self.__server.register_function(self.__osl_obj._tts_get_pitch, '_tts_get_pitch')
            self.__server.register_function(self.__osl_obj.kill, 'kill')
            self.__server.register_function(self.__osl_obj._wav_play, '_wav_play')
            self.__server.register_function(self.__osl_obj._wav_set_pause, '_wav_set_pause')
            self.__server.register_function(self.__osl_obj._wav_set_stop, '_wav_set_stop')
            self.__server.register_function(self.__osl_obj._wav_get_sound_state, '_wav_get_sound_state')
            self.__server.register_function(self.__osl_obj._wav_get_pause_state, '_wav_get_pause_state')
            self.__server.register_function(self.__osl_obj.get_version, 'get_version')
            self.__server.register_function(self.__osl_obj.get_connect_state, 'get_connect_state')
            self.__server.register_introspection_functions()
            self.__server.register_multicall_functions()
        except socket.error:
            print '[TUXOSL] : Cmd server : Binding error'
            self.__server_can_start = False
        self.__connected = False
        self.__connected_mutex = threading.Lock()
        self.__server_thread = None
        self.__stop_flag = False
        
    def destroy(self):
        self.stop()
        
    def set_connected(self, value):
        self.__connected_mutex.acquire()
        self.__connected = value
        self.__connected_mutex.release()
        
    def get_connected(self):
        self.__connected_mutex.acquire()
        result = self.__connected
        self.__connected_mutex.release()
        return result
        
    def __serve_forever(self):
        print '[TUXOSL] : Cmd server started'
        while not self.__stop_flag:
            try:
                self.__server.handle_request()
            except:
                pass
        
    def __start(self):
        self.set_connected(True)
        try:
            self.__server.socket.settimeout(0.5)
            self.__serve_forever()
        except:
            print "[TUXOSL] : Error on start the cmd server"
        self.set_connected(False)
            
    def start(self):
        if not self.__server_can_start:
            return False
        self.__server_thread = threading.Thread(target = self.__start)
        self.__server_thread.start()
        return True
        
    def stop(self):
        if not self.__server_can_start:
            return
        self.__stop_flag = True
        if self.__server_thread != None:
            if self.__server_thread.isAlive():
                self.__server_thread.join()
                print '[TUXOSL] : Cmd server stopped'
        self.__stop_flag = False
        self.__server.socket.close()
        self.__server.server_close()  
    
        
if __name__ == "__main__":
    e = TuxOSLEventServer()
    def send_dummy_event():
        time.sleep(0.5)
        while e.get_connected():
            e.update_events(('coucou', 'Test', 1))
            time.sleep(1)
    t = threading.Thread(target = send_dummy_event)
    t.start()
    e.start()
    
