import os
import sys
import errno

class PIDFile(object):
    """
    Class to deal with the pidfile.
        Their original version come from the sysklogd package, under GPL
        Copyright (c) 1995  Martin Schulze <Martin.Schulze@Linux.DE>
    """
    def __init__(self, name, path = "/var/run"):
        self.__PIDFILE = "%s/%s.pid" % (path, name)
        
    def read(self):
        pid = 0
        try:
            f = open(self.__PIDFILE, "r")
            try:
                pid = int(f.readline())
            finally:
                f.close()
        except:
            pass
        return pid
            
    def write(self):
        pid = os.getpid()
        result = False
        try:
            f = open(self.__PIDFILE, "w")
            try:
                f.write("%d\n" % pid)
            finally:
                f.close()
                result = True
        except:
            print 'can not write file' 
        return result
            
    def check(self):
        pid = os.getpid()
        old_pid = self.read()
        if (old_pid == pid) or (old_pid == 0): # pid is different
            return False 
        try:
            os.kill(old_pid, 0)
        except OSError, why:
            if why[0] == errno.ESRCH:
                return False
        return True
        
    def remove(self):
        try:
            os.remove(self.__PIDFILE)
        except:
            pass
            
class ServiceDaemonizer(object):

    def __init__(self, name, log_path, service_funct, redirect_io = True):
        log_filename = '%s/%s.log' % (log_path, name)
        self.daemonize(redirect_io, '/dev/null', log_filename, log_filename)
        self.__pidfile = PIDFile(name, '/tmp')
        self.__service_funct = service_funct
        
    def start(self):
        result = True
        if not self.__pidfile.check():
            if not self.__pidfile.write():
                result = False
        else:
            old_pid = self.__pidfile.read()
            if old_pid != 0:
                os.kill(old_pid, 9)
                if not self.__pidfile.write():
                    result = False
            else:
                result = False
        if result:
            self.__service_funct()
        return result
        
    def destroy(self):
        pass
        #self.__pidfile.remove()

    def daemonize(self, redirect_io, stdin, stdout, stderr):
        """
         References:
            UNIX Programming FAQ
                1.7 How do I get my program to act like a daemon?
                    http://www.erlenstar.demon.co.uk/unix/faq_2.html#SEC16
        
            Advanced Programming in the Unix Environment
                W. Richard Stevens, 1992, Addison-Wesley, ISBN 0-201-56317-7.
        """
        # Do first fork.
        try: 
            pid = os.fork() 
            if pid > 0:
                sys.exit(0) # Exit first parent.
        except OSError, e: 
            sys.stderr.write ("fork #1 failed: (%d) %s\n" % (e.errno, e.strerror)    )
            sys.exit(1)
            
        # Decouple from parent environment.
        os.chdir("/") 
        os.umask(0) 
        os.setsid() 
        
        # Do second fork.
        try: 
            pid = os.fork()
            if pid > 0:
                sys.exit(0) # Exit second parent.
        except OSError, e: 
            sys.stderr.write ("fork #2 failed: (%d) %s\n" % (e.errno, e.strerror)    )
            sys.exit(1)
            
        # Now I am a daemon!
        
        # Redirect standard file descriptors.
        if redirect_io:
            si = file(stdin, 'r')
            so = file(stdout, 'w')
            se = file(stderr, 'w', 0)
            os.dup2(si.fileno(), sys.stdin.fileno())
            os.dup2(so.fileno(), sys.stdout.fileno())
            os.dup2(se.fileno(), sys.stderr.fileno())
