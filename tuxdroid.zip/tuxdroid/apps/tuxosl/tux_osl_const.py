#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - OSL - Constants
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
SPK_NO_VOICE                                                = 0x00
SPK_NO_VOICE_NAME											= "None8k"
SPK_FR_MALE													= 0x01
SPK_FR_MALE_NAME											= "Bruno8k"
SPK_FR_FEMALE												= 0x02
SPK_FR_FEMALE_NAME											= "Julie8k"
SPK_US_MALE													= 0x03
SPK_US_MALE_NAME											= "Ryan8k"
SPK_US_FEMALE												= 0x04
SPK_US_FEMALE_NAME											= "Heather8k"
SPK_B_FEMALE												= 0x05
SPK_B_FEMALE_NAME											= "Sofie8k"
SPK_D_MALE												    = 0x06
SPK_D_MALE_NAME											    = "Klaus8k"
SPK_D_FEMALE												= 0x07
SPK_D_FEMALE_NAME											= "Sarah8k"
SPK_GB_MALE												    = 0x08
SPK_GB_MALE_NAME											= "Graham8k"
SPK_GB_FEMALE												= 0x09
SPK_GB_FEMALE_NAME											= "Lucy8k"
SPK_AR_FEMALE												= 0x0A
SPK_AR_FEMALE_NAME											= "Salma8k"
SPK_DK_FEMALE												= 0x0B
SPK_DK_FEMALE_NAME											= "Mette8k"
SPK_E_FEMALE												= 0x0C
SPK_E_FEMALE_NAME											= "Maria8k"
SPK_I_FEMALE												= 0x0D
SPK_I_FEMALE_NAME											= "Chiara8k"
SPK_NL_FEMALE												= 0x0E
SPK_NL_FEMALE_NAME											= "Femke8k"
SPK_N_FEMALE												= 0x0F
SPK_N_FEMALE_NAME											= "Kari8k"
SPK_P_FEMALE												= 0x10
SPK_P_FEMALE_NAME											= "Celia8k"
SPK_S_MALE												    = 0x11
SPK_S_MALE_NAME											    = "Erik8k"
SPK_S_FEMALE												= 0x12
SPK_S_FEMALE_NAME											= "Emma8k"

SPK_NAME_LIST = [
    SPK_NO_VOICE_NAME,
    SPK_FR_MALE_NAME,
    SPK_FR_FEMALE_NAME,
    SPK_US_MALE_NAME,
    SPK_US_FEMALE_NAME,
    SPK_B_FEMALE_NAME,
    SPK_D_MALE_NAME,
    SPK_D_FEMALE_NAME,
    SPK_GB_MALE_NAME,
    SPK_GB_FEMALE_NAME,
    SPK_AR_FEMALE_NAME,
    SPK_DK_FEMALE_NAME,
    SPK_E_FEMALE_NAME,
    SPK_I_FEMALE_NAME,
    SPK_NL_FEMALE_NAME,
    SPK_N_FEMALE_NAME,
    SPK_P_FEMALE_NAME,
    SPK_S_MALE_NAME,
    SPK_S_FEMALE_NAME
]
