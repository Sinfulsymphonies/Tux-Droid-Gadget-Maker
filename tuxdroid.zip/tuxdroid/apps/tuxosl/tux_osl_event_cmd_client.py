#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - OSL - XMLRPC client of osl server
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import xmlrpclib
import time
import sys
import os
import threading
import socket

from tux_osl_const import *
from tux_osl_event_controler import EventsHandler

EVENT_CLIENT_DEFAULT_PORT                           = 5510
CMD_CLIENT_DEFAULT_PORT                             = 5511

class TimeoutTransport(xmlrpclib.Transport):

    def request(self, host, handler, request_body, verbose=0):
        self.__handler = handler
        ret = ""
        try:
            ret = xmlrpclib.Transport.request(self, host, '/RPC2',
                                           request_body, verbose)
        except socket.timeout:
            ret = ""
        except:
            raise
            
        return ret

class TuxOSLClientBase(object):

    def __init__(self):
        self.__host = 'localhost'
        self.__port = '5510'
        self.__connected = False
        self.__connected_mutex = threading.Lock()
        self.__server = None
        self.__auto_connect_flag = False
        self.__auto_connect_mutex = threading.Lock()
        self.__auto_connect_thread = None
        self._events_hdl = EventsHandler()
        self._events_hdl.insert('all')
        self.on_event = self._events_hdl.event['all']
        
    def destroy(self):
        self.auto_connect(False)
        self.disconnect()
        self._events_hdl.destroy()
        
    def server(self):
        return self.__server
        
    def get_connected(self):
        self.__connected_mutex.acquire()
        result = self.__connected
        self.__connected_mutex.release()
        return result
        
    def _set_connected(self, value):
        self.__connected_mutex.acquire()
        self.__connected = value
        self.__connected_mutex.release()
        if value:
            self.on_event.notify('client', 'connected')
        else:
            self.on_event.notify('client', 'disconnected')
        
    def __get_auto_connect_flag(self):
        self.__auto_connect_mutex.acquire()
        result = self.__auto_connect_flag
        self.__auto_connect_mutex.release()
        return result
        
    def __set_auto_connect_flag(self, value):
        self.__auto_connect_mutex.acquire()
        self.__auto_connect_flag = value
        self.__auto_connect_mutex.release()
        
    def connect(self, host = 'localhost', port = 5510):
        if self.get_connected():
            # Error: Already connected
            return False
        self.__host = host
        self.__port = port
        proxy = "http://%s:%d" % (self.__host, self.__port)
        try:
            t = TimeoutTransport()
            t.timeout = 20
            self.__server = xmlrpclib.Server(proxy, transport = t)
            self.__server.system.listMethods()
        except:
            # Error: Server not found
            return False
        self._set_connected(True)
        #print 'Connected to [%s] server' % proxy
        return True
        
    def disconnect(self):
        if not self.get_connected():
            # Error: Already disconnected
            return False
        else:
            self._events_hdl.clear_conditions()
            return True
        
    def auto_connect(self, active, host = 'localhost', port = 5510):
        def ac_async(host, port):
            while self.__get_auto_connect_flag():
                if not self.get_connected():
                    #os.system("/opt/tuxdroid/bin/tuxosld&")
                    #time.sleep(1.0)
                    self.connect(host, port)
                time.sleep(1.0)
            
        if active:  # Enabling the auto-connect
            # Disabling of the auto-connect
            self.auto_connect(False)
            # Disconnect the client
            if self.get_connected():
                self.disconnect()
            # Reconnect
            self.__host = host
            self.__port = port
            self.__set_auto_connect_flag(True)
            self.__auto_connect_thread = threading.Thread(target = ac_async, args = (host, port))
            self.__auto_connect_thread.start()
        else:       # Disabling the auto-connect
            if self.__get_auto_connect_flag():
                # Stop the auto-connect loop
                self.__set_auto_connect_flag(False)
                # Wait
                if self.__auto_connect_thread != None:
                    if self.__auto_connect_thread.isAlive():
                        self.__auto_connect_thread.join()
                        
class TuxOSLEventClient(TuxOSLClientBase):

    def __init__(self, client_name):
        TuxOSLClientBase.__init__(self)
        self.__client_name = client_name
        self.__client_id = -1
        self.__capture_thread = None

    def connect(self, host = 'localhost', port = EVENT_CLIENT_DEFAULT_PORT):
        if not TuxOSLClientBase.connect(self, host, port):
            return False
        self.__client_id = self.server().register_me(self.__client_name)
        if self.__client_id == -1:
            return False
        self.__capture_thread = threading.Thread(target = self.__capture_events)
        self.__capture_thread.start()
        return True
        
    def disconnect(self):
        if self.get_connected():
            TuxOSLClientBase.disconnect(self)
            try:
                self.server().unregister_me(self.__client_id)
            except:
                pass # Server already disconnected
            self._set_connected(False)
            time.sleep(0.5)
            if self.__capture_thread != None:
                if self.__capture_thread.isAlive():
                    self.__capture_thread._Thread__stop()
        
    def __capture_events(self):
        while self.get_connected():
            try:
                events = self.server().get_events(self.__client_id)
            except:
                self._set_connected(False)
                self._events_hdl.clear_conditions()
                break
            if len(events) > 0:
                for event in events:
                    self.on_event.notify(*event)
            else:
                time.sleep(0.05)
                    
class TuxOSLCmdClient(TuxOSLClientBase):
    pass
                    
if __name__ == "__main__":

    def on_event(*args):
        print args
        
    e = TuxOSLEventClient("Test")
    e.on_event.connect(on_event)
    e.auto_connect(True, 'localhost', EVENT_CLIENT_DEFAULT_PORT)
