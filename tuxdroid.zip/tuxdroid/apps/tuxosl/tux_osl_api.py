#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - OSL - Bin to old API
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import os
import sys
import threading
import time
from tux_osl_obj import TuxOSLObjDistant, TuxOSLObjDirect
from tux_osl_const import *

class TuxOSLVClass(object):
        
    def __getattribute__(self, name):
        if name == 'authorized_voices_list':
            return self._get_authorized_voices_list()
        elif name == 'connected':
            return self._get_connected()
        return object.__getattribute__(self, name)
        
    def __setattr__(self, name, value):
        if name == 'on_sound_on':
            if value != None:
                self._sound_on_event.connect(value, threaded = False, idx = 2)
        elif name == 'on_sound_off':
            if value != None:
                self._sound_off_event.connect(value, threaded = True, idx = 2)    
        elif name == 'on_connected':
            if value != None:
                self._connected_event.connect(value, threaded = False, idx = 2)
        elif name == 'on_disconnected':
            if value != None:
                self._disconnected_event.connect(value, threaded = False, idx = 2)
        elif name == 'on_voice_list':
            if value != None:
                self._voice_list_event.connect(value, threaded = False, idx = 1)
        object.__setattr__(self, name, value)

class TuxOSLAPI(object):

    def __init__(self, parent = None):
        self.__osl_obj = TuxOSLObjDistant()
        self.__osl_obj.on_sound_on.connect(self._on_general_sound_on, threaded = False)
        self.__osl_obj.on_sound_off.connect(self._on_general_sound_off, threaded = False)
        self.__osl_obj.on_connected.connect(self._on_general_connected, threaded = False)
        self.__osl_obj.on_disconnected.connect(self._on_general_disconnected, threaded = False)
        self.__parent = parent
        self.__tts_mutex = threading.Lock()
        self.__wav_mutex = threading.Lock()
        self.tts = TuxOSLVClass()
        self.wav = TuxOSLVClass()
        self.__decorate_tts_sub_object()
        self.__decorate_wav_sub_object()
        
    def destroy(self):
        self.__osl_obj.destroy()
        
    def connect(self, host = 'localhost', port = 5510):
        self.__osl_obj.connect(host)
        
    def auto_connect(self, value, host = 'localhost', port = 5510):
        self.__osl_obj.auto_connect(value, host)
        
    def disconnect(self):
        self.__osl_obj.disconnect()
        
    def kill_daemon(self):
        self.__osl_obj.kill()
        
    def _get_version(self):
        return self.__osl_obj.get_version()
        
    def __decorate_tts_sub_object(self):
        self.tts.print_status = False
        self.tts.on_sound_on = None
        self.tts._sound_on_event = self.__osl_obj.on_sound_on
        self.tts.on_sound_off = None
        self.tts._sound_off_event = self.__osl_obj.on_sound_off
        self.tts.on_connected = None
        self.tts._connected_event = self.__osl_obj.on_connected
        self.tts.on_disconnected = None
        self.tts._disconnected_event = self.__osl_obj.on_disconnected
        self.tts.on_voice_list = None
        self.tts._voice_list_event = self.__osl_obj.tts.on_voice_list_changed
        self.tts.sound_on = False 
        self.tts.connected = False
        self.tts.authorized_voices_list = []
        self.tts._get_authorized_voices_list = self._tts_get_authorized_voices_list
        self.tts._get_connected = self._get_connected
        self.tts._locutor = SPK_US_MALE_NAME
        self.tts._pitch = 100
        self.tts.speak = self._tts_speak
        self.tts.speak_free = self._tts_speak_free
        self.tts.pause = self._tts_pause
        self.tts.play = self._tts_play
        self.tts.stop = self._tts_stop
        self.tts.select_voice = self._tts_select_voice
        self.tts.connect = self.connect
        self.tts.auto_connect = self.auto_connect
        self.tts.disconnect = self.disconnect
        self.tts.destroy = self.destroy
        self.tts.kill_daemon = self.kill_daemon
        self.tts.get_version = self._get_version
        
    def __decorate_wav_sub_object(self):
        self.wav.play = self._wav_play
        self.wav.play_free = self._wav_play_free
        self.wav.pause = self._wav_pause
        self.wav._continue = self._wav__continue
        self.wav.stop = self._wav_stop
        self.wav.get_duration = self._wav_get_duration
        self.wav.destroy = self.empty_funct
        
    def _on_general_sound_on(self, *args):
        self.tts.sound_on = True
        if self.__parent != None:
            self.__parent.cmd.audio_channel_tts()
        
    def _on_general_sound_off(self, *args):
        self.tts.sound_on = False
        if self.__parent != None:
            self.__parent.cmd.audio_channel_general()
            
    def _on_general_connected(self, *args):
        print "CONNECTED to tux_osl_daemon"
        
    def _on_general_disconnected(self, *args):
        print "DISCONNECTED from tux_osl_daemon"
            
    def empty_funct(self):
        pass
        
    def _tts_speak(self, text):
        if str(type(text)) != "<type 'str'>":
            return False
        t_text = text.replace(' ', '')
        if len(t_text) == 0:
            return False
        text = text.lower().replace("skype", "skaïpe")
        self.__tts_mutex.acquire()
        result = True
        channel = self.__osl_obj.tts.speak(text, self.tts._locutor, self.tts._pitch)
        if channel != -1:
            self.__osl_obj.current_tts_channel = channel
        else:
            result = False
        self.__tts_mutex.release()
        if result:
            if self.__osl_obj.tts.get_sound_state() == 1:
                self.__osl_obj.tts.on_speak_stop.wait_condition(())
        return result
        
    def _tts_speak_free(self, text):
        if str(type(text)) != "<type 'str'>":
            return False
        t_text = text.replace(' ', '')
        if len(t_text) == 0:
            return False
        text = text.lower().replace("skype", "skaïpe")
        self.__tts_mutex.acquire()
        result = True
        channel = self.__osl_obj.tts.speak(text, self.tts._locutor, self.tts._pitch)
        if channel != -1:
            self.__osl_obj.current_tts_channel = channel
        else:
            result = False
        self.__tts_mutex.release()
        return result
        
    def __tts_speak_free(self, text):
        t = threading.Thread(target = self.__tts_speak_free, args = (text,))
        t.start()
        
    def _tts_pause(self):
        return self.__osl_obj.tts.set_pause(True)
        
    def _tts_play(self):
        return self.__osl_obj.tts.set_pause(False)
        
    def _tts_stop(self):
        return self.__osl_obj.tts.set_stop()
        
    def _tts_select_voice(self, locutor, pitch):
        if (locutor == None) or (pitch == None):
            return False
        self.tts._pitch = pitch
        if str(type(locutor)) != "<type 'str'>":
            locutor = SPK_NAME_LIST[locutor]
        if locutor not in SPK_NAME_LIST:
            return False
        self.tts._locutor = locutor
        return True
        
    def _tts_get_authorized_voices_list(self):
        avl = self.__osl_obj.tts.get_authorized_voices_list()
        result = []
        for v in avl:
            for i, name in enumerate(SPK_NAME_LIST):
                if name == v:
                    result.append(i - 1)
        return result
        
    def _wav_play(self, wav_path, begin = 0.0, end = 9999999.0):
        self.__wav_mutex.acquire()
        result = True
        channel = self.__osl_obj.wav.play(wav_path, begin, end)
        if channel != -1:
            self.__osl_obj.current_wav_channel = channel
        else:
            result = False
        self.__wav_mutex.release()
        if result:
            if self.__osl_obj.wav.get_sound_state(channel) == 1:
                self.__osl_obj.wav.on_play_stop.wait_condition(())
        return result
        
    def _wav_play_free(self, wav_path, begin = 0.0, end = 9999999.0):
        self.__wav_mutex.acquire()
        result = True
        channel = self.__osl_obj.wav.play(wav_path, begin, end)
        if channel != -1:
            self.__osl_obj.current_wav_channel = channel
        else:
            result = False
        self.__wav_mutex.release()
        return result
        
    def _wav_pause(self):
        return self.__osl_obj.wav.set_pause(True)
        
    def _wav__continue(self):
        return self.__osl_obj.wav.set_pause(False)
        
    def _wav_stop(self):
        return self.__osl_obj.wav.set_stop()
        
    def _wav_get_duration(self, wav_path):
        wav_length = 0.0
        if os.path.isfile(wav_path):
            try:
                size = os.stat(wav_path)[6] - 44
                wav_length = (float)(size) / 8000
            except:
                pass
        return wav_length
        
    def _get_connected(self):
        return self.__osl_obj.get_connect_state()

