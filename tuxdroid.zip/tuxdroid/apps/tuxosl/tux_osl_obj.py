#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - OSL - OSL Object
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import time
import sys
import threading
import os
from tux_osl_wrapper import TuxOSLWrapper
from tux_osl_const import *
from tux_osl_event_controler import EventsHandler
from tux_osl_event_cmd_client import TuxOSLEventClient, TuxOSLCmdClient

TUX_OSL_OBJ_VERSION = '0.0.2-alpha'

class TUXOSLVClass(object):
    pass

class TuxOSLObjAncestor(object):

    def __init__(self):
        self.__version = TUX_OSL_OBJ_VERSION
        self.__connect_state = False
        self.__connect_mutex = threading.Lock()
        self.current_wav_channel = 0
        self.current_tts_channel = 0
        self._events_hdl = EventsHandler()
        self.__create_event_handlers()
        self.on_event = self._events_hdl.event['all']
        self.on_connected = self._events_hdl.event['connected']
        self.on_disconnected = self._events_hdl.event['disconnected']
        self.on_sound_on = self._events_hdl.event['sound_on']
        self.on_sound_off = self._events_hdl.event['sound_off']
        self.on_kill = self._events_hdl.event['kill']
        self.tts = TUXOSLVClass()
        self._bind_tts_functions()
        self.wav = TUXOSLVClass()
        self._bind_wav_functions()
        
    def destroy(self):
        if self.get_connect_state():
            self.auto_connect(False)
            self.disconnect()
        self._events_hdl.destroy()
        
    def get_connect_state(self):
        self.__connect_mutex.acquire()
        result = self.__connect_state
        self.__connect_mutex.release()
        return result
        
    def set_connect_state(self, value):
        self.__connect_mutex.acquire()
        self.__connect_state = value
        self.__connect_mutex.release() 
        
    def connect(self, host = 'localhost', ports = [5510, 5511]):
        pass
        
    def disconnect(self):
        pass
        
    def auto_connect(self, value, host = 'localhost', ports = [5510, 5511]):
        pass
        
    def get_version(self):
        return self.__version
        
    def kill(self):
        self._events_hdl.event['kill'].notify()
        return True
        
    def update_events(self, *args):
        self._events_hdl.event['all'].notify(*args)
        if args[0] == 'text_to_speech':
            if args[1] == self.current_tts_channel:
                if args[2] == 'sound':
                    if args[3] == 'on':
                        self._events_hdl.event['tts_speak_start'].notify()
                    else:
                        self._events_hdl.event['tts_speak_stop'].notify()
                if args[2] == 'pause':
                    if args[3] == 'on':
                        self._events_hdl.event['tts_pause_on'].notify()
                    else:
                        self._events_hdl.event['tts_pause_off'].notify()
                if args[2] == 'voice_list': 
                    self._events_hdl.event['voice_list_changed'].notify()
                    self._events_hdl.event['voice_list'].notify(args[3]) 
                if args[2] == 'speak_status':
                    self._events_hdl.event['speak_status'].notify(args[3]) 
        elif args[0] == 'wav_player':
            if args[1] == self.current_wav_channel:
                if args[2] == 'sound':
                    if args[3] == 'on':
                        self._events_hdl.event['wav_play_start'].notify()
                    else:
                        self._events_hdl.event['wav_play_stop'].notify()
                if args[2] == 'pause':
                    if args[3] == 'on':
                        self._events_hdl.event['wav_pause_on'].notify()
                    else:
                        self._events_hdl.event['wav_pause_off'].notify()
        elif args[0] == 'general':
            if args[1] == 'sound':
                if args[2] == 'on':
                    self._events_hdl.event['sound_on'].notify()
                else:
                    self._events_hdl.event['sound_off'].notify()
            elif args[1] == 'connected':
                self._events_hdl.event['connected'].notify()
            elif args[1] == 'disconnected':
                self._events_hdl.event['disconnected'].notify()
        
    def __create_event_handlers(self):
        self._events_hdl.insert('all')
        self._events_hdl.insert('kill')
        self._events_hdl.insert('sound_on')
        self._events_hdl.insert('sound_off')
        self._events_hdl.insert('connected')
        self._events_hdl.insert('disconnected')
        self._events_hdl.insert('voice_list_changed')
        self._events_hdl.insert('voice_list')
        self._events_hdl.insert('speak_status')
        self._events_hdl.insert('tts_speak_start')
        self._events_hdl.insert('tts_speak_stop')
        self._events_hdl.insert('tts_pause_on')
        self._events_hdl.insert('tts_pause_off')
        self._events_hdl.insert('wav_play_start')
        self._events_hdl.insert('wav_play_stop')
        self._events_hdl.insert('wav_pause_on')
        self._events_hdl.insert('wav_pause_off')
        
    def _bind_tts_functions(self):
        self.tts.get_version = self.get_version
        self.tts.get_connect_state = self.get_connect_state
        self.tts.speak = self._tts_speak
        self.tts.set_pause = self._tts_set_pause
        self.tts.set_stop = self._tts_set_stop
        self.tts.get_authorized_voices_list = self._tts_get_authorized_voices_list
        self.tts.get_sound_state = self._tts_get_sound_state
        self.tts.get_pause_state = self._tts_get_pause_state
        self.tts.get_pitch = self._tts_get_pitch
        self.tts._wait_speak_start = self._tts_wait_speak_start
        self.tts.on_voice_list = self._events_hdl.event["voice_list"]
        self.tts.on_voice_list_changed = self._events_hdl.event["voice_list_changed"]
        self.tts.on_speak_start = self._events_hdl.event["tts_speak_start"]
        self.tts.on_speak_stop = self._events_hdl.event["tts_speak_stop"]
        self.tts.on_pause_on = self._events_hdl.event["tts_pause_on"]
        self.tts.on_pause_off = self._events_hdl.event["tts_pause_off"]
        self.tts.on_speak_status = self._events_hdl.event["speak_status"]
        
    def _bind_wav_functions(self):
        self.wav.get_version = self.get_version
        self.wav.get_connect_state = self.get_connect_state
        self.wav.play = self._wav_play
        self.wav.set_pause = self._wav_set_pause
        self.wav.set_stop = self._wav_set_stop
        self.wav.get_sound_state = self._wav_get_sound_state
        self.wav.get_pause_state = self._wav_get_pause_state
        self.wav._wait_play_start = self._wav_wait_play_start
        self.wav.on_play_start = self._events_hdl.event["wav_play_start"]
        self.wav.on_play_stop = self._events_hdl.event["wav_play_stop"]
        self.wav.on_pause_on = self._events_hdl.event["wav_pause_on"]
        self.wav.on_pause_off = self._events_hdl.event["wav_pause_off"]
        
    def _tts_speak(self, text, locutor = SPK_US_MALE_NAME, pitch = 100):
        pass
        
    def _tts_set_pause(self, value):
        pass
        
    def _tts_set_stop(self):
        pass
        
    def _tts_get_authorized_voices_list(self):
        pass
        
    def _tts_get_sound_state(self):
        pass
        
    def _tts_get_pause_state(self):
        pass
        
    def _tts_get_pitch(self):
        pass
        
    def _tts_wait_speak_start(self, timeout):
        ret = False
        if self.get_connect_state():
            ret, result = self._events_hdl.event["tts_speak_start"].wait_condition((), timeout)
        return ret
        
    def _wav_play(self, wav_path, begin = 0.0, end = 9999999.0):
        pass
        
    def _wav_set_pause(self, value):
        pass
        
    def _wav_set_stop(self):
        pass
        
    def _wav_get_sound_state(self, channel):
        pass
        
    def _wav_get_pause_state(self, channel):
        pass
        
    def _wav_wait_play_start(self, timeout):
        ret = False
        if self.get_connect_state():
            ret, result = self._events_hdl.event["wav_play_start"].wait_condition((), timeout)
        return ret 
        
class TuxOSLObjDirect(TuxOSLObjAncestor):

    def __init__(self):
        TuxOSLObjAncestor.__init__(self)
        self.__osl = TuxOSLWrapper()
        self.__tts_mutex = threading.Lock()
        self.__wav_mutex = threading.Lock()
        self.__osl.wav_player_1.set_sound_on_callback(self.__on_wav1_sound_on)
        self.__osl.wav_player_1.set_sound_off_callback(self.__on_wav1_sound_off)
        self.__osl.wav_player_1.set_pause_on_callback(self.__on_wav1_pause_on)
        self.__osl.wav_player_1.set_pause_off_callback(self.__on_wav1_pause_off)
        self.__osl.wav_player_2.set_sound_on_callback(self.__on_wav2_sound_on)
        self.__osl.wav_player_2.set_sound_off_callback(self.__on_wav2_sound_off)
        self.__osl.wav_player_2.set_pause_on_callback(self.__on_wav2_pause_on)
        self.__osl.wav_player_2.set_pause_off_callback(self.__on_wav2_pause_off)
        self.__osl.tts.set_sound_on_callback(self.__on_tts_sound_on)
        self.__osl.tts.set_sound_off_callback(self.__on_tts_sound_off)
        self.__osl.tts.set_pause_on_callback(self.__on_tts_pause_on)
        self.__osl.tts.set_pause_off_callback(self.__on_tts_pause_off)
        self.__osl.tts.set_voice_list_callback(self.__on_tts_voice_list)
        self.__osl.tts.set_speak_status_callback(self.__on_tts_speak_status)
        self.__osl.set_sound_on_callback(self.__on_general_sound_on)
        self.__osl.set_sound_off_callback(self.__on_general_sound_off)
        self.__osl.set_dongle_disconnect_callback(self.__on_dongle_disconnect)
        
    def destroy(self):
        self.__osl.destroy()
        TuxOSLObjAncestor.destroy(self)
        
    def connect(self, host = 'localhost', ports = [5510, 5511]):
        if self.__osl.start_async():
            self.set_connect_state(True)
            self.update_events('general', 'connected')
            return True
        else:
            return False
            
    def auto_connect(self, value, host = 'localhost', ports = [5510, 5511]):
        if self.__osl.start_async():
            self.set_connect_state(True)
            self.update_events('general', 'connected')
            return True
        else:
            return False
        
    def disconnect(self):
        self._events_hdl.clear_conditions()
        self.update_events('general', 'disconnected')
        
    def __on_wav1_sound_on(self):
        self.update_events('wav_player', 0, 'sound', 'on')
            
    def __on_wav1_sound_off(self):
        self.update_events('wav_player', 0, 'sound', 'off')
            
    def __on_wav1_pause_on(self):
        self.update_events('wav_player', 0, 'pause', 'on')
            
    def __on_wav1_pause_off(self):
        self.update_events('wav_player', 0, 'pause', 'off')
            
    def __on_wav2_sound_on(self):
        self.update_events('wav_player', 1, 'sound', 'on')
            
    def __on_wav2_sound_off(self):
        self.update_events('wav_player', 1, 'sound', 'off')
            
    def __on_wav2_pause_on(self):
        self.update_events('wav_player', 1, 'pause', 'on')
            
    def __on_wav2_pause_off(self):
        self.update_events('wav_player', 1, 'pause', 'off')
            
    def __on_tts_sound_on(self):
        self.update_events('text_to_speech', 0, 'sound', 'on')
        self.__osl.wav_player_1.set_volume(35)
        self.__osl.wav_player_2.set_volume(35)
            
    def __on_tts_sound_off(self):
        self.update_events('text_to_speech', 0, 'sound', 'off')
        self.__osl.wav_player_1.set_volume(80)
        self.__osl.wav_player_2.set_volume(80)
            
    def __on_tts_pause_on():
        self.update_events('text_to_speech', 0, 'pause', 'on')
        self.__osl.wav_player_1.set_volume(80)
        self.__osl.wav_player_2.set_volume(80)
            
    def __on_tts_pause_off(self):
        self.update_events('text_to_speech', 0, 'pause', 'off')
        self.__osl.wav_player_1.set_volume(35)
        self.__osl.wav_player_2.set_volume(35)
            
    def __on_tts_voice_list(self, voice_list):
        self.update_events('text_to_speech', 0, 'voice_list', voice_list)
            
    def __on_tts_locutor_loaded(self):
        self.update_events('text_to_speech', 0, 'locutor_loaded')
        
    def __on_tts_speak_status(self, status):
        self.update_events('text_to_speech', 0, 'speak_status', status)
            
    def __on_general_sound_on(self):
        self.update_events('general', 'sound', 'on')
            
    def __on_general_sound_off(self):
        self.update_events('general', 'sound', 'off')
            
    def __on_dongle_disconnect(self):
        self.update_events('general', 'dongle_disconnected')
        
    def _tts_speak(self, text, locutor = SPK_US_MALE_NAME, pitch = 100):
        if not self.get_connect_state():
            return -1
        try:
            u = text.decode("utf-8")
            text = u.encode('latin-1', 'replace')
        except:
            try:
                text = text.encode('iso-8859-1', 'replace')
            except:
                return -1
        self.__tts_mutex.acquire()
        self.__osl.tts.set_pitch(pitch)
        ret = self.current_tts_channel
        # Try to select the locutor
        if self.__osl.tts.select_locutor(locutor) != 1:
            ret = -1
            print "Locutor can't be loaded"
        # If locutor is ok, try to speak
        if ret != -1:
            self.__osl.tts.speak(text)
            self.current_tts_channel = 0
            ret = 0
            cr, result = self.tts.on_speak_status.wait_condition((None,), 5.0)
            if cr == False:
                ret = -1
                print 'Speak status not found'
            elif result[0] != "NoError":
                ret = -1
                print 'Speak return [%s]' % result[0]
        # If speak is ok, try to wait the sound on event
        if ret != -1:
            if self.tts.get_sound_state() == 0:
                cr = self.tts._wait_speak_start(5.0)
                if not cr:
                    ret = -1
                    print 'Wait sound on timeout 10 seconds'
        self.__tts_mutex.release()
        return ret
        
    def _tts_set_pause(self, value):
        if not self.get_connect_state():
            return False
        self.__osl.tts.pause(value)
        return True
        
    def _tts_set_stop(self):
        if not self.get_connect_state():
            return False
        self.__osl.tts.stop()
        return True
        
    def _tts_get_authorized_voices_list(self):
        if not self.get_connect_state():
            return []
        return self.__osl.tts.get_voice_list()
        
    def _tts_get_sound_state(self):
        if not self.get_connect_state():
            return 0
        return self.__osl.tts.get_sound_state()
        
    def _tts_get_pause_state(self):
        if not self.get_connect_state():
            return 0
        return self.__osl.tts.get_pause_state()
        
    def _tts_get_pitch(self):
        if not self.get_connect_state():
            return 100
        return self.__osl.tts.get_pitch()
        
    def _wav_play(self, wav_path, begin = 0.0, end = 9999999.0):
        if not self.get_connect_state():
            return -1
        if not os.path.isfile(wav_path):
            return -1
        wav_r = None
        channel = -1
        self.__wav_mutex.acquire()
        if self.__osl.wav_player_1.get_sound_state() == 0:
            wav_r = self.__osl.wav_player_1
            channel = 0
        elif self.__osl.wav_player_2.get_sound_state() == 0:
            wav_r = self.__osl.wav_player_2
            channel = 1
        else:
            wav_r = self.__osl.wav_player_1
            channel = 0
        self.current_wav_channel = channel
        wav_r.play(wav_path, begin, end)
        self.wav._wait_play_start(0.5)
        self.__wav_mutex.release()
        return channel
        
    def _wav_set_pause(self, value):
        if not self.get_connect_state():
            return False
        self.__osl.wav_player_1.pause(value)
        self.__osl.wav_player_2.pause(value)
        return True
        
    def _wav_set_stop(self):
        if not self.get_connect_state():
            return False
        self.__osl.wav_player_1.stop()
        self.__osl.wav_player_2.stop()
        return True
        
    def _wav_get_sound_state(self, channel):
        if not self.get_connect_state():
            return 0
        result = 0
        if channel == 0:
            result = self.__osl.wav_player_1.get_sound_state()
        else:
            result = self.__osl.wav_player_2.get_sound_state()
        return result
        
    def _wav_get_pause_state(self, channel):
        if not self.get_connect_state():
            return 0
        result = 0
        if channel == 0:
            result = self.__osl.wav_player_1.get_pause_state()
        else:
            result = self.__osl.wav_player_2.get_pause_state()
        return result
        
class TuxOSLObjDistant(TuxOSLObjAncestor):

    def __init__(self):
        TuxOSLObjAncestor.__init__(self)
        self.__cmd_client = TuxOSLCmdClient()
        self.__cmd_client.on_event.connect(self.__on_cmd_event, threaded = False)
        self.__event_client = TuxOSLEventClient("Distant object")
        self.__event_client.on_event.connect(self.__on_event_event, threaded = False)
        
    def destroy(self):
        self.__event_client.destroy()
        self.__cmd_client.destroy()
        TuxOSLObjAncestor.destroy(self)
        
    def connect(self, host = 'localhost', ports = [5510, 5511]):
        cmd_ret = self.__cmd_client.connect(host, ports[1])
        event_ret = self.__event_client.connect(host, ports[0])
        if cmd_ret and event_ret:
            self.set_connect_state(True)
            
    def auto_connect(self, value, host = 'localhost', ports = [5510, 5511]):
        self.__event_client.auto_connect(value, host, ports[0])
        self.__cmd_client.auto_connect(value, host, ports[1])
        
    def disconnect(self):
        self.__event_client.disconnect()
        self.__cmd_client.disconnect()
        
    def kill(self):
        if not self.get_connect_state():
            return
        self.__cmd_client.server().kill()
        
    def __on_cmd_event(self, *args):
        if args[0] == 'client':
            if args[1] == 'connected':
                if self.__event_client.get_connected():
                    self.set_connect_state(True)
                    self.update_events('general', 'connected')
            elif args[1] == 'disconnected':
                self.set_connect_state(False)
                self.update_events('general', 'disconnected')
        else:
            pass
    
    def __on_event_event(self, *args):
        if args[0] == 'client':
            if args[1] == 'connected':
                if self.__cmd_client.get_connected():
                    self.set_connect_state(True)
                    self.update_events('general', 'connected')
            elif args[1] == 'disconnected':
                self.set_connect_state(False)
                self.update_events('general', 'disconnected')
                self._events_hdl.clear_conditions()
        else:
            self.update_events(*args)
        
    def _tts_speak(self, text, locutor = SPK_US_MALE_NAME, pitch = 100):
        if not self.get_connect_state():
            return -1
        return self.__cmd_client.server()._tts_speak(text, locutor, pitch)
        
    def _tts_set_pause(self, value):
        if not self.get_connect_state():
            return False
        return self.__cmd_client.server()._tts_set_pause(value)
        
    def _tts_set_stop(self):
        if not self.get_connect_state():
            return False
        return self.__cmd_client.server()._tts_set_stop()
        
    def _tts_get_authorized_voices_list(self):
        if not self.get_connect_state():
            return []
        return self.__cmd_client.server()._tts_get_authorized_voices_list()
        
    def _tts_get_sound_state(self):
        if not self.get_connect_state():
            return 0
        return self.__cmd_client.server()._tts_get_sound_state()
        
    def _tts_get_pause_state(self):
        if not self.get_connect_state():
            return 0
        return self.__cmd_client.server()._tts_get_pause_state()
        
    def _tts_get_pitch(self):
        if not self.get_connect_state():
            return 100
        return self.__cmd_client.server()._tts_get_pitch()
        
    def _wav_play(self, wav_path, begin = 0.0, end = 9999999.0):
        if not self.get_connect_state():
            return -1
        return self.__cmd_client.server()._wav_play(wav_path, begin, end)
        
    def _wav_set_pause(self, value):
        if not self.get_connect_state():
            return False
        return self.__cmd_client.server()._wav_set_pause(value)
        
    def _wav_set_stop(self):
        if not self.get_connect_state():
            return False
        return self.__cmd_client.server()._wav_set_stop()
        
    def _wav_get_sound_state(self, channel):
        if not self.get_connect_state():
            return 0
        return self.__cmd_client.server()._wav_get_sound_state(channel)
        
    def _wav_get_pause_state(self, channel):
        if not self.get_connect_state():
            return 0
        return self.__cmd_client.server()._wav_get_pause_state(channel)

if __name__ == "__main__":
    def on_event(*args):
        print args

    test = TuxOSLObjDistant()
    test.on_event.connect(on_event, threaded = False)
    test.connect()
    print 'connected'
    print test.tts.speak("Hello world ! how are you ?")
