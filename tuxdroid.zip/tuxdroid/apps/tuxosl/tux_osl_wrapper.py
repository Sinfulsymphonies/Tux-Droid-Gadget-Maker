#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - OSL - Wrapper to osl library
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
from ctypes import *
import os
import threading
import time
from tux_osl_const import *

tux_osl_lib = CDLL("%s/_TUX_OSL.so" % os.path.dirname(__file__))

TUX_OSL_SIMPLE_CALLBACK = CFUNCTYPE(None)
TUX_OSL_VOICE_LIST_CALLBACK = CFUNCTYPE(None, c_int, POINTER(c_int8))
TUX_OSL_SPEAK_STATUS_CALLBACK = CFUNCTYPE(None, c_char_p)

TUX_OSL_WRAPPER_VERSION = '0.0.2-alpha'

class TTSpeak(object):

    def __init__(self):
        self.__callback_garbage = []
        self.__speak_thread = None
        self.__action_mutex = None
        self.__on_voice_list_funct = None
        self.current_voice_list = []
        hf = TUX_OSL_VOICE_LIST_CALLBACK(self.__on_voice_list)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_tts_set_voice_list_callback(hf)
        
    def destroy(self):
        self.stop()
        if self.__speak_thread != None:
            if self.__speak_thread.isAlive():
                self.__speak_thread.join()
        return 0
        
    def set_volume(self, volume):
        if (volume > 100) or (volume < 0):
            return
        tux_osl_lib.tux_osl_tts_set_volume(c_uint8(volume))
        return 0
        
    def get_volume(self):
        return tux_osl_lib.tux_osl_tts_get_volume()
        
    def speak(self, text):
        self.stop()
        self.__speak_thread = threading.Thread(  target = tux_osl_lib.tux_osl_tts_speak, 
                                                args = ( c_char_p(text),))
        self.__speak_thread.start()
        return 0
        
    def pause(self, value = True):
        if value:
            val = 1
        else:
            val = 0
        tux_osl_lib.tux_osl_tts_set_pause(val)
        return 0
        
    def stop(self):
        tux_osl_lib.tux_osl_tts_stop()
        return 0
        
    def select_default_locutor(self):
        return tux_osl_lib.tux_osl_tts_set_default_locutor()
        
    def select_locutor(self, locutor_name):
        if locutor_name in SPK_NAME_LIST:
            return tux_osl_lib.tux_osl_tts_set_locutor(c_char_p(locutor_name))
        return -1
            
    def set_pitch(self, pitch):
        rpitch = int(10000 / pitch)
        tux_osl_lib.tux_osl_tts_set_pitch(c_uint8(rpitch))
        return 0
        
    def request_voice_list(self):
        tux_osl_lib.tux_osl_tts_request_voice_list()
        
    def get_voice_list(self):
        byte_a = tux_osl_lib.tux_osl_tts_get_voice_list()
        vl = string_at(c_char_p(byte_a))
        result = []
        for v in vl:
            result.append(SPK_NAME_LIST[ord(v)])
        return result
       
        
    def get_pitch(self):
        pitch = tux_osl_lib.tux_osl_tts_get_pitch()
        pitch = int(10000 / pitch)
        return pitch
        
    def get_sound_state(self):
        return tux_osl_lib.tux_osl_tts_get_sound_state()
        
    def get_pause_state(self):
        return tux_osl_lib.tux_osl_tts_get_pause_state()
        
    def set_sound_on_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_tts_set_sound_on_callback(hf)
        
    def set_sound_off_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_tts_set_sound_off_callback(hf)
        
    def set_pause_on_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_tts_set_pause_on_callback(hf)
        
    def set_pause_off_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_tts_set_pause_off_callback(hf)
        
    def set_stop_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_tts_set_stop_callback(hf)
        
    def set_locutor_loaded_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_tts_set_voice_loaded_callback(hf)
        
    def set_speak_status_callback(self, funct):
        hf = TUX_OSL_SPEAK_STATUS_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_tts_set_speak_status_callback(hf)
        
    def set_voice_list_callback(self, funct):
        self.__on_voice_list_funct = funct
        
    def __on_voice_list(self, size, data):
        result = []
        for i in range(size):
            if data[i] != 0:
                result.append(SPK_NAME_LIST[data[i]])
        self.current_voice_list = result
        if self.__on_voice_list_funct != None:
            self.__on_voice_list_funct(result)

class WavPlayer(object):

    def __init__(self, channel):
        self.__play_thread = None
        self.__callback_garbage = []
        self.__channel = channel
        
    def destroy(self):
        self.stop()
        if self.__play_thread != None:
            if self.__play_thread.isAlive():
                self.__play_thread.join()
        return 0
        
    def set_volume(self, volume):
        if (volume > 100) or (volume < 0):
            return -1
        tux_osl_lib.tux_osl_wav_player_set_volume(self.__channel, c_uint8(volume))
        return 0
        
    def get_volume(self):
        return tux_osl_lib.tux_osl_wav_player_get_volume(self.__channel)
        
    def play(self, wav_path, begin = 0.0, end = 99999.0):
        self.stop()
        self.__play_thread = threading.Thread(  target = tux_osl_lib.tux_osl_wav_player_play, 
                                                args = (    c_int(self.__channel), 
                                                            c_char_p(wav_path), 
                                                            c_float(begin), 
                                                            c_float(end)))
        self.__play_thread.start()
        
    def pause(self, value = True):
        if value:
            val = 1
        else:
            val = 0
        tux_osl_lib.tux_osl_wav_player_set_pause(self.__channel, c_int(val))
        return 0
        
    def stop(self):
        tux_osl_lib.tux_osl_wav_player_stop(self.__channel)
        return 0
        
    def get_sound_state(self):
        return tux_osl_lib.tux_osl_wav_player_get_sound_state(self.__channel)
        
    def get_pause_state(self):
        return tux_osl_lib.tux_osl_wav_player_get_pause_state(self.__channel)
        
    def set_sound_on_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_wav_player_set_sound_on_callback(self.__channel, hf)
        
    def set_sound_off_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_wav_player_set_sound_off_callback(self.__channel, hf)
        
    def set_pause_on_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_wav_player_set_pause_on_callback(self.__channel, hf)
        
    def set_pause_off_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_wav_player_set_pause_off_callback(self.__channel, hf)
        
    def set_stop_callback(self, funct):
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        tux_osl_lib.tux_osl_wav_player_set_stop_callback(self.__channel, hf)
        

class TuxOSLWrapper(object):

    def __init__(self):
        self.__callback_garbage = []
        ret = tux_osl_lib.tux_osl_init_module()
        if ret != 0:
            print "Can't initialize the module (%d)" % ret
            self.__system_ready = False
        else:
            self.__system_ready = True
        self.wav_player_1 = WavPlayer(0)
        self.wav_player_2 = WavPlayer(1)
        self.tts = TTSpeak()
        self.__start_thread = None
        self.__start_async_thread = None
        self.__sr_mutex = threading.Lock()
        self.__on_dongle_disconnect_funct = None
        self.__on_library_exit_funct = None
        p = POINTER(TUX_OSL_SIMPLE_CALLBACK).in_dll(tux_osl_lib, 'tux_dongle_disconnected_funct')
        hf = TUX_OSL_SIMPLE_CALLBACK(self.__on_dongle_disconnect)
        self.__callback_garbage.append(hf)
        memmove(addressof(p), addressof(hf), sizeof(TUX_OSL_SIMPLE_CALLBACK)) 
        
    def destroy(self):
        #if not self.__system_ready:
        #    return
        self.wav_player_1.destroy()
        self.wav_player_2.destroy()
        self.tts.destroy()
        
        self.__set_system_ready(False)
        tux_osl_lib.tux_osl_close_module()
        if self.__start_thread != None:
            if self.__start_thread.isAlive():
                self.__start_thread.join()
        if self.__on_library_exit_funct != None:
            self.__on_library_exit_funct()
        
    def start(self):
        if not self.__get_system_ready():
            return False
        tux_osl_lib.tux_osl_run()
        self.tts.request_voice_list()
        return True
        
    def __on_dongle_disconnect(self):
        self.__set_system_ready(False)
        if self.__on_dongle_disconnect_funct != None:
            self.__on_dongle_disconnect_funct()
        
    def __set_system_ready(self, value):
        self.__sr_mutex.acquire()
        self.__system_ready = value
        self.__sr_mutex.release()
        
    def __get_system_ready(self):
        self.__sr_mutex.acquire()
        result = self.__system_ready
        self.__sr_mutex.release()
        return result
        
    def system_ready(self):
        return self.__get_system_ready()
        
    def start_async(self, timeout = -1):
        if not self.__get_system_ready():
            return False
        def async_funct(timeout):
            self.__start_thread = threading.Thread(target = tux_osl_lib.tux_osl_run)
            self.__start_thread.start()
            time.sleep(0.5)
            self.tts.request_voice_list()
            if timeout != -1:
                for i in range(timeout * 10):
                    if not self.__get_system_ready():
                        break
                    time.sleep(0.1)
                self.destroy()
        self.__start_async_thread = threading.Thread(target = async_funct, args = (timeout,))
        self.__start_async_thread.start()
        return True
        
    def set_sound_on_callback(self, funct):
        p = POINTER(TUX_OSL_SIMPLE_CALLBACK).in_dll(tux_osl_lib, 'mixer_sound_on_funct')
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        memmove(addressof(p), addressof(hf), sizeof(TUX_OSL_SIMPLE_CALLBACK)) 
        
    def set_sound_off_callback(self, funct):
        p = POINTER(TUX_OSL_SIMPLE_CALLBACK).in_dll(tux_osl_lib, 'mixer_sound_off_funct')
        hf = TUX_OSL_SIMPLE_CALLBACK(funct)
        self.__callback_garbage.append(hf)
        memmove(addressof(p), addressof(hf), sizeof(TUX_OSL_SIMPLE_CALLBACK))
        
    def set_dongle_disconnect_callback(self, funct):
        self.__callback_garbage.append(funct)
        self.__on_dongle_disconnect_funct = funct
        
    def set_library_exit_callback(self, funct):
        self.__callback_garbage.append(funct)
        self.__on_library_exit_funct = funct
        
