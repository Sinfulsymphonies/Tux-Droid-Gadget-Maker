#!/usr/bin/python
# -*- coding: latin1 -*-
# -----------------------------------------------------------------------------
# Tux Droid - OSL - Events handlers
# Copyright (C) 2007 C2ME Sa <remi.jocaille@c2me.be>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
# 02111-1307, USA.
# -----------------------------------------------------------------------------
# $Id: $
# -----------------------------------------------------------------------------
import threading
import time
import copy

class EventsHandler(object):

    def __init__(self):
        self.event = {}
        
    def destroy(self):
        for event_hdler in self.event.keys():
            self.event[event_hdler].destroy()
        self.event = {}
        
    def insert(self, event_name):
        if event_name not in self.event.keys():
            self.event[event_name] = EventHandler()
            return True
        else:
            return False
            
    def connect(self, event_name, funct, condition = None, threaded = True, idx = None):
        if event_name not in self.event.keys():
            return -1
        return self.event[event_name].connect(funct, condition, threaded, idx)
        
    def disconnect(self, event_name, idx):
        if event_name not in self.event.keys():
            return
        self.event[event_name].disconnect(idx)
        
    def push(self):
        for event_hdler in self.event.keys():
            self.event[event_hdler].push()
    
    def pop(self):
        for event_hdler in self.event.keys():
            self.event[event_hdler].pop()
            
    def clear(self):
        for event_hdler in self.event.keys():
            self.event[event_hdler].clear()
        
    def emit(self, event_name, args):
        if event_name not in self.event.keys():
            return
        self.event[event_name].emit(*args)
        
    def notify(self, event_name, args):
        if event_name not in self.event.keys():
            return
        self.event[event_name].emit(*args)
        
    def wait_condition(self, event_name, condition, timeout = 999999999.0):
        if event_name not in self.event.keys():
            return False, []
        return self.event[event_name].wait_condition(condition, timeout)
            
    def clear_conditions(self):
        for event_hdler in self.event.keys():
            self.event[event_hdler].clear_conditions()

class EventHandler(object):

    def __init__(self):
        self.__funct_struct_list = []
        self.__fifo_list = []
        self.__list_mutex = threading.Lock()
        self.__threads_list = []
        self.__lock_list = []
        self.__lock_mutex = threading.Lock()
        self.__run_flag = True
        self.__run_mutex = threading.Lock()
        self.connect(self.__lock_list_process)
        
    def __get_run_flag(self):
        self.__run_mutex.acquire()
        result = self.__run_flag
        self.__run_mutex.release()
        return result
        
    def __set_run_flag(self, value):
        self.__run_mutex.acquire()
        self.__run_flag = value
        self.__run_mutex.release()

    def destroy(self):
        self.clear_conditions()
        self.__set_run_flag(False)
        for my_thread in self.__threads_list:
            if my_thread.isAlive():
                my_thread._Thread__stop()
                
    def connect(self, funct, condition = None, threaded = True, idx = None):
        if idx == None:
            result = self.__connect(funct, condition, threaded)
        else:
            ret = self.__update_connect(idx, funct, condition, threaded)
            if not ret:
                result = self.__connect(funct, condition, threaded)
            else:
                result = idx
        return result

    def __connect(self, funct, condition = None, threaded = True):
        self.__list_mutex.acquire()
        idx = len(self.__funct_struct_list)
        n_funct = {
            'funct' : funct,
            'condition' : condition,
            'threaded' : threaded
        }
        self.__funct_struct_list.append(n_funct)
        self.__list_mutex.release()
        return idx
        
    def __update_connect(self, idx, funct, condition = None, threaded = True):
        self.__list_mutex.acquire()
        if idx < len(self.__funct_struct_list): 
            n_funct = {
                'funct' : funct,
                'condition' : condition,
                'threaded' : threaded
            }
            self.__funct_struct_list[idx] = n_funct
            result = True
        else:
            result = False
        self.__list_mutex.release()
        return result

    def push(self):
        self.__list_mutex.acquire()
        self.__fifo_list.append(self.__funct_struct_list)
        self.__list_mutex.release()
        self.clear()

    def pop(self):
        if len(self.__fifo_list) > 0:
            self.__list_mutex.acquire()
            self.__funct_struct_list = self.__fifo_list.pop()
            self.__list_mutex.release()

    def clear(self):
        self.__list_mutex.acquire()
        self.__funct_struct_list = []
        self.__list_mutex.release()

    def disconnect(self, idx):
        self.__list_mutex.acquire()
        if idx < len(self.__funct_struct_list): 
            self.__funct_struct_list[idx] = None
        self.__list_mutex.release()
        
    def __refresh_threads_list(self):
        nl = []
        for t in self.__threads_list:
            if t.isAlive():
                nl.append(t)
        self.__threads_list = nl

    def __run(self, funct_ptr, idx, fargs):
        try:
            funct_ptr(*fargs)
        except:
            self.__list_mutex.acquire()
            self.__funct_struct_list[idx] == None
            self.__list_mutex.release()
            
    def emit(self, *fargs):
        self.notify(*fargs)

    def notify(self, *fargs):
        m_fargs = copy.copy(fargs)
        self.__list_mutex.acquire()
        if len(self.__funct_struct_list) == 0:
            self.__list_mutex.release()
            return
        try:
            funct_struct_list = self.__funct_struct_list
        except:
            self.__list_mutex.release()
            return
        self.__list_mutex.release()
        for idx, funct_struct in enumerate(funct_struct_list):
            if not self.__get_run_flag():
                break
            if funct_struct != None:
                condition_matched = True
                if funct_struct['condition'] != None: # funct entry have a condition
                    if len(funct_struct['condition']) != len(m_fargs):
                        condition_matched = False
                    for i, rule in enumerate(funct_struct['condition']):
                        if funct_struct['condition'][i] not in [None, m_fargs[i]]:
                            condition_matched = False
                            break
                if condition_matched:
                    self.__refresh_threads_list()
                    if funct_struct['threaded']: 
                        t=threading.Thread(target=self.__run, args=(funct_struct['funct'], idx, m_fargs))
                        t.setName('Event_CallBack')
                        try:
                            t.start()
                            self.__threads_list.append(t)
                        except:
                            pass
                    else:
                        self.__run(funct_struct['funct'], idx, m_fargs)
                
    def __lock_list_process(self, *args):
        self.__lock_mutex.acquire()
        new_lock_list = []
        
        for my_lock in self.__lock_list:
            if my_lock['timeout'] <= (time.time() - my_lock['start_time']):
                my_lock['result'].append((None,))
                my_lock['mutex'].acquire()
                my_lock['mutex'].notify()
                my_lock['mutex'].release()
                continue
                
            rules = my_lock['rules']
            if len(rules) != len(args):
                new_lock_list.append(my_lock)
                continue
            
            matched_rule = True
            for i, rule in enumerate(rules):
                if not rule in [None, args[i]]:
                    matched_rule = False
                    break
            
            if not matched_rule:
                new_lock_list.append(my_lock)
                continue
            else:
                my_lock['result'].append(args)
                my_lock['mutex'].acquire()
                my_lock['mutex'].notify()
                my_lock['mutex'].release()
                
        self.__lock_list = new_lock_list    
        self.__lock_mutex.release()
            
        
    def wait_condition(self, condition, timeout = 999999999.0):
        result = []
        condition_mutex = threading.Condition(threading.Lock())
        new_lock = {    
            'rules' : condition, 
            'result' : result, 
            'mutex' : condition_mutex,
            'start_time' : time.time(),
            'timeout' : timeout
        }
        self.__lock_mutex.acquire()
        self.__lock_list.append(new_lock)
        self.__lock_mutex.release()
        condition_mutex.acquire()
        condition_mutex.wait(timeout)
        condition_mutex.release()
        if len(result) != 0:
            return True, result[0]
        else:
            return False, []
        
    def clear_conditions(self):
        for my_lock in self.__lock_list:
            my_lock['timeout'] = 0.0
            my_lock['result'].append((None,))
            my_lock['mutex'].acquire()
            my_lock['mutex'].notify()
            my_lock['mutex'].release()
            
if __name__ == "__main__":
    import time
    import thread

    def on_ten_event(*args):
        print '--> Ten event (%d)' % args[0]
        
    def on_unit_event(*args):
        print 'Unit event (%d)' % args[0]
        
    def dummy_events_loop(events_handler):
        for i in range (100):
            events_handler.emit('unit_event', (i,))
            if (i % 10) == 0:
                events_handler.emit('ten_event', (i,))
            time.sleep(0.1)
    
    # Create an events handler           
    my_events_handler = EventsHandler()
    
    # Add two events
    my_events_handler.insert('unit_event')
    my_events_handler.insert('ten_event')
    
    # Connect callback functions
    u_idx = my_events_handler.connect('unit_event', on_unit_event, threaded = False)
    t_idx = my_events_handler.connect('ten_event', on_ten_event, threaded = False)
    
    # Start a dummy events loop in a thread
    thread.start_new_thread(dummy_events_loop, (my_events_handler,))
    
    # Wait a specific event with a timeout of 10 seconds
    print 'Wait that unit is equal to 45'
    my_events_handler.wait_condition('unit_event', (45,), 10.0)
    print 'Wait ok ! The number is equal to 45'
    
    # Wait a specific event with a timeout of 10 seconds
    print 'Wait that the number is equal to 90'
    my_events_handler.wait_condition('ten_event', (90,), 10.0)
    print 'Wait ok ! The number is equal to 90'
    
    # Disconnect callback functions
    my_events_handler.disconnect('unit_event', u_idx)
    my_events_handler.disconnect('ten_event', t_idx)
    
    # Destroy the handler
    my_events_handler.destroy()
